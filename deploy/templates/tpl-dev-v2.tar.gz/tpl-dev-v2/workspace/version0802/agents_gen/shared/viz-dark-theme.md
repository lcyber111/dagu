# 深色雷达军工视觉主题

## 领域色表（单一来源）

大屏领域主色由此表决定，agent-generator 生成智能体时据此选择，并通过 spec 的 `theme.primary` 传入构建脚本。构建脚本缺省主色为军绿 `#00ff88`。

| 领域 | 主色 | 背景 | 说明 |
|------|------|------|------|
| 军事/情报 | `#00ff88`（军绿色） | `#0a0e17` | 深色雷达军工风（默认） |
| 网络/安全 | `#00a6ff`（蓝色） | `#0a1628` | 深蓝天空主题 |
| 数据/分析 | `#ffd93d`（金色） | `#1a1a0e` | 暗金科技风 |
| 工具/开发 | `#ff6b6b`（红色） | `#1a0e0e` | 深色终端风 |
| 创意/写作 | `#c882ff`（紫色） | `#0e0a1a` | 深紫星空风 |
| 其他 | `#00d4aa`（青色） | `#0a0e17` | 深色雷达风 |

spec.theme 允许使用表外自定义主色（如 `#ff6b00` 台海打击场景），背景建议保持深色。

## 样式预设（style preset，单一来源）

| style | 适用任务类型 | 布局结构 | 视觉基调 |
|-------|------------|---------|---------|
| `command`（默认） | 态势/监控/实时追踪 | 大屏网格（header+KPI+rows+footer） | 深色雷达风（现默认） |
| `report-light` | 评估/研判/建议/对比分析 | 文书报告（标题区→KPI→摘要→分节→结论） | 浅色纸张、衬线标题、打印友好 |
| `report-dark` | 正式军情研判/威胁评估 | 同 report-light | 深色机密简报风（金棕主色） |
| `timeline` | 事件复盘/航迹/过程演进 | 垂直时间线（主线+节点卡片） | 深色时间线风 |
| `terminal` | 技术/数据/工具/日志 | 大屏网格 | 荧光绿等宽终端风 |
| `minimal` | 参考/对比/清单/百科 | 大屏网格 | 极简浅色卡片 |

**选择规则**：分析智能体按任务性质自动选 style（写入 spec.style），用户明确指定风格时以用户为准：

- 带"态势/监控/实时"性质 → `command`
- 带"评估/研判/建议/报告"性质 → `report-light`（正式军情研判 → `report-dark`）
- 带"复盘/轨迹/过程/演进"性质 → `timeline`
- 带"技术/数据/工具/日志"性质 → `terminal`
- 带"参考/对比/清单/百科"性质 → `minimal`

**说明**：

- `command` 为默认；预设样式已内置领域主色，`spec.theme` 仅对 `command` 生效（预设由 preset CSS 覆盖）
- 预设 CSS 位于 `lib/dashboard/presets/<style>.css`，构建脚本按 spec.style 自动引入；智能体不得手写 CSS
- report/timeline 布局的 spec 结构见 `shared/html-output.md`
- 示例：`templates/dashboard-spec-{command,report-light,report-dark,timeline,terminal,minimal}-example.json`

## 配色方案

- **背景色**：`#0a0e17`（深色雷达军工风格通用底色）
- **主色**：默认 `#00ff88`（军绿色），辅以金色 `#ffd93d` 高亮
- **字体体系**：'Segoe UI', 'Helvetica Neue', Arial, 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', sans-serif（**所有预设统一**，不再用 Georgia/宋体衬线，避免数字字母歪斜）；数字使用 'Consolas', monospace；report 正文/表格加 `font-variant-numeric: tabular-nums` 数字纵向对齐
- **卡片样式**：半透明毛玻璃效果（`background: rgba(255,255,255,0.05)`），边框 1px solid rgba(主色,0.2)
- **地图配色**：海洋 `#0d1b2a`，陆地 `#1b2838`，陆地边框 `#2a3a4a`，标注光晕使用领域主色

## 布局响应式

- **≥1200px**：全屏矩阵布局
- **768-1199px**：自适应网格（图表行自动折为单列）
- **≤767px**：纵向堆叠

## 动画效果

- 地图标记点呼吸光晕动画（effectScatter ripple）
- 数字渐进计数动画（构建脚本自动启用，KPI value 为数字时）
- 图表入场淡入

## 地图方案

- ECharts + world.geojson 离线地图（声明式 `map` 类型自动完成注册/渲染）
- 图例位置：地图右上角

## 实现说明

- 主题样式已固化在 `lib/dashboard/dashboard.css`（CSS 变量驱动），由 `scripts/build_dashboard.py` 按 spec.theme 注入覆盖段
- 智能体**不得手写 CSS**，通过 spec 声明内容，样式由构建链路统一提供
