# MySQL 目标情报库连接与查询

## 连接方式

MySQL 对伊情报侦库（连接信息在 `config/db_sources.json` 的 `mysql_gf` 节点，目标：哈梅内伊）：

```python
import json, pymysql, pandas as pd

with open('config/db_sources.json', encoding='utf-8') as f:
    cfg = json.load(f)['mysql_gf']

conn = pymysql.connect(
    host=cfg['host'],
    port=cfg['port'],
    user=cfg['user'],
    password=cfg['password'],
    database=cfg['database'],
    charset='utf8mb4',
    connect_timeout=5
)

# 查看可用表
tables_info = cfg.get('tables', {})
print(f'MySQL 情报库已连接，可用表 {len(tables_info)} 个:')
for tname, tinfo in tables_info.items():
    print(f'  - {tname}: {tinfo["cn_name"]} — {tinfo["description"]}')

conn.close()
```

## SQL 查询注意事项

- MySQL 连接已指定 `database='gf'`，SQL 中**直接写表名**即可（如 `SELECT * FROM communication`），无需 `gf.` 前缀
- 字段参考 `schema/mysql_gf_*.md` 文件

### 查询表结构

```python
conn = pymysql.connect(host=cfg['host'], port=cfg['port'],
                       user=cfg['user'], password=cfg['password'],
                       database=cfg['database'], charset='utf8mb4',
                       connect_timeout=5)

with conn.cursor() as cur:
    cur.execute("DESCRIBE communication")
    for row in cur.fetchall():
        print(f'  {row[0]}: {row[1]}')

conn.close()
```

### 查询数据

```python
conn = pymysql.connect(host=cfg['host'], port=cfg['port'],
                       user=cfg['user'], password=cfg['password'],
                       database=cfg['database'], charset='utf8mb4',
                       connect_timeout=5)

df = pd.read_sql("SELECT * FROM attribution_person WHERE name_en LIKE '%Khamenei%' LIMIT 10", conn)
conn.close()
```
