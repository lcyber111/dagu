# MySQL 目标情报库查询（统一网关）

MySQL 对伊情报侦库（`config/db_sources.json` 的 `mysql_gf` 节点，目标：哈梅内伊）查询统一经只读网关
`scripts/db_query.py` 完成。**禁止直接写 pymysql 连接代码**——凭据只存在于网关进程，且网关强制只读。

## 网关命令

```bash
# 列出表清单（读注册表，不访问数据库）
python scripts/db_query.py --source mysql_gf --tables

# 内省表结构
python scripts/db_query.py --source mysql_gf --schema communication

# 只读查询（自动追加 LIMIT 1000，上限 5000）
python scripts/db_query.py --source mysql_gf --sql "SELECT * FROM communication"
```

输出为 JSON：`{"ok": true, "columns": [...], "rows": [...], "row_count": N, "truncated": false}`。
失败返回 `{"ok": false, "error": ...}` 且 exit code 1。

## SQL 查询注意事项

- 连接已指定 `database='gf'`，SQL 中**直接写表名**即可（如 `SELECT * FROM communication`），无需 `gf.` 前缀
- 内省元数据（列含义）以 `--schema` 为准；业务判读规则按需读取 `schema/mysql_gf_*.md`

### 查询表结构

```bash
python scripts/db_query.py --source mysql_gf --schema communication
```

### 查询数据

```bash
python scripts/db_query.py --source mysql_gf --sql "SELECT * FROM attribution_person WHERE name_en LIKE '%Khamenei%'"
```
