# 严格离线部署环境说明

本环境为**严格离线环境**，禁止一切联网操作（websearch / webfetch / pip 安装 / 外部下载均不可用）。你作为本智能体必须遵守以下规则：

1. **所有前端库优先使用本地 `lib/` 目录下的离线包**（`lib/chartjs/`, `lib/echarts/`, `lib/fontawesome/` 等）
2. `lib/` 已预装全部所需前端库，禁止尝试联网下载缺失的库；若确有缺失，报告用户处理，不得联网获取
3. **态势地图**优先使用 ECharts + world.geojson 方案（无需瓦片，参考 `templates/echarts-map-reference.html`），**不得使用 Canvas 手绘或 Leaflet**
4. 生成的 HTML 必须能在**无网络环境下双击打开即可运行**，所有资源引用使用相对路径
5. **所有分析结果必须生成 HTML 大屏文件**，不得仅以文本或表格形式汇报
6. **禁止 websearch/webfetch**：情报仅来自本地知识库（`rag/`、`schema/`）与数据库（Doris/MySQL），数据不足时如实标注"数据缺失"，不得编造

## 资源管理策略

1. 优先从 `lib/` 目录引用本地包（HTML 中使用相对路径 `../lib/包名/文件`，因为 HTML 存在 `html/` 子目录下）
2. Python 依赖（`pandas`/`pymysql`/`jsonschema`）与 `node` 已预装于运行环境，**禁止联网安装**；确缺失时报告用户处理
3. 使用前先用 `bash` 检查环境是否已有（`python -c "import os; os.path.exists(...)"` 或 `python -c "import ..."`）
4. 数据库连接信息统一从 `config/db_sources.json` 读取，禁止硬编码

## 临时文件管理

1. 任务中产生的 Python 脚本、中间 JSON 等临时文件，统一写入 `temp/` 目录
2. 最终交付产物写入 `html/`（HTML 大屏）或 `output/`（JSON 分析结果）
3. 禁止在项目根目录、`data/`、`scripts/`、`.opencode/` 下写入任何临时文件
4. 任务结束时清理 `temp/` 中本次产生的临时文件
