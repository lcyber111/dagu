# 工具使用指南

| 工具 | 用途 | 使用场景 |
|------|------|---------|
| `question` | 向用户追问细节 | Step 0 需求澄清、分析范围确认 |
| `websearch` | ~~联网搜集情报~~（严格离线环境禁用） | 不可用 |
| `webfetch` | ~~加载在线数据/下载库~~（严格离线环境禁用） | 不可用 |
| `bash` | 运行 Python 脚本、系统命令 | 数据分析、文件操作 |
| `write` | 写出 HTML 大屏文件或脚本 | 最终输出 |
| `edit` | 修改/调整已生成的 HTML | 修正自检发现的问题 |
| `read` | 读取文件内容 | 验证写入的文件、读取 `lib/` 和 `schema/` 目录内容 |
| `glob/grep` | 搜索文件 | 查找 schema、知识库、模板 |

### bash 常用命令

```bash
# 检查 Python 依赖是否已预装（已内置，无需安装）
python -c "import pandas, pymysql, jsonschema, yaml, PIL; print('deps ok')"

# 执行数据分析脚本
python -c "..."

# 数据库查询（统一只读网关，禁止手写 pymysql 连接代码）
python scripts/db_query.py --sources                             # 列出数据源
python scripts/db_query.py --source doris --tables               # 表清单
python scripts/db_query.py --source doris --schema ais_ship_track # 表结构内省
python scripts/db_query.py --source doris --sql "SELECT ..."      # 只读查询

# 分析模式模块（lib/analysis/）
python -m lib.analysis.ais_anomaly --input temp/events.json --output temp/anomalies.json

# 检查文件是否存在（跨平台，Linux 容器无 Test-Path）
python -c "import os; print('exists' if os.path.exists('lib/<path>') else 'missing')"

# 验证数据库配置
python -c "import json; json.load(open('config/db_sources.json'))"
```

> 严格离线环境禁止 `pip install`、`npm install`、`Invoke-WebRequest`/`curl`/`wget` 等联网操作。
> 数据库一律经 `scripts/db_query.py` 只读网关取数，凭据不进提示词；分析算法优先调用 `lib/analysis/` 既有模块。
