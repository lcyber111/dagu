# 通用分析工具

## Haversine 球面距离计算

```python
import math

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R * c
```

## 数据质量验证

```python
# 坐标范围检查
assert df['Lat'].between(-90, 90).all(), 'Lat 超范围'
assert df['Lon'].between(-180, 180).all(), 'Lon 超范围'

# 空值检查
print('空值统计:\n', df.isnull().sum())

# 数据类型检查
print('数据类型:\n', df.dtypes)
```

## 分析逻辑自检

1. ✅ 距离计算使用 Haversine 而非平面欧氏距离（如涉及空间关联）
2. ✅ 字段类型和单位正确（按 schema 文档核对，DB TEXT 类型字段需 CAST 为 DOUBLE 再计算）
3. ✅ 关联规则应用顺序正确（先 SQL WHERE 过滤，再 Python 关联计算）
4. ✅ 归属唯一（多候选目标时按规则去重，如最近距离优先）
5. ✅ 数据时间窗口一致（使用 SQL 的 BETWEEN 或 >=/< 限定时间范围）
6. ✅ 数据库连接已关闭（确认 `conn.close()` 在查询结束后执行）
