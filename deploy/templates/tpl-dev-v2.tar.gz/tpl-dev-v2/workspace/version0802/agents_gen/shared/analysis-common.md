# 通用分析工具

## 空间关联分析

航母-飞机空间关联、Haversine 距离、高度分层、舰载机归属统一调用资产模块：

```bash
python -m lib.analysis.spatial_association --input temp/assoc.json --output temp/out.json \
    [--radius-km 50] [--landing-alt-ft 200] [--max-alt-ft 10000] [--max-dist-km 100]
```

- 输入/输出契约见模块 docstring；**不得自行内联实现 Haversine 或距离计算**（R=6371，规则源 `rag/carrier_aircraft_kb.md` §1.2）
- 误判防范、高度分层、重叠区最近归属等规则均由模块统一编码

## 数据质量验证

```python
# 坐标范围检查
assert df['Lat'].between(-90, 90).all(), 'Lat 超范围'
assert df['Lon'].between(-180, 180).all(), 'Lon 超范围'

# 空值检查
print('空值统计:\n', df.isnull().sum())

# 数据类型检查
print('数据类型:\n', df.dtypes)
```

## 分析逻辑自检

1. ✅ 空间关联使用 `lib.analysis.spatial_association` 模块（Haversine），而非平面欧氏距离或自行内联实现
2. ✅ 威胁等级评估优先调用 `lib.analysis.threat_assessment` 模块（4 级分级）
3. ✅ 字段类型和单位正确（按 schema 文档核对，DB TEXT 类型字段需 CAST 为 DOUBLE 再计算）
4. ✅ 关联规则应用顺序正确（先 SQL WHERE 过滤，再模块关联计算）
5. ✅ 归属唯一（多候选目标时按规则去重，如最近距离优先）
6. ✅ 数据时间窗口一致（使用 SQL 的 BETWEEN 或 >=/< 限定时间范围）
7. ✅ 数据库连接由 `scripts/db_query.py` 网关管理，分析代码无需自行维护 `conn.close()`
