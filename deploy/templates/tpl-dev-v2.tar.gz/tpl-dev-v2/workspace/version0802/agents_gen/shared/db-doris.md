# Doris 数据库连接与查询

## 连接方式

Doris 数据仓库（连接信息在 `config/db_sources.json` 的 `doris` 节点）：

```python
import json, pymysql, pandas as pd

with open('config/db_sources.json', encoding='utf-8') as f:
    cfg = json.load(f)['doris']

conn = pymysql.connect(
    host=cfg['host'],
    port=cfg['port'],
    user=cfg['user'],
    password=cfg['password'],
    connect_timeout=5
)

# 查看可用表
tables_info = cfg.get('tables', {})
print(f'Doris 数据仓库已连接，可用表 {len(tables_info)} 个:')
for tname, tinfo in tables_info.items():
    print(f'  - {tname}: {tinfo["cn_name"]} ({tinfo["record_count"]}条)')
```

建立连接后，用 `pd.read_sql(sql, conn)` 执行查询，最后 `conn.close()` 关闭。

## SQL 查询注意事项

- 表名 `aircraft_ads-b_track` 含连字符，SQL 中必须用反引号包裹：`` `aircraft_ads-b_track` ``
- 查询使用 `库名.表名` 格式（如 `standard.ais_ship_track`）

### 按时间范围查询

```python
# conn = <按上方方式建立连接>
sql = "SELECT * FROM standard.ais_ship_track WHERE acquire_time >= '2026-01-01' AND acquire_time < '2026-07-01'"
df = pd.read_sql(sql, conn)
```

### 按目标筛选

```python
sql = "SELECT * FROM standard.ais_ship_track WHERE hull_no = 'CVN-72' ORDER BY acquire_time"
df = pd.read_sql(sql, conn)
```

### 跨表关联查询

```python
sql = """
SELECT a.*, c.name, c.en_name, c.class, c.service_status
FROM standard.ais_ship_track a
JOIN standard.carrier_attribution c ON a.hull_no = c.hull_number
WHERE a.acquire_time >= '2026-01-01'
ORDER BY a.acquire_time
"""
df = pd.read_sql(sql, conn)
```

### 查询表结构

```python
with conn.cursor() as cur:
    cur.execute("SELECT COLUMN_NAME, COLUMN_TYPE, COLUMN_COMMENT FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='standard' AND TABLE_NAME='ais_ship_track'")
    for row in cur.fetchall():
        print(f'  {row[0]}: {row[1]} -- {row[2]}')
```

### 关闭连接

```python
conn.close()
```
