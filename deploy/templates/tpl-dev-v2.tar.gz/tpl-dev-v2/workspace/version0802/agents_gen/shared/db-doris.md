# Doris 数据库查询（统一网关）

Doris 数据仓库查询统一经只读网关 `scripts/db_query.py` 完成。**禁止直接写 pymysql 连接代码**——
连接凭据只在网关进程内读取（`config/db_sources.json` 的 `doris` 节点），不进入分析上下文，且网关强制只读。

## 网关命令

```bash
# 列出可用数据源
python scripts/db_query.py --sources

# 列出表清单（读注册表，不访问数据库）
python scripts/db_query.py --source doris --tables

# 内省表结构（实时 INFORMATION_SCHEMA，列名/类型/注释）
python scripts/db_query.py --source doris --schema ais_ship_track

# 只读查询（自动追加 LIMIT 1000，上限 5000，超限标记 truncated）
python scripts/db_query.py --source doris --sql "SELECT * FROM standard.ais_ship_track WHERE hull_no='CVN-72'"

# 指定返回行数上限
python scripts/db_query.py --source doris --sql "SELECT * FROM standard.ais_ship_track" --limit 100
```

输出为 JSON：`{"ok": true, "columns": [...], "rows": [...], "row_count": N, "truncated": false}`。
失败返回 `{"ok": false, "error": ...}` 且 exit code 1。

## SQL 查询注意事项

- 表名 `aircraft_ads-b_track` 含连字符，SQL 中必须用反引号包裹：`` `standard.aircraft_ads-b_track` ``
- 查询使用 `库名.表名` 格式（如 `standard.ais_ship_track`）
- 内省元数据（列含义）以 `--schema` 为准；业务判读规则按需读取 `schema/doris_*.md`

### 按时间范围查询

```bash
python scripts/db_query.py --source doris --sql "SELECT * FROM standard.ais_ship_track WHERE acquire_time >= '2026-01-01' AND acquire_time < '2026-07-01'"
```

### 按目标筛选

```bash
python scripts/db_query.py --source doris --sql "SELECT * FROM standard.ais_ship_track WHERE hull_no = 'CVN-72' ORDER BY acquire_time"
```

### 跨表关联查询

```bash
python scripts/db_query.py --source doris --sql "SELECT a.*, c.name, c.en_name, c.class, c.service_status FROM standard.ais_ship_track a JOIN standard.carrier_attribution c ON a.hull_no = c.hull_number WHERE a.acquire_time >= '2026-01-01' ORDER BY a.acquire_time"
```

### 查询表结构

```bash
python scripts/db_query.py --source doris --schema ais_ship_track
```
