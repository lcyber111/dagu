# HTML 大屏质量保障流程（构建脚本版）

大屏产出走三步：**写 spec → 构建脚本 → 验证**。spec 是智能体的唯一产出物，质量聚焦于 spec 与产物验证。

## 写 spec 时 — 7 项自检

1. ✅ `name` 为 kebab-case（小写字母/数字/连字符），产物在 `html/` 下
2. ✅ 必填字段齐全：`title`、`kpis`、`rows`、`charts`；rows 引用的 chart/table id 均存在
3. ✅ 图表类型在 6 类内（map/bar/line/pie/scatter/echarts）；**每张图的 data 均非空且形状合法**（bar/line 多序列必须 `legend` 且 `legend`/`colors` 长度等于序列数，见 `shared/html-output.md`）
4. ✅ `theme` 颜色为 #RRGGBB 十六进制；缺省即军绿
5. ✅ KPI `value` 使用数字或 `{text, sub}` 结构化，**禁止内嵌 HTML**；表格 `formatters` 仅用白名单（tag/color/bold/truncate）
6. ✅ 复杂图（力导向/多层覆盖）用 `echarts` 类型：能 JSON 表达的用 `option`；必须 JS 函数（如 tooltip formatter）时用 `js` 路径
7. ✅ 数据内的 `</script>` 等序列由构建脚本自动转义，无需自行处理
8. ✅ `style` 按任务性质选择合理（态势→command、评估→report-*、复盘→timeline、技术→terminal、参考→minimal，见 `shared/viz-dark-theme.md`）；style=report-*/timeline 时必须带对应结构且 blocks 引用 id 全部存在；timeline 阶段 `type`/`status` 可选，`color`/`status_color` 必须为 #RRGGBB
9. ✅ 富文本用声明式组件：`docs`（text 非空、color 为 #RRGGBB）与 `cards`（id 必填、meta 为 [label,value] 对），**禁止**把 HTML 塞进 `text` 单元格或手写 CSS

## 写后 — 验证流程

1. 运行构建：`python scripts/build_dashboard.py temp/dashboard_spec_<任务>.json`
   - 失败：根据 `[ERROR]` 提示修正 spec 后重跑（JSON 语法/结构/**数据形状**错误一次定位）
2. 运行验证：`python scripts/validate_html.py html/<文件名>.html`
   - 必须输出 `OK`。含三层：HTML 结构 + JS 语法 + **行为校验**（node 执行真实 builders → 数据形状断言 → ECharts SSR 渲染非空）
3. 用 `read` 抽查产物：主题色、图表容器 id、表格 tag 渲染是否符合预期

## 3 轮修正机制（适用于复杂图语义错误）

构建+验证能保证 JSON/结构/数据形状正确，但**语义错误**（如 `echarts` 的 `option` 配置无效、`js` 逻辑错误）仍需迭代：

- **优先用 `edit` 修正 spec**，重新构建 + 验证
- **最多修正 3 轮**，若 3 轮后仍不通过，向用户报告失败原因并询问修正方向

## 措辞预期

- **标准图表场景**（bar/line/pie/scatter/声明式 map/表格）：构建脚本按 JSON Schema 深度校验 + 行为校验，空数据/坏形状会被**当场拒绝**，不会产出空图
- **复杂场景**（力导向图、多层覆盖圈等 `echarts` 透传）：脚本负责接线与校验，option/js 本体仍由智能体编写，语义错误需迭代修正
