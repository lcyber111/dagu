# HTML 大屏构建流程（构建脚本）

所有分析结果必须以 HTML 大屏形式输出，**一律使用构建脚本生成，禁止手写 HTML**。

## 标准流程（三步）

```
1. 写 spec JSON   → temp/dashboard_spec_<任务>.json   （声明式配置，见下）
2. 构建           → python scripts/build_dashboard.py temp/dashboard_spec_<任务>.json
3. 验证           → python scripts/validate_html.py html/<文件名>.html   → OK
```

spec 的 `name` 决定输出文件名（kebab-case，如 `carrier-ais-20260728`），产物写入 `html/`。

> **契约唯一来源**：spec 的合法结构以 `templates/dashboard-spec.schema.json`（JSON Schema）为准，
> 构建脚本按它做深度校验，格式非法会**当场报错**（不再静默生成空图）。
> 本文件只做速查，与 Schema 冲突时以 Schema 为准；示例见 `templates/dashboard-spec-*.json`。

## spec 结构速查

| 字段 | 类型 | 说明 |
|------|------|------|
| `name` | string | 输出文件名（kebab-case），必填 |
| `title` | string | 页眉主标题，**一律中文**（H1 大标题），必填 |
| `subtitle` | string | 可选，中文副标题（H1 下一行小字） |
| `time` / `refresh` | string/int | 分析时间 / 自动刷新秒数（可选） |
| `header_icon` | string | FontAwesome 图标类，如 `fas fa-satellite` |
| `theme` | object | 可选 `{primary, background}`（#RRGGBB），缺省军绿；`primary` 自动派生 border/soft/hover 色。**仅对 `style=command` 生效** |
| `style` | string | 布局+视觉预设，缺省 `command`；六值及选择规则见 `shared/viz-dark-theme.md`，按任务性质自动选 |
| `report` | object | style=report-light/report-dark 时必填：`{summary, sections:[{title, blocks:[{text}|{chart:id}|{table:id}|{row:[id…]}]}], conclusion}` |
| `timeline` | object | style=timeline 时必填：`{phases:[{time, heading, text, blocks:[…]}]}` |
| `kpis[]` | array | `{label, value, color, sub}`，value 可为数字或 `{text, sub}`；**≥6 个时自动启用紧凑模式（缩字号）** |
| `rows[]` | array | 布局声明：`{grid, cells}`，cell 为 `{chart:id}` / `{table:id}` / `{stack:[id,id]}` / `{text}` / `{docs:[…]}` / `{cards:{…}}`。**仅网格布局（command/terminal/minimal）使用** |
| `charts[]` | array | 图表声明，6 类见下 |
| `tables[]` | array | 表格声明 `{title, id, columns, rows, formatters, maxHeight}` |
| `footer[]` | array | `{label, value}` 页脚数据来源 |

## 图表类型（6 类）

| type | 声明字段 | 典型场景 |
|------|---------|---------|
| `map` | `geo`(center/zoom)、`markers`+`categories`（多类别标记/effect/label/逐类tooltip/legendName）、`circles`（覆盖圈）、`lines`（轨迹/打击路径）；图例由脚本按实际 series 自动生成（`categories[].legendName` 控制显示名），`legend` 仅按需覆盖 | 态势地图 |
| `bar` / `line` | `data{ categories, values, unit, colors, legend, rotate, area }`，values 支持单序列与多序列（见下） | 对比/趋势 |
| `pie` | `data{ values[{name,value,color}], radius, label, colors }` | 分布 |
| `scatter` | `data{ values[[x,y]], xName, yName, color }` | 散点 |
| `echarts` | `option`（JSON-safe）或 `js`（原始脚本，需 JS 函数时用） | 力导向图等复杂图 |

### bar / line 的 values：单序列 vs 多序列

`data.values` 有两种合法形态，`colors`/`legend` 语义随形态变化：

| 形态 | values 写法 | colors 语义 | legend 语义 |
|------|------------|------------|------------|
| 单序列 | 一维数字数组 `[16, 6, 16, ...]` | **逐柱/逐类别配色**（长度须等于 categories，否则报错） | 不填（单序列无需图例） |
| 多序列 | 二维数字数组 `[[16,6,...],[16,6,...]]` | **逐序列配色**（长度须等于序列数，否则报错） | **必填**，长度为序列数，作为各序列图例名 |

```
单序列: "data": {"categories": ["F-35A","F-35B"], "values": [2220, 1670],
                 "unit": "km", "color": "#00ff88"}                      // color=单色
        或 "colors": ["#4488ff","#00cc88",...]                           // colors=逐柱
多序列: "data": {"categories": ["F-35A","F-35B"], "values": [[2220,1670],[1420,1800]],
                 "legend": ["F-35","F-16"], "colors": ["#00ff88","#ffd93d"]}
```

`line` 的 `area: true` 启用面积填充；`rotate` 控制柱状 x 轴标签旋转角度。

### 富文本组件（docs / cards，声明式，免手写 HTML/CSS）

替代把 HTML 塞进 `text` 单元格的做法，由共享 CSS 统一渲染（主题自动跟随 preset）：

- **`docs` 文本块**（判据/结论/分节说明）：左色条 + 标题 + 右侧 tag + 正文，多条同卡等高
  - 网格布局单元格：`{"docs":[{"title":"研判结论","color":"#3b9eff","tag":"支撑判据：C13","text":"正文…"},…]}`
  - report/timeline blocks：`{"doc":{…}}`（单条）或 `{"docs":[…]}`（堆叠）
- **`cards` 实体卡片**（目标/实体清单）：照片 + 属性元数据，自适应换行
  ```json
  {"cards": {"title": "目标基本属性",
     "items": [
       {"id": "UAV-B001", "role": "编队长机", "color": "#ff4d4f",
        "photo": {"src": "uav-b001.jpg", "note": "本地实拍照片"},
        "meta": [["机型", "DJI M350"], ["报备状态", "无报备", "#ff4d4f"]]}
     ]}}
  ```
  - `layout`（可选）：`vertical`（默认，照片在上/信息在下）或 `horizontal`（照片左约 30%/信息右，复刻存量 uav-card 布局）
  - 照片缺失自动显示通用占位（`fa-image` + "本地照片缺失"），无需手写 SVG
- 校验：`docs[].text` 非空、`color` 为 #RRGGBB；`cards.items[].id` 必填、`meta` 为 `[label,value]`（可选第三元颜色）对数组、`photo.src` 非空

### 布局样式（style 预设）

大屏支持 6 种预设（布局+视觉），由 `spec.style` 指定，智能体按任务性质自动选（规则见 `shared/viz-dark-theme.md`）。

- `command`/`terminal`/`minimal`（网格布局）：沿用 `rows[]` 组织行/单元格，仅视觉不同
- `report-light`/`report-dark`（文书报告）：用 `report` 结构代替 `rows`

```json
"report": {
  "summary": "执行摘要文字……",
  "sections": [
    {"title": "一、总体概况",
     "blocks": [
       {"text": "段落文字……"},
       {"row": ["chartA", "chartB"]},
       {"table": "tab1"}
     ]}
  ],
  "conclusion": "结论文字……"
}
```

  blocks 每项四种：`text`（段落）/ `chart`（单图）/ `table`（单表）/ `row`（并排多图，值为已声明的 chart/table id）
- `timeline`（时间线）：用 `timeline` 结构代替 `rows`；阶段支持 `type`（阶段类型，marker 圆点变色 + 类型 pill + 顶部自动图例）、`status`（状态 tag，`●` 前缀，缺省按关键词映射颜色：高危/异常→红、关注/较高/警戒→橙、正常/恢复/成功→绿、未知/静默→灰，可用 `status_color` 显式覆盖）、`color`（可选，指定该类型颜色，缺省按调色板自动分配）

```json
"timeline": {"phases": [
  {"time": "2026-07-20 08:00", "heading": "阶段一：抵近", "type": "发现", "status": "关注",
   "text": "正文……", "blocks": [{"chart": "c1"}, {"table": "t1"}]}
]}
```

- report/timeline 的 blocks 引用的 chart/table id 必须已声明于 `charts[]`/`tables[]`（悬空引用构建时报错）
- 完整示例见 `templates/dashboard-spec-report-light-example.json` / `templates/dashboard-spec-report-dark-example.json` / `templates/dashboard-spec-timeline-example.json`

### 数据形状不变量（构建时校验，违反即报错）

- bar/line：`categories`、`values` 必填且非空；多序列时 `legend` 必填、`colors`/`legend` 长度须等于序列数；所有数值须为数字
- pie：`values` 非空，每项须含数字 `value`
- scatter：`values` 非空，每项为 `[x, y]` 数字对
- map：`markers`/`circles`/`lines` 可选；`circles[].center` 为 `[lng, lat]`，`radiusKm` 必填；**`geo` 必须含 `center` + `zoom`**（缺任一则 ECharts SSR 渲染失败，行为校验会报错）
- 所有图表 id 全局唯一；rows/cells 引用到的 id 必须真实存在（引用悬空即报错）

### 地图图例与类别规范（2026-08-07）

图例由 builder 按实际 series 自动生成，**icon 反映类别形状 / 线型 / 圆环，颜色与地图一致**（无需手配 icon）。

- **不同类别建议不同 `symbol`**（地图图例标准：类型用图形区分，不靠颜色）：
  - 航母/核心目标 → `pin`（图钉，醒目）
  - 基地/设施 → `rect`（方块）
  - 部队/舰艇等 → `diamond`（菱形）
  - 演习区/事件 → `circle`（圆）
- **航线 `lines` 建议带 `effect` 轨迹运动**（`{period, trailLength, symbol, symbolSize}`，图例显示斜线段 icon）
- **覆盖圈 `circles`** 图例显示圆环 icon
- **避免 `categories[].effect: true` 波纹扩散**（视觉噪，效果差于航线轨迹运动；确需强调单点可用，不建议整类开启）
- `categories[].legendName` 控制图例显示名；`legend` 仅按需覆盖
- 示例分配（美日同盟图）：航母=pin、驻日/关岛基地=rect、日本自卫队=diamond、联合行动/演习区=circle

**`echarts` 类型的 `js` 路径**：脚本提供容器 `dom` 变量，agent 在其中自行 `echarts.init(dom)` → `setOption` → 注册 resize；脚本负责 try/catch 错误边界与 node --check 语法校验。构建脚本会转义 `</script` 与 `<!--`，agent 无需特殊处理。

## 表格交互字段（渐进增强）

`tables[]` 声明式字段，浏览器端增强（无 JS 时仍是静态表）：

| 字段 | 类型 | 效果 |
|------|------|------|
| `searchable` | boolean | 搜索框，任意列子串匹配 |
| `sortable` | boolean | 列头点击排序（数字/中文智能比较） |
| `pageSize` | int ≥1 | 分页，每页行数 |

**自动阈值**：`searchable/sortable` **缺省按行数自动判定**——`rows ≥ 50` 时自动启用；小表缺省不启用。显式布尔可覆盖：
- `"searchable": true` → 强制开启（即使小表）
- `"searchable": false` → 强制关闭（即使大表）
- `pageSize` 仅显式声明（不做自动分页）

> formatter 单源：交互只操作 DOM 节点（移动 `<tr>`），不重新渲染 formatter，杜绝 JS/Python 双份 formatter 漂移。

## 参考大屏资产库（references/）

精调过的高质量大屏沉淀于 `references/`，作为智能体生成同类大屏的**参考模板（优先级高于从零设计）**：

- 每个资产 = `references/<id>/` 目录：`layout-spec.json`（布局骨架，可复用）+ `reference.html`（视觉对照）+ `meta.json`（任务类型/场景标签/优先级）
- **参考优先**：生成大屏前先读 `references/README.md` 索引，按任务类型+场景标签匹配，命中则参照布局骨架与视觉生成"差不多"的大屏；未命中才从零设计（见 `shared/analysis-runtime.md` Step 3.5）
- **入库**：`python scripts/import_reference.py html/<name>.html --id <id> --title "<标题>" [--task-types ...] [--tags ...] [--priority gold|normal]`（反向提取 spec + 生成三件套 + 更新索引）

## 视觉与资源

- 主题 CSS / 渲染引擎已固化：`lib/dashboard/dashboard.css` + `lib/dashboard/dashboard.js`，spec 无需也不应复写样式
- 图表构建逻辑在 `lib/dashboard/chart-builders.js`（浏览器与 `scripts/check_dashboard.py` 共用同一份代码，杜绝契约漂移）
- `theme` 决定领域主色；领域色表见 `shared/viz-dark-theme.md`
- 新流程统一使用 ECharts（`lib/echarts/` + `lib/echarts-maps/world.js`）；`lib/chartjs/` 保留但仅存量文件维护使用，新产出不引用
- 页面资源引用：FontAwesome + ECharts + world.js + chart-builders + dashboard 均来自平台共享 `lib/`（App Worker 下用**相对路径** `lib/...` 引用，构建时 `LIB_BASE=lib/`）
- 禁止引用任何 CDN/外部 URL

## 质量保障（三层防线）

```
写 spec ──▶ build_dashboard.py 按 JSON Schema 深度校验（格式错当场报错）
          ──▶ validate_html.py = 结构 + JS 语法 + ★行为校验（node 执行真实 builders→
                                  数据形状断言→ECharts SSR 渲染非空）
          ──▶ 浏览器：dashboard.js 构建失败渲染红条（失败显性化，不再静默空图）
```

行为校验由 `scripts/check_dashboard.py` 承担：与浏览器用**同一份** `chart-builders.js` 构建每个图表，
校验数据形状（空数据/坏结构必然 FAIL），再用 ECharts 5.5 SSR 真实渲染确认非空。
`echarts`+`js` 型图表无法通用执行，仅做 JS 语法检查（构建脚本会转义 `</script` 与 `<!--`）。

## 命名规范

文件名 kebab-case，如 `html/carrier-aircraft-20260625.html`，不要用中文或空格。

每个大屏配套 `<name>.md` 分析设计说明（需求/数据/逻辑，**不讲页面**），模板与写作规范见 `shared/md-report.md`，校验见 `scripts/check_md_report.py`。
