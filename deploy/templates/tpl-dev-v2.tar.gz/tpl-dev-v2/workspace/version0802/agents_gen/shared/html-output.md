# HTML 大屏构建流程（构建脚本）

所有分析结果必须以 HTML 大屏形式输出，**一律使用构建脚本生成，禁止手写 HTML**。

## 标准流程（三步）

```
1. 写 spec JSON   → temp/dashboard_spec_<任务>.json   （声明式配置，见下）
2. 构建           → python scripts/build_dashboard.py temp/dashboard_spec_<任务>.json
3. 验证           → python scripts/validate_html.py html/<文件名>.html   → OK
```

spec 的 `name` 决定输出文件名（kebab-case，如 `carrier-ais-20260728`），产物写入 `html/`。

> **契约唯一来源**：spec 的合法结构以 `templates/dashboard-spec.schema.json`（JSON Schema）为准，
> 构建脚本按它做深度校验，格式非法会**当场报错**（不再静默生成空图）。
> 本文件只做速查，与 Schema 冲突时以 Schema 为准；示例见 `templates/dashboard-spec-*.json`。

## spec 结构速查

| 字段 | 类型 | 说明 |
|------|------|------|
| `name` | string | 输出文件名（kebab-case），必填 |
| `title` | string | 中文标题，必填 |
| `title_en` / `subtitle` | string | 可选，标题栏英文/副标题 |
| `time` / `refresh` | string/int | 分析时间 / 自动刷新秒数（可选） |
| `header_icon` | string | FontAwesome 图标类，如 `fas fa-satellite` |
| `theme` | object | 可选 `{primary, background}`（#RRGGBB），缺省军绿；`primary` 自动派生 border/soft/hover 色 |
| `kpis[]` | array | `{label, value, color, sub}`，value 可为数字或 `{text, sub}` |
| `rows[]` | array | 布局声明：`{grid, cells}`，cell 为 `{chart:id}` / `{table:id}` / `{stack:[id,id]}` |
| `charts[]` | array | 图表声明，6 类见下 |
| `tables[]` | array | 表格声明 `{title, id, columns, rows, formatters, maxHeight}` |
| `footer[]` | array | `{label, value}` 页脚数据来源 |

## 图表类型（6 类）

| type | 声明字段 | 典型场景 |
|------|---------|---------|
| `map` | `geo`(center/zoom)、`markers`+`categories`（多类别标记/effect/label/逐类tooltip/legendName）、`circles`（覆盖圈）、`lines`（轨迹/打击路径）；图例由脚本按实际 series 自动生成（`categories[].legendName` 控制显示名），`legend` 仅按需覆盖 | 态势地图 |
| `bar` / `line` | `data{ categories, values, unit, colors, legend, rotate, area }`，values 支持单序列与多序列（见下） | 对比/趋势 |
| `pie` | `data{ values[{name,value,color}], radius, label, colors }` | 分布 |
| `scatter` | `data{ values[[x,y]], xName, yName, color }` | 散点 |
| `echarts` | `option`（JSON-safe）或 `js`（原始脚本，需 JS 函数时用） | 力导向图等复杂图 |

### bar / line 的 values：单序列 vs 多序列

`data.values` 有两种合法形态，`colors`/`legend` 语义随形态变化：

| 形态 | values 写法 | colors 语义 | legend 语义 |
|------|------------|------------|------------|
| 单序列 | 一维数字数组 `[16, 6, 16, ...]` | **逐柱/逐类别配色**（长度须等于 categories，否则报错） | 不填（单序列无需图例） |
| 多序列 | 二维数字数组 `[[16,6,...],[16,6,...]]` | **逐序列配色**（长度须等于序列数，否则报错） | **必填**，长度为序列数，作为各序列图例名 |

```
单序列: "data": {"categories": ["F-35A","F-35B"], "values": [2220, 1670],
                 "unit": "km", "color": "#00ff88"}                      // color=单色
        或 "colors": ["#4488ff","#00cc88",...]                           // colors=逐柱
多序列: "data": {"categories": ["F-35A","F-35B"], "values": [[2220,1670],[1420,1800]],
                 "legend": ["F-35","F-16"], "colors": ["#00ff88","#ffd93d"]}
```

`line` 的 `area: true` 启用面积填充；`rotate` 控制柱状 x 轴标签旋转角度。

### 数据形状不变量（构建时校验，违反即报错）

- bar/line：`categories`、`values` 必填且非空；多序列时 `legend` 必填、`colors`/`legend` 长度须等于序列数；所有数值须为数字
- pie：`values` 非空，每项须含数字 `value`
- scatter：`values` 非空，每项为 `[x, y]` 数字对
- map：`markers`/`circles`/`lines` 可选；`circles[].center` 为 `[lng, lat]`，`radiusKm` 必填；**`geo` 必须含 `center` + `zoom`**（缺任一则 ECharts SSR 渲染失败，行为校验会报错）
- 所有图表 id 全局唯一；rows/cells 引用到的 id 必须真实存在（引用悬空即报错）

**`echarts` 类型的 `js` 路径**：脚本提供容器 `dom` 变量，agent 在其中自行 `echarts.init(dom)` → `setOption` → 注册 resize；脚本负责 try/catch 错误边界与 node --check 语法校验。构建脚本会转义 `</script` 与 `<!--`，agent 无需特殊处理。

## 视觉与资源

- 主题 CSS / 渲染引擎已固化：`lib/dashboard/dashboard.css` + `lib/dashboard/dashboard.js`，spec 无需也不应复写样式
- 图表构建逻辑在 `lib/dashboard/chart-builders.js`（浏览器与 `scripts/check_dashboard.py` 共用同一份代码，杜绝契约漂移）
- `theme` 决定领域主色；领域色表见 `shared/viz-dark-theme.md`
- 新流程统一使用 ECharts（`lib/echarts/` + `lib/echarts-maps/world.js`）；`lib/chartjs/` 保留但仅存量文件维护使用，新产出不引用
- 离线资源引用：FontAwesome（`../lib/fontawesome/`）+ ECharts + world.js + chart-builders + dashboard，均本地路径，双击可运行
- 禁止引用任何 CDN/外部 URL

## 质量保障（三层防线）

```
写 spec ──▶ build_dashboard.py 按 JSON Schema 深度校验（格式错当场报错）
          ──▶ validate_html.py = 结构 + JS 语法 + ★行为校验（node 执行真实 builders→
                                  数据形状断言→ECharts SSR 渲染非空）
          ──▶ 浏览器：dashboard.js 构建失败渲染红条（失败显性化，不再静默空图）
```

行为校验由 `scripts/check_dashboard.py` 承担：与浏览器用**同一份** `chart-builders.js` 构建每个图表，
校验数据形状（空数据/坏结构必然 FAIL），再用 ECharts 5.5 SSR 真实渲染确认非空。
`echarts`+`js` 型图表无法通用执行，仅做 JS 语法检查（构建脚本会转义 `</script` 与 `<!--`）。

## 命名规范

文件名 kebab-case，如 `html/carrier-aircraft-20260625.html`，不要用中文或空格。
