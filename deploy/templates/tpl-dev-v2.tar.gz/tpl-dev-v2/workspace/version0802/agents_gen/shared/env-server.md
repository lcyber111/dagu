# 服务器配置

Web 大屏通过 `scripts/serve_html.py` 提供访问。**每次生成 HTML 后必须启动该服务**，再从中取对外链接汇报。

## 启动服务（强制步骤）

生成 HTML 落盘到 `html/` 后，执行：

```bash
python3 scripts/serve_html.py
```

- 服务自动监听 `0.0.0.0`（OCC2 规范，允许中央网关跨网络代理），端口取环境变量 `PORT`（未设置则取代理基址端口，默认 9088）。
- 启动日志会打印 `对外访问` / `大屏列表` / `大屏示例` 三行——**从 `大屏示例` 那行提取当前大屏的完整链接**，直接汇报给用户，不要自行拼接。
- 服务仅开放 `html/` 与 `lib/` 白名单路径（防泄露 `config/`、`.opencode/`、`schema/` 等敏感目录）。

## 对外 URL 规则

```
{代理基址}/app-proxy/{侦听端口}/html/{文件名}
```

代理基址来自环境变量 `APP_PROXY_BASE_URL`（OCC2 网关注入，形如 `http://IP:9088/app-proxy`），其次 `PUBLIC_BASE_URL`（形如 `http://IP:9088`），最后回退 `config/server.json` 的 `baseUrl`。

例：`APP_PROXY_BASE_URL=http://106.63.8.234:9088/app-proxy`、侦听端口 `9088` 时：

```
http://106.63.8.234:9088/app-proxy/9088/html/carrier-cvn73-westpac-20260801.html
```

## 拼接 baseUrl（供脚本校验，汇报以服务输出为准）

如需手动核对 baseUrl（`代理基址 + /app-proxy/<端口>`）：

```bash
# 跨平台（Windows PowerShell / Linux bash 均可用，依赖 python3）
$base = $(python3 -c "import os; print((os.environ.get('APP_PROXY_BASE_URL') or os.environ.get('PUBLIC_BASE_URL') or '').rstrip('/'))")
$port = $(python3 -c "import os; print(int(os.environ.get('PORT') or 9088))")
$url = "$base/app-proxy/$port"
```

若环境变量均未设置，回退读取 `config/server.json` 的 `baseUrl`（仅取主机部分），端口沿用上面规则：

```bash
$url = $(python3 -c "
import json, os
base = (os.environ.get('APP_PROXY_BASE_URL') or os.environ.get('PUBLIC_BASE_URL') or '').rstrip('/')
if not base:
    base = json.load(open('config/server.json'))['baseUrl'].rstrip('/')
port = int(os.environ.get('PORT') or 9088)
print(f'{base}/app-proxy/{port}')
")
```

最终汇报链接为 `$url/html/<文件名>`（HTML 文件统一输出到 `html/` 目录）。

注：服务监听端口与代理基址来自环境变量（多租户部署由网关注入），无环境变量时回退 `config/server.json`，无需告知用户技术细节。
