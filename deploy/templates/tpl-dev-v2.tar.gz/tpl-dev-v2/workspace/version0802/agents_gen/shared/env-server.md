# 服务器配置

**新生成的大屏一律走 App Worker 流程（页面 + 数据接口 + SQLite 的微服务），自动进入生成物门户（/portal 右侧卡片）。**

## App Worker 大屏（唯一流程）

新生成的大屏 = 宿主机 workerd 内的独立 App Worker 微服务（页面 + 数据接口 + 每版本独立 SQLite），自动出现在「生成物门户」右侧卡片。

### 目录约定（容器内视角；宿主机对应 `users/<uid>/workspace`）

- 注册表：`/workspace/.apps/apps.json`
- 每个大屏：`/workspace/.apps/<appId>/`
  - `<version>.js`（worker，首个版本 `v1.js`；新版本另存 `v2.js`，不覆盖旧版本）
  - `www/`（页面资产，`index.html` 起步，**改文件即时生效**；图片等静态文件放 `www/uploads/`，按相对路径 `uploads/<文件名>` 引用）
  - 数据按版本自动隔离（`data-<version>` SQLite，无需手动建）
- 脚手架：`templates/app-scaffold/worker.js.tpl`（复制为 `v1.js` 后按业务修改）；示例页面 `templates/app-scaffold/www/index.html`、注册表示例 `templates/app-scaffold/apps.json.example` 同目录

### 固定流程

1. **生成页面**：按 `shared/html-output.md` 用 `build_dashboard.py` 构建 HTML，**必须以 `LIB_BASE=lib/` 构建**（相对路径，页面在 `/app/<port>/` 下会正确解析到 worker 的 lib 路由；禁止用根绝对路径 `/lib/...`，网关不会路由它）：

   ```bash
   LIB_BASE=lib/ python3 scripts/build_dashboard.py temp/dashboard_spec_<任务>.json
   python3 scripts/validate_html.py html/<文件名>.html   # 验证通过后继续
   ```

   产物放入 `/workspace/.apps/<appId>/www/index.html`。页面内嵌 `DASHBOARD_SPEC` 数据即可；需要运行期实时拉数据时再改调 `/svc/data`。

2. **写 worker**：复制脚手架为 `/workspace/.apps/<appId>/v1.js`，按需修改表结构/接口。

3. **登记注册表** `/workspace/.apps/apps.json`：`id`、`port`（20000-29999 唯一）、`defaultVersion`、`versions`，以及门户元数据 `title`（必填）、`description`、`createdAt`、`type`（默认 dashboard）。

3.5 **修正属主（容器以 root 运行，宿主机发布进程是 uid 1000；不执行则发布报 PermissionError）**：

   ```bash
   chown -R 1000:1000 /workspace/.apps
   ```

4. **发布**（容器内无 curl，用 python3；uid 取自环境变量 `WS_USER`，否则 `config/server.json` 的 `uid`）：

   ```python
   python3 - <<'PY'
   import json, urllib.request, os
   cfg = json.load(open("config/server.json"))
   gw = cfg["baseUrl"].rstrip("/")
   uid = os.environ.get("WS_USER") or cfg.get("uid")
   assert uid, "无法确定 uid"
   opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
   opener.open(gw + "/portal/u/" + uid)               # 建立会话 Cookie
   req = urllib.request.Request(
       gw + "/app/v1/sync",
       data=json.dumps({"payload": {"uid": uid}}).encode(),
       headers={"Content-Type": "application/json"}, method="POST")
   print(opener.open(req, timeout=15).read().decode())
   PY
   ```

5. **验证**（必须输出含 `"ok": true` 才允许汇报）：

   ```python
   python3 - <<'PY'
   import json, urllib.request, os
   cfg = json.load(open("config/server.json"))
   gw = cfg["baseUrl"].rstrip("/")
   uid = os.environ.get("WS_USER") or cfg.get("uid")
   opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
   opener.open(gw + "/portal/u/" + uid)
   print(opener.open(gw + "/app/<port>/svc/health", timeout=10).read().decode())
   PY
   ```

6. **direct 测试新版本**：`{baseUrl}/app/<port>/svc/health?version=v2`；通过后改 `apps.json` 的 `defaultVersion` 切默认（零重启）。

7. **汇报**：主推大屏链接 `{baseUrl}/app/<port>/`，附门户入口 `{baseUrl}/portal`。

### 接口约定（worker 脚手架内置）

- `/` 页面；`/svc/health` 探活；`/svc/spec`（GET 读取 / POST 写入大屏 spec，快照唯一数据源）；
  `/svc/events`（SSE 实时推送：页面 EventSource 订阅，spec 更新后自动重绘）
- 页面共享资源走相对路径 `lib/...`（worker 内解析为平台 app-libs：echarts / fontawesome / dashboard.css 等）
- `www/` 内非首页静态文件（图片等）按相对路径直接访问（worker 静态路由）

## 禁止外网请求（硬性规则）

轻应用（`v1.js`/`v2.js` worker 与页面 JS）**一律不得发起任何外网请求**：

- **禁止** `fetch`/`XMLHttpRequest`/`WebSocket` 等请求任何外部地址（公网 IP、域名、`106.63.8.234` 等）
- **禁止**引用外部 CDN / 外部静态资源 / 外部 API
- **允许**：平台内部 workerd service binding（`http://lib`、`http://files` 等内部地址）、页面同应用相对路径（`lib/`、`uploads/`、`/svc/...`）、网关同域接口（`{baseUrl}` 下的 `/app/v1/*` 与 `/api/v1/*`）
- **数据来源仅限**：应用自身 SQLite（DO 存储）、页面内嵌数据、或经平台 `scripts/db_query.py` 只读网关取数后注入
- 发布前自查：worker 与页面中除 `http://lib`、`http://files`、`http://internal` 等内部绑定外，不得出现任何外部 `http(s)://` 引用；违反视为交付失败

## 生成物门户（/portal）

- 门户入口：`{baseUrl}/portal`（带会话 Cookie；无 Cookie 时先访问 `{baseUrl}/portal/u/<uid>`），左侧对话 + 右侧生成物切换展示
- 生成物元数据：title（必填）、description、createdAt、type（默认 dashboard）
- 汇报主推大屏链接，附工作台入口

## 修改现有大屏（门户联动）

- 用户在门户点选卡片后，系统写 `/workspace/.apps/.selected`（JSON：`{"id": ..., "ts": ...}`）
- **修改类指令第一步必读 `/workspace/.apps/.selected` 确认目标**：用户未点名时一律以选中项为准，**禁止猜测**；`.selected` 缺失或与用户点名冲突时读 `apps.json` 列候选请用户确认
- **动手前先在回复中明示目标**（如"将修改 carrier-global-v4 的标题为 Test"），用户可据此判断是否正确
- **禁止直接编辑 `/workspace/.apps/<appId>/`**（生成新应用除外）；修改必须经平台接口，**目标由平台按 `.selected` 强制**（agent 传参无效）：
  - **大屏内容/标题（统一走 spec）**：把修改后的完整 spec JSON 写入 `temp/modify-spec.json`，
    调用 `POST /app/v1/apply/spec`（body 直接传 spec 或 `{"spec": ...}`；平台按 `.selected`
    强制目标 app，结构校验后写库 + SSE 广播，页面自动重绘）。HTML 骨架生成时已定稿，不再单独改。
  - 用户明确点名其他 app 时，先把 `.selected` 写为目标 app（`{"id": "<appId>", "ts": <当前秒>}`）再调用
- 平台返回实际应用的 appId 后汇报新链接；页面改动即时生效，门户自动刷新预览
- **门户建议保持单一标签页**：多标签页同时打开时，各页自动选中可能互相覆盖 `.selected`（现在自动选中不再写 `.selected`，仅用户点击写入）

## 图片

- 图片放入 `/workspace/.apps/<appId>/www/uploads/`，页面用相对路径 `uploads/<文件名>` 引用（worker 静态路由自动服务）
- `photo.src` 指向的文件缺失时，大屏显示"本地照片缺失"占位；文件已存在时刷新即显示
