# 运行时 SOP（统一执行流程，全垂域共用）

> 本文件是**全垂域统一的运行时 SOP**，由 persona 执行任务前直读。**必须完整、按序执行，不得省略步骤。**
> 领域差异（信息提取 / 数据源路由 / 大屏布局 / 分析模式 / 默认偏好）由 persona 各段落承载，
> 本文件通过引用对应段落标题获取（如"本 persona『信息提取规则』段落"）。

**语言规范**：所有面向用户的输出与执行说明一律使用**中文**；仅技术标识（SQL / 字段名 / 模块名 / 专有名词）保留英文。

## Step 1: 需求理解（智能提取 + 按需追问）

### 任务类型判断

先判断指令类型，决定行为路径：

- **纯问答类**（指令仅为提问，不涉及生成/展示）→ 直接回答，无需追问
- **生成/分析类**（涉及分析数据、生成HTML、对比数据等）→ 进入信息提取流程

**混合指令处理**（如"数据是什么？生成一张图"）：按生成类处理——先回答问答部分，再追问生成所需的细节。

### 信息提取规则

从用户指令中尝试提取 目标 / 区域 / 时间范围 / 分析深度 / 关注维度 等要素。提取项、关键词示例与默认值见**本 persona「信息提取规则」段落**；若 persona 无该段落，目标与区域从指令推断，时间范围用最近可查数据，深度取 persona「默认配置偏好」。

### 追问决策逻辑（专家式决定性提问，稀疏触发）

按四种问题类型设计追问（规则澄清 / 范围收窄 / 缺口提醒 / 偏好确认），**判定标准：一个问题若回答后不影响本次注入/过滤/形态，就不该问**。规则：**用户显式给过的信息提取，不反问；缺失到影响正确性或与默认冲突才问；带默认选项，"你看着办"即默认**。**输出形态默认大屏（内嵌清单），不问**（7 号输出类型化后再按 app_type 问）。

```
如果 目标 + 区域 都缺失 → 问范围（带默认：特定目标/特定区域/全局）
如果 目标 已指定、区域 缺失 → 不问，默认使用目标所在区域
如果 区域 已指定、目标 缺失 → 不问，默认覆盖该区域所有目标
如果 目标 + 区域 都已有 → 跳过范围问题
如果 时间范围 缺失 → 问一次（带默认：近半年/近一年/全历史），
      除非 persona「信息提取规则」已显式声明默认时间窗口（则用默认不问）
如果 分析深度 已明确 → 跳过深度问题；缺失 → 问深度（带默认：智能研判）
如果 判定参数（阈值/窗口/判据）与默认不同会显著改变结果且用户未给
      → 问一次（带默认，参数读 rag/*_kb.md 真实阈值）   ← 规则澄清
如果 用户显式给了判定规则/阈值 → 提取写入本次分析参数，不反问  ← 规则提取优先
如果 关键维度遗漏（数据来源/静默处理/配属判据）→ 缺口提醒
如果 以上都齐 → 完全跳过追问，直接执行
```

### 可能的追问（按需选择，不要全问）

**缺失范围时：**
```
question:
  header: "关注范围"
  question: "关注的地理范围是哪里？"
  options:
    - label: "特定目标"
      description: "聚焦某个具体目标深入分析"
    - label: "特定区域"
      description: "如南海、中东、印太"
    - label: "全局/全域"
      description: "大范围宏观态势"
```

**缺失时间范围时：**
```
question:
  header: "时间范围"
  question: "分析的时间范围是？"
  options:
    - label: "最新状态"
      description: "只看当前最新位置和状态"
    - label: "近半年"
      description: "最近6个月的活动分析"
    - label: "近一年"
      description: "最近12个月的规律分析"
    - label: "全历史"
      description: "自数据可查以来的完整分析"
```

**缺失分析深度时：**
```
question:
  header: "分析深度"
  question: "分析到哪个深度？"
  options:
    - label: "基础呈现"
      description: "数据如实呈现——标注位置、显示状态、不加研判"
    - label: "特征分析"
      description: "自动提取特征——分类统计、对比分析、趋势识别"
    - label: "智能研判"
      description: "全面研判——状态判定、意图分析、威胁评估"
```

**规则澄清（判定参数与默认冲突或未给时，引用本域 KB 真实阈值）：**
```
question:
  header: "判定规则"
  question: "判定参数按哪个？（默认：{KB 真实阈值}，如 AIS 关闭 24h/窗口 6 个月；舰载机关联 <50km/<200ft）"
  options:
    - label: "按默认值"
      description: "采用领域标准阈值（{具体默认值}）"
    - label: "自定义"
      description: "我指定阈值/窗口/判据"
```
> 用户显式给过判定规则/阈值 → 直接提取写入本次参数，不反问（如"AIS关3天以上才算异常" → 阈值取 72h，不问）。

**如果用户说"你看着办" → 采用本 persona「默认配置偏好」的默认配置。**

### 数据源路由规则

按**本 persona「数据源路由规则」段落**中的关键词规则自动判断使用哪个数据源/表；若 persona 无该段落，结合其「数据库数据源」与「领域知识库」判断。

**跨源关联**：如果指令同时涉及多个数据域，同时连接对应数据源进行交叉分析。

## Step 2: 数据获取

按以下优先级搜集数据：

1. **本地情报文件** — 优先读取本 persona「领域知识库」中列出的 `rag/*.md` 知识库与「字段参考文档」中的 `schema/*.md` 判读规则
2. **Doris 数据库** — 如离线情报不够，经统一只读网关查询实时数据（`python scripts/db_query.py --source doris --sql "SELECT ..."`，见 `shared/db-doris.md`）
3. **MySQL 目标情报库** — 当指令涉及对应域关键词时（`python scripts/db_query.py --source mysql_gf --sql "SELECT ..."`，见 `shared/db-mysql.md`）

> 严格离线环境：无 websearch/webfetch，情报仅来自本地知识库与数据库，数据不足时如实标注"数据缺失"。

**字段参考**：需要理解字段时用网关内省 `python scripts/db_query.py --source <源> --schema <表名>`，或读取本 persona「字段参考文档」中列出的 `schema/*.md` 判读规则。

## Step 3: 分析与开发

### 3.1 数据加载与预处理

**前置：数据探索三步**（套用任何阈值/间隔规则前必须先做；条件触发，成本受控）：

1. **目标全集确认**（分析对象为有限实体集合时）：分析对象 = 画像/注册表声明的集合 ∪ 数据实际出现（`SELECT DISTINCT <主键> FROM <表> WHERE <时间窗>`，经网关）。防止只按文档集合漏掉真实对象（案例：CVN-79 在建舰不在 carrier_attribution，但 AIS 有真实信号）。
2. **源分布甄别**（判读规则提示多来源混合，或表含 source 类字段时）：`GROUP BY <source>` 看分布 → 识别**快照型源**（时间戳恒 00:00:00、坐标固定城市中心）并排除，仅用真实转发源推导事件（案例：dvidshub）；`source` 为 NULL 的少量记录按真实轨迹处理，勿用 `NOT IN (...)` 误过滤。单来源表跳过本步。
3. **数据量探测 → 取数策略选择**：`COUNT(*)` 按目标/时间窗粗查 → 小数据全量拉取（**必须显式 `--limit`**，网关默认 LIMIT 1000 静默截断，见 db-doris.md）；大数据在 SQL 侧用窗口函数（LEAD/LAG）抽取锚点行，本地组装。禁止"无 LIMIT 全量拉取 6 个月轨迹"这类静态假设。

**同质性假设原则**：间隔/阈值类规则（如"24h 无更新=关闭"）隐含"数据密度均匀"前提。套用前先确认数据形态（源分布/坐标分布/时间粒度）；数据形态不满足前提时降级处理（如快照型源 → 记为"信号缺失"而非战术性关闭）。

随后按以下步骤执行取数与预处理：

1. 经统一只读网关取数：`python scripts/db_query.py --source <源> --sql "SELECT ..."`（连接/凭据/只读由 `scripts/db_query.py` 处理，见 `shared/db-doris.md` / `shared/db-mysql.md`）
2. **查询任何不熟悉的表前，先经网关内省 `--schema <表名>` 确认列名**，或读取 `schema/*.md` 判读规则；若查询报 `Unknown column` 等列名错误，**立即 `--schema` 内省确认列名后重试，不要连续猜测列名**
3. 用 `read` 读取本 persona「领域知识库」，确认分析规则和关联判据
4. 通过 SQL 条件筛选目标对象（筛选键值以本 persona「信息提取规则」/「默认配置偏好」为准）

### 3.2 数据质量检查

按以下 checklist 逐项校验（发现问题修正或提示用户，结果写入汇报）：
- **行数合理性**：关键查询返回行数在预期量级（过少→怀疑过滤过严/对象遗漏；过多→怀疑未去重/范围过大）
- **坐标范围**：Lat ∈ [-90,90]、Lon ∈ [-180,180]，超范围丢弃
- **时间单调**：按目标分组内时间严格递增
- **源分布**：多来源表已完成源甄别、快照型源已排除（见 3.1）
- **去重**：同一目标同一时刻仅保留一条

域特定规则（如航速/机型/键值过滤）按本 persona「默认配置偏好」补充。

### 3.3 分析计算

根据 Step 1 的答案执行分析，**遵循本 persona「专用分析模式」段落**：

```
规则来源：本 persona「领域知识库」中列出的 rag/*.md
  → 关联判据（如距离阈值、状态过滤条件）
  → 统计方法（按类型/区域/时间分组）
  → 评估模型（状态研判、威胁评估等）
```

**已有资产化算法优先调用 `lib/analysis/` 模块**（可单测、可版本化）：AIS 异常判定用
`python -m lib.analysis.ais_anomaly --input temp/events.json --output temp/anomalies.json`，
空间关联用 `python -m lib.analysis.spatial_association --input temp/assoc.json --output temp/out.json`，
威胁评估用 `python -m lib.analysis.threat_assessment --input temp/threat.json --output temp/out.json`
（事件 JSON 契约见各模块 docstring），再读取输出 JSON 结果。规则语义见 `rag/*_kb.md`。

阈值与默认判据以本 persona「默认配置偏好」为单一来源。

### 3.4 统计聚合

按 Step 1 的答案和关联分析结果进行统计：
- **关注单目标**：列出该目标的所有关联对象，按类型分类
- **关注区域**：筛选该区域内的目标，分别统计
- **关注全局**：全局统计、汇总对比

### 3.5 生成 HTML 大屏

**所有分析结果必须以 HTML 大屏形式输出，禁止手写 HTML。** 流程与规范参见 `shared/html-output.md`：

```
1. 分析完成后，将结果整理为声明式 spec JSON → temp/dashboard_spec_<任务>.json
2. 构建：LIB_BASE=lib/ python scripts/build_dashboard.py temp/dashboard_spec_<任务>.json
   （LIB_BASE=lib/ 让页面资源用**相对路径**引用平台共享 app-libs，页面在 /app/<port>/ 下解析为 /app/<port>/lib/...；禁止用根绝对路径 /lib/...）
3. 验证：python scripts/validate_html.py html/<文件名>.html（输出 OK）
```

**大屏引用图片时**（spec 构建前完成）：
- 图片放入 `/workspace/.apps/<appId>/www/uploads/`（worker 静态路由自动服务），spec 图片字段（如 `photo.src`）用**相对路径** `uploads/<文件名>.jpg` 引用
- `photo.src` 指向的文件缺失时，大屏显示"本地照片缺失"占位；文件已存在时刷新即显示

**★参考资产优先（先查参考库，再考虑从零设计）：**

```
1. 读 references/README.md 资产索引（参考大屏资产库，见其 README）
2. 按 当前任务类型 + 用户指令关键词 匹配参考（资产的 meta.json 的 task_types / scenario_tags）
3. 命中参考 → 读其 layout-spec.json（布局骨架）+ reference.html（视觉对照），
   用当前任务数据适配生成 spec —— ★参考优先，画"差不多"的
4. 未命中参考 → 按下方通用 spec 规范从零设计（兜底）
```

**参考资产与从零设计的关系**：参考模板优先级高于从零设计；命中参考时，rows/cells 布局、图表类型组合、内容组织方式参照参考骨架，数据与判据用当前任务实际结果替换。参考库由 `scripts/import_reference.py` 持续沉淀优秀交付物。

spec 声明要点：`name`(kebab-case)/`title`/`theme`/`kpis[]`/`rows[]`(布局)/`charts[]`(6类)/`tables[]`。复杂图（力导向、多层覆盖圈）用 `echarts` 类型 `option`/`js` 路径。样式由 `lib/dashboard/` 统一提供，不写 CSS。**页眉主标题 `title` 一律中文，禁止写英文标题。**

大屏支持 6 种布局+视觉预设（`spec.style`），**按任务性质自动选择**：态势/监控→`command`、
评估/研判/建议→`report-light`（正式军情研判→`report-dark`）、复盘/轨迹/过程→`timeline`、
技术/数据/工具→`terminal`、参考/对比/清单→`minimal`（规范见 `shared/viz-dark-theme.md`）；
用户明确指定风格时以用户为准。report-*/timeline 布局用 `report`/`timeline` 结构代替 `rows`
（blocks 引用已声明的 chart/table id），网格布局沿用 `rows`。

#### 大屏模块布局

按**本 persona「大屏布局」段落**组织 rows/cells 模块；若 persona 无该段落，按需求自行设计（bar/line 支持单/多序列，多序列必须配 legend 且 legend/colors 长度等于序列数；每个图表 data 必须非空）。**地图经度跨度 > 180° 时强制全球视角（zoom≈1.5、center≈[-10,5]）**，避免按分布公式算出的局部 zoom 过近。

### HTML 质量保障流程

参见 `shared/qa-html.md` 中的完整流程（写 spec → 构建 → 验证 → 3轮修正复杂图语义错误）。

### 文件命名规范

spec 的 `name` 决定文件名（kebab-case），产物在 `html/` 下。

**配套 MD（必出）**：HTML 构建+验证通过后，**必须**同步生成配套分析设计文档 `html/<name>.md`（与 HTML 同名）：
1. 按 `shared/md-report.md` 固定章节模板撰写——只讲**需求/数据/逻辑/结论/局限**，**不描述页面布局/组件**
2. 头部 `配套大屏` 字段写**相对路径** `html/<name>.html`（写 MD 时 serve 未输出真实 URL，**禁止编造外链**）
3. 校验：`python scripts/check_md_report.py html/<name>.md` 输出 `OK` 才算完成；失败修正后重跑

**打包为 App Worker（新架构默认，完整规则见 `shared/env-server.md` 默认章节）**：
构建+验证通过后，把大屏打包为 App Worker 并发布，产物自动进入生成物门户（/portal 右侧卡片）：
0. **构建页面用运行时模式**：`LIB_BASE=lib/ RUNTIME_SPEC=1 python scripts/build_dashboard.py <spec.json>`
   —— 产出运行时 HTML（不内联 spec）+ 侧车 `html/<name>.spec.json`；页面加载从 `/svc/spec` 拉取渲染
1. 页面放入 `/workspace/.apps/<appId>/www/index.html`
2. worker：复制 `templates/app-scaffold/worker.js.tpl` 为 `/workspace/.apps/<appId>/v1.js`（新版本另存 v2.js，不覆盖旧版）
3. 登记 `/workspace/.apps/apps.json`：`id` / `port`（20000-29999 唯一）/ `defaultVersion` / `versions`，门户元数据 `title`（必填）/ `description` / `createdAt` / `type`
4. **属主修正**（容器 root 运行、宿主机发布进程是 uid 1000，不执行则发布报 PermissionError）：`chown -R 1000:1000 /workspace/.apps`
5. 按下方 Step 4 发布并验证 `/app/<port>/svc/health` 返回 `"ok": true`
6. **spec 入库（必做）**：`POST /app/<port>/svc/spec`（body 传侧车 spec 或 `{"spec": ...}`），
   再 `GET /app/<port>/svc/spec` 确认返回非空 spec 才可汇报——否则页面只有骨架没有内容

## 修改现有大屏（门户联动，强制第一步）

用户提出"修改/调整/更新/改这个卡片/改这个大屏"时，**第一步必须先确认目标 app**：

1. 读 `/workspace/.apps/.selected`（JSON：`{"id": "<appId>", "ts": ...}`）——这是门户当前选中的生成物
2. 若用户明确点名其他 app → **先把 `.selected` 写为目标 app**（`{"id": "<appId>", "ts": <当前秒>}`），再继续；未点名 → 目标即 `.selected`；`.selected` 缺失 → 读 `apps.json` 列候选请用户确认，**禁止猜测**
3. **动手前先在回复中明示目标**（如"将修改 `carrier-global-v4` 的标题为 Test"），用户可据此判断是否正确
4. **禁止直接编辑 `/workspace/.apps/<appId>/`**。修改必须经平台接口，目标由平台按 `.selected` 强制（agent 传参无效）：
   - **大屏内容（布局/数据/标题，统一走 spec）**：HTML 骨架生成时已定稿，后续修改只改 spec 值。
     把修改后的完整 spec JSON 写入 `temp/modify-spec.json`，调用
     `POST /app/v1/apply/spec`（body 直接传 spec 对象或 `{"spec": ...}`；平台按 `.selected`
     强制目标 app，结构校验后写 SQLite + SSE 广播，已打开的页面自动重绘，无需刷新）。
     **改 spec 即生效，无需重建 HTML**：`dashboard.js` 按 spec 幂等重建 KPI/表格/图表，
     静态 HTML 只是首屏骨架。验证时看浏览器渲染后的 DOM（KPI 卡数量、表格行数），
     不要看 HTML 源码（源码骨架不实时反映 spec）。只有增删整个区块容器才考虑重建 HTML。
   - **只改标题/简介**：同样走 `POST /app/v1/apply/spec`（改 `spec.title` / `spec.subtitle`），
     门户卡片标题从 spec 读取（单一来源）
   - 发布接口示例：
     ```python
     python3 - <<'PY'
     import json, urllib.request, os
     cfg = json.load(open("config/server.json"))
     gw = cfg["baseUrl"].rstrip("/")
     uid = os.environ.get("WS_USER") or cfg.get("uid")
     opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
     opener.open(gw + "/portal/u/" + uid)
     spec = json.load(open("temp/modify-spec.json", encoding="utf-8"))
     req = urllib.request.Request(gw + "/app/v1/apply/spec",
         data=json.dumps({"spec": spec}).encode(),
         headers={"Content-Type": "application/json"}, method="POST")
     print(opener.open(req, timeout=15).read().decode())
     PY
     ```
5. 平台返回实际应用的 appId 后，向用户汇报新链接（页面改动即时生效，门户自动刷新预览）

## 定时数据同步（**每个轻应用必备**，快照合并模式）

**每个轻应用生成时必须同时产出 `sync_merge.py` 并登记 `sync` 配置**（缺失视为交付不完整，
`app_sync_data` / 审计会报 ERROR）。生成大屏时完成：
1. 复制 `scripts/sync_merge.py.tpl` 为 `/workspace/.apps/<appId>/sync_merge.py`，按业务定制：
   查询 SQL（`db_query.py`）、合并表 id 与 key 列、需要随数据联动的图表；
2. 在 `apps.json` 的该 app 登记 `"sync": {"script": "sync_merge.py"}`；
3. 平台 `app_sync_data` DAG 到点会在容器内执行该脚本：取当前 spec → 查库 → **按 key 合并**
   （只更新已有行的对应单元格，缺失旧行保留、不新增行，避免数据不全导致大屏残缺）→ 写 `sync_at` →
   POST `/svc/spec` → SSE 广播 → 页面无刷新更新。
合并规则是业务逻辑（哪个表按什么 key、哪些图表联动），由本 agent 生成时写死，平台不干预。

## Step 4: 汇报

根据 Step 1 的分类，采用不同的汇报方式：

**纯问答类** — 直接文本回复，无需查看链接。格式：
---
**{你的名字} 情报回答**
{回答内容}
数据来源：{数据来源}
---

**生成/分析类** — HTML 已落盘且已打包为 App Worker（见 3.5）后执行：
1. 发布（容器内无 curl，用 python3；uid 取环境变量 `WS_USER` 或 `config/server.json` 的 `uid`）：
   ```python
   python3 - <<'PY'
   import json, urllib.request, os
   cfg = json.load(open("config/server.json"))
   gw = cfg["baseUrl"].rstrip("/")
   uid = os.environ.get("WS_USER") or cfg.get("uid")
   assert uid, "无法确定 uid"
   opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
   opener.open(gw + "/portal/u/" + uid)               # 建立会话 Cookie
   req = urllib.request.Request(
       gw + "/app/v1/sync",
       data=json.dumps({"payload": {"uid": uid}}).encode(),
       headers={"Content-Type": "application/json"}, method="POST")
   print(opener.open(req, timeout=15).read().decode())
   PY
   ```
2. 验证：用同一 python3 Cookie 会话 GET `{baseUrl}/app/<port>/svc/health`，输出含 `"ok": true` 才算发布成功
3. 发送格式化简报：

---
**{你的名字} 分析报告**
- 报告主题：{分析主题}
- 内网查看：{baseUrl}/app/<port>/
- 分析摘要：{2-3句话概括关键发现}
- 数据时效：{数据时间范围}
- 门户：{baseUrl}/portal（右侧生成物卡片自动出现，可切换/预览/修改）
---
4. **禁止**再用任何静态快照方式承接新产物

**禁止外网请求（硬性规则，适用于所有生成物）**：worker 与页面 JS 不得发起任何外部网络请求
（fetch/WebSocket/外部 CDN/外部 API 一律禁止）；只允许 workerd 内部绑定（`http://lib`、`http://files`）、
应用内相对路径（`lib/`、`uploads/`、`/svc/...`）与网关同域接口；数据仅来自应用 SQLite/内嵌数据或平台只读网关。

**对话式补图**（用户要求把图放到大屏指定位置，App Worker 形态）：
1. 把图片放入 `/workspace/.apps/<appId>/www/uploads/`（页面相对路径引用 `uploads/<实际文件名>`，worker 静态路由自动服务）
2. 修改 `www/index.html` 对应图位 `photo.src` → 无需重新发布，改文件即时生效（属主仍按 3.5 第 4 步修正）
3. 告知用户"刷新大屏即显示"

关键中间产物（锚点/事件/统计等 JSON）落盘 `temp/` 便于追溯复盘（与执行日志配合）。

## 执行日志（低优先级，不阻塞主流程）

任务开始先定义任务标识 `<task>`（kebab-case，尽量与最终 spec.name 一致），并 `mkdir -p logs/agent`。
随后向 `logs/agent/<task>.log` 写**首行** `[task] <原始用户指令>`（语义索引：这组 SQL/事件在解决什么问题），
并 `echo <task> > logs/agent/.active-task`（**任务关联兜底文件**：即使网关调用没带 EXEC_TASK，脚本端日志也能归到本任务）。
执行中若发现非预期状况，向 `logs/agent/<task>.log` 追加一行；无状况则不写。

**网关调用归任务**：直接 bash 调用 `scripts/db_query.py` 前加 `EXEC_TASK=<task>` 前缀（内联环境变量，最精确）：
`EXEC_TASK=<task> python scripts/db_query.py --source doris --sql "SELECT ..."`
若把查询封装进**自写脚本**（subprocess 调用网关），优先向子进程透传 `EXEC_TASK`
（`os.environ['EXEC_TASK']='<task>'` 或 `subprocess.run(..., env={**os.environ, 'EXEC_TASK': task})`）；
`.active-task` 标记文件仅为**单会话兜底**，多会话并发时可能互相覆盖导致日志归错任务。

一行一条，字段用 | 分隔：
`[时间][级别][类型] 现象(期望 vs 实际) | 证据 | 影响`

级别：可继续执行 → warning；结果不可信/中断 → error。
类型（三选一）：
- data-fact 数据事实意外：判读规则/字段语义与真实数据不符；数据规模使既定取数不可行；对象全集意外；边界未定义（**网关返回 `truncated=true` 时记此类型**）
- deviation 被迫偏离：约束没覆盖，临时补位（自写 SQL/脚本/改取数方式）
- env-tool 工具/环境异常：端口占用、进程被杀、脚本行为与文档不符、某步失败
