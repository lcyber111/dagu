# opencode 智能体快速构建系统

## 项目核心

基于 [opencode](https://opencode.ai) 框架的一套**智能体生成系统**。核心是一个 **智能体设计顾问**（`agent-generator`），它通过**专家式业务问答**（任务类型/视角/深度 + 追加规则澄清，NL 已含则跳问）理解一线作战参谋的实际需求，**内部自主决策**匹配模板、注入领域知识、编排分析能力，最终生成一个能独立处理"这一类问题"的专业智能体。

### 与传统生成器的本质区别

| 传统模式（填空器） | 新模式（设计顾问） |
|--------------|--------------|
| 用户描述需求 → 让用户选模板 → 填充占位符 | 专家式问答（可跳问）→ **内部决策**模板 → 注入知识 |
| 2-3 个固定模板，用户需要知道模板差异 | 模板是内部实现细节，用户完全不需要知道 |
| SOP 是写死的 | SOP 是动态编排的 |
| 只能解决"这一个"问题 | 生成的 agent 能解决"这一类"问题 |
| 用户需要懂技术概念 | 用户只需要懂业务场景 |
| 生成后需要自己验证 | 自动生成验收测试用例 |

---

## 核心架构

```
agent-generator.md  ← ☆ 核心——智能体设计顾问
       │
       │【对外：专家式业务问答（四类型，NL 已含可跳问）】
       │  第1轮：任务类型（态势监控/规律挖掘/综合评估/专项检测）
       │  第2轮：分析视角（特定目标/区域态势/跨域关联/全局概览）
       │  第3轮：分析深度（态势呈现/特征分析/智能研判）
       │
       │【对内：自动决策】
        │  ① 匹配模板（analysis-agent，唯一统一模板）
       │  ② 选择能力模式（lib/analysis 资产模块 + 提示词模式）
       │  ③ 注入领域知识（schema 探查档案 + KB + 输入契约）
       │
       ├── 数据层
       │   ├── Doris 数据仓库 (23张表)
       │   │   ├── 轨迹数据: ais_ship_track / aircraft_ads-b_track
       │   │   ├── 航母核心: carrier_attribution / carrier_strike_track / ...
       │   │   ├── 情报事件: alarm / event / satellite_roll_call
       │   │   ├── 体系数据: base_attribution / force_attribution / ...
       │   │   └── 装备数据: equipment_attribution / weapon_deploy_info
       │   │
       │   └── MySQL 情报库 (10张表, 目标:哈梅内伊)
       │       ├── 通信情报: communication / email
       │       ├── 位置情报: signaling / traffic_camera_pictures
       │       ├── 人物情报: attribution_person / contact
       │       └── 组织情报: institution / key_area / ...
       │
       ├── 知识层
       │   ├── schema/  判读规则 + 探查档案 (33个文件，Doris 23 + MySQL 10)
       │   └── rag/     领域知识库 (6个文件)
       │
       ├── 配置层 → config/db_sources.json (数据库连接注册)
       │
       ├── 模板层 → templates/ (内部选用 + spec 样例)
       │
       ├── 共享层 → shared/ (10个共享模块，含 analysis-runtime 运行时 SOP，Boot Sequence 加载)
       │
       ├── 工具层 → scripts/ (db_query 网关 + 构建/校验 + probe/log 工具)
       │
       ├── 临时层 → temp/ (智能体运行中的临时文件，任务结束清理)
       │
       ├── 日志层 → logs/ (智能体端 + 脚本端执行日志，双向印证，gitignored)
       │
       └── 输出层
            ├── .opencode/agents/ (生成的专业智能体)
             ├── html/             (大屏 HTML 构建产物 + 配套 MD，由构建脚本生成)
            ├── lib/dashboard/    (大屏共享主题 CSS + 渲染引擎 JS)
            ├── output/           (智能体分析结果 JSON/GeoJSON)
            └── data/             (手动拷贝的参考数据)
```

---

## 智能体设计顾问工作流程

### 设计理念

**智能体设计顾问不向用户提及任何模板名称。** 用户（参谋长）只需回答**必要**的业务问题（NL 已含则跳过对应问；判定规则/阈值与默认冲突时追加一次规则澄清），模板选择是内部实现细节。

| 你（用户）看到的 | 背后发生的 |
|----------------|-----------|
| "这个智能体主要完成哪类分析任务？" | → 判断任务类型：态势监控/规律挖掘/综合评估/专项检测（NL 已含则跳过） |
| "分析时更关注哪个维度？" | → 决定分析视角：特定目标/区域态势/跨域关联/全局概览（NL 已含则跳过） |
| "大屏分析需要到哪个深度？" | → 选择注入多少领域知识与分析模式（NL 已含则跳过） |
| "AIS 关闭多久算异常？/判定参数按哪个？" | → 追加**规则澄清**（读 KB 真实阈值，用户给过则提取不反问） |
| 你回答了必要问题 | → 内部决策：匹配模板+编排能力+注入知识（含 schema 探查档案与模式输入契约） |
| "请确认能力清单" | → 展示将要生成的智能体能力 |
| "智能体已就绪" | → 生成完毕，附验收测试指令 |

> 判定标准：一个问题若回答后不影响生成物（注入的表/模式/规则/形态），就不该问。

### 第1轮：问任务类型

```
这个智能体主要完成哪类情报分析任务？
  A) 态势监控    —— 实时掌握目标动态（位置/状态/异常）
  B) 规律挖掘    —— 分析历史活动规律（周期/节奏/趋势）
  C) 综合评估    —— 全面情报融合（态势+规律+意图+威胁）
  D) 专项检测    —— 聚焦特定检测目标（如AIS异常/舰载机活动）
```

### 第2轮：问分析视角

```
分析时更关注哪个维度？
  A) 特定目标纵深    —— 聚焦一个或几个关键目标深挖
  B) 区域整体态势    —— 关注某区域部署格局与关联
  C) 跨域交叉关联    —— 不同数据源交叉印证（如舰船↔飞机）
  D) 全局多目标概览  —— 大范围宏观态势
```

### 第3轮：问分析深度

```
大屏分析需要到哪个深度？
  A) 态势呈现    —— 数据如实呈现，不加研判
  B) 特征分析    —— 分类统计、对比、趋势识别
  C) 智能研判    —— 状态判定+意图分析+威胁评估+建议
```

### 第4轮：数据就绪检查

经只读网关 `scripts/db_query.py` 验证数据源连通（只读冒烟），不生成演示数据。

### 第5轮：内部决策

匹配模板、编排能力模式、匹配数据表，决定注入的 schema 探查档案 / KB / 模式输入契约（不向用户展示）。

### 第6轮：能力确认

展示按答案编排的能力清单，供用户确认或补充。

### 第7轮：生成 + 注入领域知识

读模板 → 填占位符 → 注入 schema/KB/模式契约 → Boot Sequence → 自检（含 `--schema` 内省与共享模块完整性）。

### 第8轮：验收引导

根据对话自动生成 2-3 条验收测试指令与推荐问题。

---

## 模板系统（内部实现）

以下模板由生成器内部根据业务答案自动匹配，用户无需感知：

| 模板 | 典型场景 | 匹配业务特征 |
|------|---------|-------------|
| `analysis-agent.md` | 所有情报分析任务——数据加载/情报问答→分析→大屏 | 统一模板，占位符配置差异 |
| `dashboard-spec-*.json` | 大屏 spec 样例（标准/地图/echarts透传） | 构建脚本 `build_dashboard.py` 的输入参照 |

## 模式库

生成器从模式库中动态选择能力模式注入 agent：

| 模式 | 用途 | 触发条件 |
|------|------|---------|
| AIS 异常判定（资产模块 `ais-anomaly`） | AIS OFF/ON 异常与等级判定 | 涉及AIS状态事件 |
| 空间关联（资产模块 `spatial-association`） | Haversine 距离、航母→舰载机归属、高度分层 | 涉及空间关联分析 / AIS+ADS-B同时使用 |
| 威胁等级评估（资产模块 `threat-assessment`） | 威胁 4 级分级（严重/高/一般/无实质） | 综合评估+威胁判定 |
| 航母状态判定（资产模块 `carrier-state`） | 状态判定（休整/维修/训练/警戒/演习/作战/补给） | 综合评估+状态判定 |
| AIS 事件装配（资产模块 `ais-event-assembly`） | 锚点→OFF/ON 事件序列（边界合成/同刻冲突/零记录/去重） | 涉及AIS开关事件推导 |
| AIS 航母识别 | 从AIS数据筛选航母 | 涉及AIS数据 |
| ADS-B 高度过滤 | 按高度筛选飞机 | 涉及ADS-B数据 |
| 统计聚合 | 按机型/时间/空间分类统计 | 深度=B/C |
| 状态判定 | 判读航母当前状态 | 深度=C + 有状态KB |
| ECharts 地图 | 态势大屏可视化 | 输出=A/C（声明式 map 类型） |
| 数据分析图表 | ECharts 统计图表（bar/line/pie/scatter） | 输出=A/C + 深度=B/C |
| 复杂图 | echarts option/js 透传（力导向图等） | 声明式无法表达时 |

> 资产化模式（`lib/analysis/` 注册表 id，现有 **5 个**：ais-anomaly / ais-event-assembly / spatial-association / threat-assessment / carrier-state）由多个画像共用同一模块实现，生成器注入**模块 id + CLI 契约 + 输入契约要点**（见 `agent-generator.md` 第5轮契约表）；未资产化模式以提示词描述。

---

## 数据层详解

### Doris 数据仓库（23张表）

连接配置：`config/db_sources.json` → `doris`

| 领域 | 表名 | 记录数 | 用途 |
|------|------|--------|------|
| **轨迹数据** | `ais_ship_track` | 1.59亿 | AIS船舶轨迹（MMSI/船名/位置/航速） |
| | `aircraft_ads-b_track` | 1.63亿 | ADS-B飞机轨迹（ICAO/机型/高度，表名含连字符须反引号） |
| **航母核心** | `carrier_attribution` | 11 | 11艘航母完整属性 |
| | `carrier_strike_track` | 8 | 航母编队组成（护航舰艇编配） |
| | `carrier_homeport_info` | 11 | 航母母港地理分布 |
| | `kantian_aircraft_carrier_status` | 265 | 航母实时状态（在港/出海/部署） |
| | `carrier_equipment_relation` | 811 | 航母-装备挂载关系 |
| | `carrier_aircraft_weapon_relation` | 9 | 航母武器系统关系 |
| | `carrier_info_input` | 6 | 手工录入航母位置信息 |
| | `naval_ships_attribution` | 59 | 护航舰艇属性 |
| **情报事件** | `alarm` | 1376 | 异常告警（AIS异常/区域入侵） |
| | `event` | 3155 | 军事情报事件（部署/演习/访问） |
| | `satellite_roll_call` | 850 | 卫星侦察目标清单 |
| **装备数据** | `equipment_attribution` | 223 | 军事装备属性 |
| | `naval_platform_equipment_mount` | 450 | 海战平台-装备挂载 |
| | `weapon_deploy_info` | 1 | 堤丰导弹部署信息 |
| **体系数据** | `base_attribution` | 22 | 军事基地属性 |
| | `force_attribution` | 96 | 军事部队属性 |
| | `force_base_relation` | 70 | 部队-基地驻扎关系 |
| **人员数据** | `person_attribution` | 126 | 军事人员属性 |
| | `person_carrier_relation` | 39 | 关键人物-航母关系 |
| **属性数据** | `aircraft_attribution` | 9 | 飞行器型号参数 |
| | `aircraft_focus_targets` | 513 | 重点飞行器关注清单 |

> 记录数为 `scripts/probe_tables.py` 探查值（as-of 2026-08-10）；各表权威的源语义/时间范围/取数策略/已知坑见 `schema/doris_*.md` 探查档案。

### MySQL 对伊情报库（10张表）

连接配置：`config/db_sources.json` → `mysql_gf`，目标：哈梅内伊关联情报

| 领域 | 表名 | 用途 |
|------|------|------|
| **通信情报** | `communication` | 通信截获记录（通话/短信/加密消息） |
| | `email` | 邮件截获记录（元数据+内容+命名实体） |
| **位置情报** | `signaling` | 手机信令数据（轨迹还原） |
| | `traffic_camera_pictures` | 卡口监控抓拍 |
| **人物情报** | `attribution_person` | 目标人物属性（身份/职务/宗教/政治倾向） |
| | `contact` | 目标联系人网络（通联频次/亲密度） |
| **组织情报** | `institution` | 目标关联机构（IRGC/情报机构） |
| | `key_area` | 重点目标区域（官邸/宗教场所/密会点） |
| **车辆情报** | `senior_government_vehicle` | 高价值目标车辆（领袖车队） |
| **基础设施** | `base_station` | 通信基站部署 |

### config/ 配置目录

| 文件 | 用途 |
|------|------|
| `config/db_sources.json` | 数据库源注册表 —— 连接凭据、表清单、对应 schema 文件路径 |

扩展数据源：添加新数据库源或新表后，在此文件中注册，生成器即可自动识别和引用。

---

## 知识层

### schema/ —— 判读规则 + 探查档案（33个文件）

每个数据库表对应一个 `schema/*.md` 文件，采用**两段式**结构：
- **业务判读规则**：只讲业务语义（不引用具体列名）
- **探查档案**：数据源语义 / 数据量级（as-of）/ 时间范围 / 坐标范围 / 关键字段事实 / 取数策略 / 已知坑

列元数据以 `scripts/db_query.py --schema` 实时内省为唯一来源；探查档案由 `scripts/probe_tables.py` 只读探查生成（as-of 日期标注，运行时以 SOP 探索三步复核）。

| 前缀 | 数量 | 说明 |
|------|------|------|
| `doris_*` | 23 | Doris 数据仓库各表（判读规则 + 探查档案） |
| `mysql_gf_*` | 10 | MySQL 对伊情报库各表业务判读规则（暂未建档，待连接后扩展） |

> 旧版 CSV schema（`carrier_*`）已随数据库迁移删除；纯字段列表文档已剥离（列元数据归 `--schema`）。

### rag/ —— 领域知识库（6个文件）

| 文件 | 行数 | 用途 |
|------|------|------|
| `carrier_aircraft_kb.md` | 92 | 航母舰载机知识库（空间关联规则、Haversine公式） |
| `carrier_ais_kb.md` | 97 | AIS 异常监测知识库（判定规则、零记录边界、dedupe 契约、同质性假设、锚点抽取） |
| `carrier_intel_report.md` | 628 | 美军航母情报报告（11艘航母技术参数+动态） |
| `carrier_assessment_kb.md` | 196 | 航母态势评估知识库（状态判定/动向/意图/威胁） |
| `cvn73_washington_intel.md` | 131 | 华盛顿号（CVN-73）动态情报报告（2023-2025时间线） |
| `cvn73_2026_trajectory_kb.md` | 143 | CVN-73 2026年航迹分析知识库（航迹分段/态势评估规则） |

---

## 工具与临时文件

### scripts/ —— 项目工具脚本

| 文件 | 用途 |
|------|------|
| `scripts/db_query.py` | **只读查询网关** —— 统一取数/表清单/结构内省（只读白名单 + LIMIT 上限，凭据不进提示词；执行日志写 logs/） |
| `scripts/build_dashboard.py` | **大屏构建脚本** —— 声明式 spec JSON → HTML（JSON Schema 深度校验/主题注入/数据转义） |
| `scripts/validate_html.py` | **HTML 验证工具** —— HTML 结构 + Node.js JS 语法 + 行为校验（核心QA基础设施） |
| `scripts/check_dashboard.py` | **行为校验** —— node 执行真实 `chart-builders.js` → 数据形状断言 → ECharts SSR 渲染非空 |
| `scripts/selftest.py` | **回归自测** —— 全部样例构建+验证（正例必过、构造负例必败）+ 单元测试 |
| `scripts/probe_tables.py` | **表探查脚本** —— Doris 注册表只读探查（量级/时间/源分布/坐标），产出 schema 探查档案定量部分 |
| `scripts/log_util.py` | **执行日志工具** —— 脚本端确定性日志（logs/scripts/*.log，EXEC_TASK/.active-task 任务关联） |
| `scripts/check_md_report.py` | **配套 MD 校验器** —— 必备章节/每节非空/配套大屏真实性（大屏交付前置） |
| `scripts/strip_schema_docs.py` | **schema 判读文档化** —— 剥离字段列表，只留业务判读规则（--dry-run/--execute） |
| `scripts/validate_agent.py` | **生成 agent 校验器** —— front matter/文件名/Boot Sequence 引用/权限/`{{` 残留（生成器第7步必跑） |
| `scripts/test_*.py` | **单元测试** —— 网关只读 + 5 个分析模式模块（20+11+15+18+7+12 例） |

### temp/ —— 临时文件目录

智能体在任务执行中产生的 Python 脚本、中间 JSON 等临时文件统一写入此目录，任务结束后自动清理。不纳入版本控制。

### logs/ —— 执行日志目录（gitignored）

智能体端语义日志 + 脚本端确定性日志，双向印证，供复盘/追溯/算法沉淀：

| 日志 | 内容 |
|------|------|
| `logs/agent/<task>.log` | 智能体端语义日志（数据事实/偏离/环境异常，首行 `[task]` 原始指令） |
| `logs/scripts/sql.log` | 网关成功 SQL 全量（执行语料：SQL/行数/耗时/truncated，`task=` 关联） |
| `logs/scripts/db_query.log` | 网关截断/只读拒绝/失败（信号轨） |
| `logs/scripts/build.log` / `validate.log` / `serve.log` | 构建/验证/服务事件 |

任务关联：agent 直接 bash 调用网关带 `EXEC_TASK=<task>` 前缀，或经 `.active-task` 标记文件兜底；SQL 语料按任务聚合，供后续算法资产化。

---

## 输出层

### .opencode/agents/ —— 智能体清单

| 智能体 | 用途 |
|--------|------|
| `agent-generator.md` | **核心** —— 智能体设计顾问（专家式问答：能力问 + 追加规则澄清，可跳问） |
| `washington-carrier-intel.md` | 存量垂域 agent（手工维护，华盛顿号航母情报分析） |

> 生成的垂域 agent 按治理约定不入库（`.opencode/agents/.gitignore` 只保留生成器与手工维护存量）。

#### 智能体生成链路

生成的专业智能体通过 Boot Sequence 加载共享模块，分析结果统一以声明式 spec 构建 HTML 大屏（见 `shared/html-output.md`、`shared/qa-html.md`）。模板参考 `templates/analysis-agent.md`，spec 样例见 `templates/dashboard-spec-*.json`。

### html/ —— 大屏构建产物

所有 HTML 大屏**由 `scripts/build_dashboard.py` 从声明式 spec 构建**（`LIB_BASE=lib/`，资源走平台共享 `lib/`），构建验证通过后**打包为 App Worker 发布**（见 `shared/env-server.md`，产物进入生成物门户 /portal 右侧卡片）；每个大屏配套 `<name>.md` 分析设计说明（需求/数据/逻辑，模板见 `shared/md-report.md`）：

| 文件 | 行数 | 内容 |
|------|------|------|
| `sample-standard-dashboard.html` | 111 | 标准看板样例（bar/line/pie/table，机型对比） |
| `sample-map-dashboard.html` | 113 | 地图大屏样例（多类别标记+覆盖圈+轨迹线，台海打击） |
| `sample-echarts-dashboard.html` | 164 | 复杂图样例（echarts 力导向图透传 + 声明式图表） |

spec 样例位于 `templates/dashboard-spec-*.json`，可直接参照。存量大屏已统一重建为构建脚本产物，历史手写 HTML 不再维护。

### lib/ —— 离线前端库

| 库 | 用途 | 本地路径 |
|----|------|---------|
| ECharts 5.x | 地图/图表可视化 | `lib/echarts/echarts.min.js` |
| ECharts 世界地图 | 离线 GeoJSON 地图 | `lib/echarts-maps/world.js` |
| Chart.js 4.x | 统计图表（存量维护，新大屏统一 ECharts） | `lib/chartjs/chart.umd.min.js` |
| Font Awesome 6.x | 图标系统 | `lib/fontawesome/` |
| **Dashboard 主题** | 大屏共享深色主题（CSS 变量驱动，spec.theme 注入主色） | `lib/dashboard/dashboard.css` |
| **Dashboard 引擎** | 大屏声明式渲染引擎（读取 DASHBOARD_SPEC 渲染图表/KPI） | `lib/dashboard/dashboard.js` |
| **图表构建器** | 图表逻辑唯一实现（浏览器与行为校验共用，杜绝契约漂移） | `lib/dashboard/chart-builders.js` |

### data/ —— 手动拷贝的参考数据

手动放入的静态参考数据文件，供智能体分析时读取：

---

## 质量保障（QA）

### HTML 大屏构建与验证流程

大屏统一由构建脚本生成，智能体不手写 HTML：

```
智能体写声明式 spec JSON → LIB_BASE=lib/ python scripts/build_dashboard.py <spec> → html/<name>.html
                                                            ↓
                              python scripts/validate_html.py html/<name>.html
                                                            ↓
打包 App Worker → 发布 → /app/<port>/（见 shared/env-server.md）
```

`scripts/validate_html.py` 提供自动化验证（三层防线）：

```
验证项：
  ✅ HTML 结构完整性
  ✅ 资源引用可访问性（相对路径、本地 lib/）
  ✅ Node.js JavaScript 语法检查
  ✅ 行为校验：node 执行真实 chart-builders 构建每个图表，
              数据形状断言（空数据/坏结构必败）+ ECharts SSR 真实渲染非空
  ✅ 离线可运行性确认
```

三层防线分工：

1. **构建期**：`build_dashboard.py` 按 `templates/dashboard-spec.schema.json`（JSON Schema 唯一契约）深度校验 spec，格式/数据形状非法当场报错，杜绝"结构合法但图空"
2. **验证期**：`validate_html.py`（结构+JS 语法）叠加 `check_dashboard.py`（浏览器同一份 `lib/dashboard/chart-builders.js` 在 node 中真实构建 + SSR 渲染非空）
3. **浏览器期**：`lib/dashboard/dashboard.js` 构建失败渲染红条（失败显性化）

每个生成的大屏必须通过验证方可交付。回归自测：`python scripts/selftest.py`（正例全过 + 构造负例必败）。spec 结构、图表类型、主题规范见 `shared/html-output.md`，质量流程见 `shared/qa-html.md`。

### 智能体质量要求

agent-generator 对每个新生成的智能体执行 7 项自检：

1. 数据源连接正确性
2. 模式库注入完整性
3. 领域知识覆盖度
4. SOP 流程可执行性
5. HTML 输出离线可用性
6. 验收测试指令可达性
7. 自我修复机制

---

## 快速参考

| 操作 | 方法 |
|------|------|
| 创建新智能体 | 切换到"智能体设计顾问"，描述需求 → 回答必要业务问题（任务类型/视角/深度 + 规则澄清，NL 已含可跳问） |
| 验证新智能体 | 切换到新 agent，运行自动生成的验收测试指令 |
| 扩展数据库表 | 添加新表后，在 `config/db_sources.json` 注册，运行 `python scripts/probe_tables.py` 生成探查档案并补 `schema/*.md` |
| 刷新表探查档案 | 数据变化后重跑 `python scripts/probe_tables.py`，同步各表 `schema/*.md` 探查档案定量部分 |
| 扩展领域知识 | 向 `rag/` 添加新的知识库 .md 文件 |
| 扩展共享模块 | 向 `shared/` 添加新的 .md 文件，在模板 Boot Sequence 中引用 |
| 扩展模板 | 创建新的 `templates/*.md`，在生成器的决策树中注册 |
| 扩展大屏样式 | 修改 `lib/dashboard/dashboard.css`（主题）或 `chart-builders.js`/`dashboard.js`（图表引擎）；地图图例/类别规范见 `shared/html-output.md` |
| 构建 HTML 大屏 | 运行 `LIB_BASE=lib/ python scripts/build_dashboard.py <spec.json>`（spec 结构见 `shared/html-output.md`） |
| 验证 HTML | 运行 `python scripts/validate_html.py html/<file>` |
| 查看执行日志 | `logs/agent/`（语义）+ `logs/scripts/`（SQL 语料/信号），gitignored |
| 发布大屏 | 按 `shared/env-server.md` 打包 App Worker（.apps 登记 + chown + python3 发布） |
| 查看生成的大屏 | 门户 `/portal` 右侧卡片点击切换；新标签打开 `/app/<port>/` |
| 查看配套文档 | 生成大屏时自动输出 `html/<name>.md`（需求/数据/逻辑，模板见 `shared/md-report.md`），沉淀于 html/ |
| 上传图片 | 图片放入 App Worker 的 `www/uploads/`，页面用相对路径 `uploads/<文件名>` 引用（见 `shared/env-server.md`） |
| 领域决策矩阵 | 生成器第5轮决策（资产化模式/表路由）由 `config/capability-matrix.json` 承载，运行 `python scripts/render_matrix.py` 生成 markdown 供生成器读取；一致性校验 `python scripts/test_capability_matrix.py` |

---

## 设计理念

### 1. 业务语言优先
生成器使用参谋长能理解的业务语言对话，不抛出技术术语。
- ✓ "分析结果在哪里看？大屏还是报告？"
- ✗ "输出格式要HTML还是CSV？"
- ✓ "关注全球还是特定战区？"
- ✗ "用哪个模板生成？"

### 2. 模板对用户透明
模板是内部实现细节，用户只需要知道**他能得到什么能力的智能体**，不需要知道**用什么模板生成的**。

### 3. 生成的是"参谋"不是"脚本"
每个生成的 agent 拥有独立判断能力，能自主理解指令、选择工具、编排流程，解决"这一类"问题而非"这一个"问题。

### 4. 领域知识分层
| 层次 | 内容 | 存放位置 |
|------|------|---------|
| **参考数据** | 手动拷贝的静态参考数据 | `data/` |
| **数据库源** | Doris + MySQL 连接与表定义 | `config/db_sources.json` |
| **表事实** | 判读规则 + 探查档案（源语义/量级/取数策略/已知坑） | `schema/*.md`（probe 生成 + 策展） |
| **领域知识** | 知识库文件（判定规则/评估模型） | `rag/` |
| **共享过程知识** | 运行时 SOP、DB连接、QA流程、视觉主题等通用能力 | `shared/`（含 `analysis-runtime.md`） |
| **执行日志** | 智能体端 + 脚本端执行语料（双向印证） | `logs/` |
| **前端资源** | 平台共享 HTML/JS/CSS 库（App Worker 经相对路径 `lib/` 引用） | `lib/` |

### 5. 离线优先
所有前端库、数据文件、知识库都在本地，生成的 HTML 大屏不依赖任何外部 CDN 或网络，双击即可运行。

### 6. 持续积累
`data/`、`schema/`、`rag/` 等目录随着每次任务不断积累完善——新的数据源、新的知识库、新的分析模式都能加入生态。
