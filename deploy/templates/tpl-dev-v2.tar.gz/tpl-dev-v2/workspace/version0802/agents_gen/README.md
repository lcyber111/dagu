# opencode 智能体快速构建系统

## 项目核心

基于 [opencode](https://opencode.ai) 框架的一套**智能体生成系统**。核心是一个 **智能体设计顾问**（`agent-generator`），它通过**3轮业务对话**理解一线作战参谋的实际需求，**内部自主决策**匹配模板、注入领域知识、编排分析能力，最终生成一个能独立处理"这一类问题"的专业智能体。

### 与传统生成器的本质区别

| 传统模式（填空器） | 新模式（设计顾问） |
|--------------|--------------|
| 用户描述需求 → 让用户选模板 → 填充占位符 | 3轮业务问答 → **内部决策**模板 → 注入知识 |
| 2-3 个固定模板，用户需要知道模板差异 | 模板是内部实现细节，用户完全不需要知道 |
| SOP 是写死的 | SOP 是动态编排的 |
| 只能解决"这一个"问题 | 生成的 agent 能解决"这一类"问题 |
| 用户需要懂技术概念 | 用户只需要懂业务场景 |
| 生成后需要自己验证 | 自动生成验收测试用例 |

---

## 核心架构

```
agent-generator.md  ← ☆ 核心——智能体设计顾问
       │
       │【对外：3轮业务问题】
       │  第1轮：分析结果怎么用？（大屏/表格/都要）
       │  第2轮：关注什么范围？（全球/区域/特定目标）
       │  第3轮：分析到哪个深度？（基础/统计/评估）
       │
       │【对内：自动决策】
        │  ① 匹配模板（analysis-agent）
       │  ② 选择能力模式（Haversine/CSV解析/ECharts地图...）
       │  ③ 注入领域知识（schema + KB）
       │
       ├── 数据层
       │   ├── Doris 数据仓库 (23张表)
       │   │   ├── 轨迹数据: ais_ship_track / aircraft_ads-b_track
       │   │   ├── 航母核心: carrier_attribution / carrier_strike_track / ...
       │   │   ├── 情报事件: alarm / event / satellite_roll_call
       │   │   ├── 体系数据: base_attribution / force_attribution / ...
       │   │   └── 装备数据: equipment_attribution / weapon_deploy_info
       │   │
       │   └── MySQL 情报库 (10张表, 目标:哈梅内伊)
       │       ├── 通信情报: communication / email
       │       ├── 位置情报: signaling / traffic_camera_pictures
       │       ├── 人物情报: attribution_person / contact
       │       └── 组织情报: institution / key_area / ...
       │
       ├── 知识层
       │   ├── schema/  字段定义与判读规则 (38个文件)
       │   └── rag/     领域知识库 (6个文件)
       │
       ├── 配置层 → config/db_sources.json (数据库连接注册)
       │
       ├── 模板层 → templates/ (内部选用 + spec 样例)
       │
       ├── 共享层 → shared/ (9个共享模块，Boot Sequence 加载)
       │
       ├── 工具层 → scripts/ (大屏构建 + 校验/工具脚本)
       │
       ├── 临时层 → temp/ (智能体运行中的临时文件，任务结束清理)
       │
       └── 输出层
            ├── .opencode/agents/ (生成的专业智能体)
            ├── html/             (离线情报大屏，由构建脚本生成)
            ├── lib/dashboard/    (大屏共享主题 CSS + 渲染引擎 JS)
            ├── output/           (智能体分析结果 JSON/GeoJSON)
            └── data/             (手动拷贝的参考数据)
```

---

## 智能体设计顾问工作流程

### 设计理念

**智能体设计顾问不向用户提及任何模板名称。** 用户（参谋长）只需要回答3个业务问题，模板选择是内部实现细节。

| 你（用户）看到的 | 背后发生的 |
|----------------|-----------|
| "这个结果希望怎么用？" | → 判断输出形态：地图/表格/混合 |
| "关注什么范围？" | → 决定数据过滤范围和聚焦区域 |
| "分析到哪个深度？" | → 选择注入多少领域知识和分析模式 |
| 你回答了3个问题 | → 内部决策树：匹配模板+编排能力+注入知识 |
| "请确认能力清单" | → 展示将要生成的智能体能力 |
| "智能体已就绪" | → 生成完毕，附验收测试指令 |

### 第1轮：问输出形式

```
这个分析结果希望怎么用？
  A) 在大屏上看态势地图 / 可视化报告
  B) 出表格 / 清单数据，供进一步研判
  C) 都可以，既要地图也要数据
```

### 第2轮：问关注范围

```
关注的范围是什么？
  A) 全球 / 全域态势
  B) 特定区域（如南海/中东/印太）
  C) 特定目标（如林肯号航母）
```

### 第3轮：问分析深度

```
分析到哪个深度？
  A) 基础层：只看"是什么"——位置标注、数据呈现
  B) 分析层：看"是什么+怎么样"——统计、对比、分类
  C) 评估层：全面的分析评估——研判态势、评估威胁
```

### 第4轮：能力确认

展示根据3轮答案编排的能力清单，供用户确认或补充。

### 第5轮：生成 + 注入领域知识

自动完成：读模板 → 填内容 → 注入schema/KB → 注入模式代码 → 自检。

### 第6轮：验收引导

根据对话自动生成 2-3 条验收测试指令。

---

## 模板系统（内部实现）

以下模板由生成器内部根据业务答案自动匹配，用户无需感知：

| 模板 | 典型场景 | 匹配业务特征 |
|------|---------|-------------|
| `analysis-agent.md` | 所有情报分析任务——数据加载/情报问答→分析→大屏 | 统一模板，占位符配置差异 |
| `dashboard-spec-*.json` | 大屏 spec 样例（标准/地图/echarts透传） | 构建脚本 `build_dashboard.py` 的输入参照 |

## 模式库

生成器从模式库中动态选择能力模式注入 agent：

| 模式 | 用途 | 触发条件 |
|------|------|---------|
| Haversine 距离计算 | 球面两点距离 | 涉及空间关联分析 |
| AIS 航母识别 | 从AIS数据筛选航母 | 涉及AIS数据 |
| ADS-B 高度过滤 | 按高度筛选飞机 | 涉及ADS-B数据 |
| 空间关联 | 航母→舰载机半径+高度关联 | AIS+ADS-B同时使用 |
| 统计聚合 | 按机型/时间/空间分类统计 | 深度=B/C |
| 状态判定 | 判读航母当前状态 | 深度=C + 有状态KB |
| ECharts 地图 | 态势大屏可视化 | 输出=A/C（声明式 map 类型） |
| 数据分析图表 | ECharts 统计图表（bar/line/pie/scatter） | 输出=A/C + 深度=B/C |
| 复杂图 | echarts option/js 透传（力导向图等） | 声明式无法表达时 |

---

## 数据层详解

### Doris 数据仓库（23张表）

连接配置：`config/db_sources.json` → `doris`

| 领域 | 表名 | 记录数 | 用途 |
|------|------|--------|------|
| **轨迹数据** | `ais_ship_track` | 570万 | AIS船舶轨迹（MMSI/船名/位置/航速） |
| | `aircraft_ads-b_track` | 2125万 | ADS-B飞机轨迹（ICAO/机型/高度） |
| **航母核心** | `carrier_attribution` | 11 | 11艘航母完整属性 |
| | `carrier_strike_track` | 58 | 航母编队组成（护航舰艇编配） |
| | `carrier_homeport_info` | 11 | 航母母港地理分布 |
| | `kantian_aircraft_carrier_status` | 156 | 航母实时状态（在港/出海/部署） |
| | `carrier_equipment_relation` | 811 | 航母-装备挂载关系 |
| | `carrier_aircraft_weapon_relation` | 9 | 航母武器系统关系 |
| | `carrier_info_input` | 6 | 手工录入航母位置信息 |
| | `naval_ships_attribution` | 59 | 护航舰艇属性 |
| **情报事件** | `alarm` | 1369 | 异常告警（AIS异常/区域入侵） |
| | `event` | 3155 | 军事情报事件（部署/演习/访问） |
| | `satellite_roll_call` | 837 | 卫星侦察目标清单 |
| **装备数据** | `equipment_attribution` | 223 | 军事装备属性 |
| | `naval_platform_equipment_mount` | 450 | 海战平台-装备挂载 |
| | `weapon_deploy_info` | 1 | 堤丰导弹部署信息 |
| **体系数据** | `base_attribution` | 22 | 军事基地属性 |
| | `force_attribution` | 96 | 军事部队属性 |
| | `force_base_relation` | 70 | 部队-基地驻扎关系 |
| **人员数据** | `person_attribution` | 111 | 军事人员属性 |
| | `person_carrier_relation` | 30 | 关键人物-航母关系 |
| **属性数据** | `aircraft_attribution` | 9 | 飞行器型号参数 |
| | `aircraft_focus_targets` | 513 | 重点飞行器关注清单 |

### MySQL 对伊情报库（10张表）

连接配置：`config/db_sources.json` → `mysql_gf`，目标：哈梅内伊关联情报

| 领域 | 表名 | 用途 |
|------|------|------|
| **通信情报** | `communication` | 通信截获记录（通话/短信/加密消息） |
| | `email` | 邮件截获记录（元数据+内容+命名实体） |
| **位置情报** | `signaling` | 手机信令数据（轨迹还原） |
| | `traffic_camera_pictures` | 卡口监控抓拍 |
| **人物情报** | `attribution_person` | 目标人物属性（身份/职务/宗教/政治倾向） |
| | `contact` | 目标联系人网络（通联频次/亲密度） |
| **组织情报** | `institution` | 目标关联机构（IRGC/情报机构） |
| | `key_area` | 重点目标区域（官邸/宗教场所/密会点） |
| **车辆情报** | `senior_government_vehicle` | 高价值目标车辆（领袖车队） |
| **基础设施** | `base_station` | 通信基站部署 |

### config/ 配置目录

| 文件 | 用途 |
|------|------|
| `config/db_sources.json` | 数据库源注册表 —— 连接凭据、表清单、对应 schema 文件路径 |

扩展数据源：添加新数据库源或新表后，在此文件中注册，生成器即可自动识别和引用。

---

## 知识层

### schema/ —— 字段定义与判读规则（38个文件）

每个数据库表对应一个 `schema/*.md` 文件，记录字段含义、业务判读规则、分析注意事项。

| 前缀 | 数量 | 说明 |
|------|------|------|
| `doris_*` | 25 | Doris 数据仓库各表字段定义 |
| `mysql_gf_*` | 10 | MySQL 对伊情报库各表字段定义 |
| `carrier_*` | 3 | 旧版 CSV schema（已迁移至数据库，保留作为参考） |

### rag/ —— 领域知识库（6个文件）

| 文件 | 行数 | 用途 |
|------|------|------|
| `carrier_aircraft_kb.md` | 92 | 航母舰载机知识库（空间关联规则、Haversine公式） |
| `carrier_ais_kb.md` | 60 | AIS 异常监测知识库（判定规则、异常等级评估） |
| `carrier_intel_report.md` | 628 | 美军航母情报报告（11艘航母技术参数+动态） |
| `carrier_assessment_kb.md` | 196 | 航母态势评估知识库（状态判定/动向/意图/威胁） |
| `cvn73_washington_intel.md` | 131 | 华盛顿号（CVN-73）动态情报报告（2023-2025时间线） |
| `cvn73_2026_trajectory_kb.md` | 143 | CVN-73 2026年航迹分析知识库（航迹分段/态势评估规则） |

---

## 工具与临时文件

### scripts/ —— 项目工具脚本

| 文件 | 用途 |
|------|------|
| `scripts/build_dashboard.py` | **大屏构建脚本** —— 声明式 spec JSON → HTML（JSON Schema 深度校验/主题注入/数据转义） |
| `scripts/validate_html.py` | **HTML 验证工具** —— HTML 结构 + Node.js JS 语法 + 行为校验（核心QA基础设施） |
| `scripts/check_dashboard.py` | **行为校验** —— node 执行真实 `chart-builders.js` → 数据形状断言 → ECharts SSR 渲染非空 |
| `scripts/selftest.py` | **回归自测** —— 全部样例构建+验证（正例必过、构造负例必败） |

### temp/ —— 临时文件目录

智能体在任务执行中产生的 Python 脚本、中间 JSON 等临时文件统一写入此目录，任务结束后自动清理。不纳入版本控制。

---

## 输出层

### .opencode/agents/ —— 智能体清单

| 智能体 | 用途 |
|--------|------|
| `agent-generator.md` | **核心** —— 智能体设计顾问（3轮问答+内部决策树+自动生成） |

#### 智能体生成链路

生成的专业智能体通过 Boot Sequence 加载共享模块，分析结果统一以声明式 spec 构建 HTML 大屏（见 `shared/html-output.md`、`shared/qa-html.md`）。模板参考 `templates/analysis-agent.md`，spec 样例见 `templates/dashboard-spec-*.json`。

### html/ —— 离线情报大屏

所有 HTML 大屏均为离线单页应用，**由 `scripts/build_dashboard.py` 从声明式 spec 构建**，引用本地 `lib/` 资源，双击即可运行：

| 文件 | 行数 | 内容 |
|------|------|------|
| `sample-standard-dashboard.html` | 104 | 标准看板样例（bar/line/pie/table，机型对比） |
| `sample-map-dashboard.html` | 109 | 地图大屏样例（多类别标记+覆盖圈+轨迹线，台海打击） |
| `sample-echarts-dashboard.html` | 163 | 复杂图样例（echarts 力导向图透传 + 声明式图表） |
| `carrier-ais-abnormal-20260731.html` | 312 | 美航母 AIS 异常态势大屏（重建：地图+柱/线/饼） |
| `carrier-dual-arabian-20260731.html` | 164 | 双阿拉伯湾航母（CVN-73/里根号）部署态势大屏（重建） |
| `carrier-cvn73-wp-pattern-20260731.html` | 153 | CVN-73 西太平洋航迹模式分析大屏（重建） |

spec 样例位于 `templates/dashboard-spec-*.json`，可直接参照。存量大屏已统一重建为构建脚本产物，历史手写 HTML 不再维护。

### lib/ —— 离线前端库

| 库 | 用途 | 本地路径 |
|----|------|---------|
| ECharts 5.x | 地图/图表可视化 | `lib/echarts/echarts.min.js` |
| ECharts 世界地图 | 离线 GeoJSON 地图 | `lib/echarts-maps/world.js` |
| Chart.js 4.x | 统计图表（存量维护，新大屏统一 ECharts） | `lib/chartjs/chart.umd.min.js` |
| Font Awesome 6.x | 图标系统 | `lib/fontawesome/` |
| **Dashboard 主题** | 大屏共享深色主题（CSS 变量驱动，spec.theme 注入主色） | `lib/dashboard/dashboard.css` |
| **Dashboard 引擎** | 大屏声明式渲染引擎（读取 DASHBOARD_SPEC 渲染图表/KPI） | `lib/dashboard/dashboard.js` |
| **图表构建器** | 图表逻辑唯一实现（浏览器与行为校验共用，杜绝契约漂移） | `lib/dashboard/chart-builders.js` |

### data/ —— 手动拷贝的参考数据

手动放入的静态参考数据文件，供智能体分析时读取：

---

## 质量保障（QA）

### HTML 大屏构建与验证流程

大屏统一由构建脚本生成，智能体不手写 HTML：

```
智能体写声明式 spec JSON → python scripts/build_dashboard.py <spec> → html/<name>.html
                                                            ↓
                              python scripts/validate_html.py html/<name>.html
```

`scripts/validate_html.py` 提供自动化验证（三层防线）：

```
验证项：
  ✅ HTML 结构完整性
  ✅ 资源引用可访问性（相对路径、本地 lib/）
  ✅ Node.js JavaScript 语法检查
  ✅ 行为校验：node 执行真实 chart-builders 构建每个图表，
              数据形状断言（空数据/坏结构必败）+ ECharts SSR 真实渲染非空
  ✅ 离线可运行性确认
```

三层防线分工：

1. **构建期**：`build_dashboard.py` 按 `templates/dashboard-spec.schema.json`（JSON Schema 唯一契约）深度校验 spec，格式/数据形状非法当场报错，杜绝"结构合法但图空"
2. **验证期**：`validate_html.py`（结构+JS 语法）叠加 `check_dashboard.py`（浏览器同一份 `lib/dashboard/chart-builders.js` 在 node 中真实构建 + SSR 渲染非空）
3. **浏览器期**：`lib/dashboard/dashboard.js` 构建失败渲染红条（失败显性化）

每个生成的大屏必须通过验证方可交付。回归自测：`python scripts/selftest.py`（正例全过 + 构造负例必败）。spec 结构、图表类型、主题规范见 `shared/html-output.md`，质量流程见 `shared/qa-html.md`。

### 智能体质量要求

agent-generator 对每个新生成的智能体执行 7 项自检：

1. 数据源连接正确性
2. 模式库注入完整性
3. 领域知识覆盖度
4. SOP 流程可执行性
5. HTML 输出离线可用性
6. 验收测试指令可达性
7. 自我修复机制

---

## 快速参考

| 操作 | 方法 |
|------|------|
| 创建新智能体 | 切换到"智能体设计顾问"，描述需求 → 回答3个业务问题 |
| 验证新智能体 | 切换到新 agent，运行自动生成的验收测试指令 |
| 扩展数据库表 | 添加新表后，在 `config/db_sources.json` 注册，添加 `schema/*.md` |
| 扩展领域知识 | 向 `rag/` 添加新的知识库 .md 文件 |
| 扩展共享模块 | 向 `shared/` 添加新的 .md 文件，在模板 Boot Sequence 中引用 |
| 扩展分析脚本 | 向 `temp/` 添加临时分析脚本（任务结束后清理） |
| 扩展模板 | 创建新的 `templates/*.md`，在生成器的决策树中注册 |
| 扩展大屏样式 | 修改 `lib/dashboard/dashboard.css`（主题）或 `chart-builders.js`/`dashboard.js`（图表引擎） |
| 构建 HTML 大屏 | 运行 `python scripts/build_dashboard.py <spec.json>`（spec 结构见 `shared/html-output.md`） |
| 验证 HTML | 运行 `python scripts/validate_html.py html/<file>` |
| 查看生成的大屏 | 在浏览器中打开 `html/*.html`，或通过 `http://localhost:7001` |

---

## 设计理念

### 1. 业务语言优先
生成器使用参谋长能理解的业务语言对话，不抛出技术术语。
- ✓ "分析结果在哪里看？大屏还是报告？"
- ✗ "输出格式要HTML还是CSV？"
- ✓ "关注全球还是特定战区？"
- ✗ "用哪个模板生成？"

### 2. 模板对用户透明
模板是内部实现细节，用户只需要知道**他能得到什么能力的智能体**，不需要知道**用什么模板生成的**。

### 3. 生成的是"参谋"不是"脚本"
每个生成的 agent 拥有独立判断能力，能自主理解指令、选择工具、编排流程，解决"这一类"问题而非"这一个"问题。

### 4. 领域知识分层
| 层次 | 内容 | 存放位置 |
|------|------|---------|
| **参考数据** | 手动拷贝的静态参考数据 | `data/` |
| **数据库源** | Doris + MySQL 连接与表定义 | `config/db_sources.json` |
| **字段定义** | 字段说明与判读规则 | `schema/*.md` |
| **领域知识** | 知识库文件 | `rag/` |
| **共享过程知识** | DB连接、分析模式、QA流程、视觉主题等通用能力 | `shared/` |
| **前端资源** | 离线 HTML/JS/CSS 库 | `lib/` |

### 5. 离线优先
所有前端库、数据文件、知识库都在本地，生成的 HTML 大屏不依赖任何外部 CDN 或网络，双击即可运行。

### 6. 持续积累
`data/`、`schema/`、`rag/` 等目录随着每次任务不断积累完善——新的数据源、新的知识库、新的分析模式都能加入生态。
