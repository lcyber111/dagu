# 参考大屏资产库

> 精调过的高质量大屏交付物沉淀于此，作为智能体生成同类大屏的**参考模板（优先级高于从零设计）**。
> 智能体生成 HTML 前先读本索引，按任务类型 + 场景标签匹配参考，命中则参照其布局与视觉生成"差不多"的大屏。

> **关于 reference.html 的用法**：`reference.html` 是**视觉对照参考**（智能体读其 HTML 结构/布局骨架理解设计），并非独立可运行的成品——其资源路径指向原 `html/` 目录，浏览器打开请用源文件 `html/<name>.html`（路径见各资产 meta.json 的 `source`）。

## 资产索引

| 资产 id | 标题 | 任务类型 | 场景标签 | 优先级 |
|---------|------|---------|---------|--------|
| `uav-border-cluster` | 无人机边境集群态势大屏 | 综合评估,专项检测 | 无人机,边境,多源印证,态势 | gold |

## 使用方式（智能体）

1. 读本索引，按当前任务类型 + 用户指令关键词匹配候选
2. 命中多个时按优先级（gold > normal）取最匹配
3. 读取对应资产的 `layout-spec.json`（布局骨架）+ `reference.html`（视觉对照），用当前任务数据适配生成 spec
4. 未命中 → 按 `shared/analysis-runtime.md` Step 3.5 通用规范从零设计

## 入库流程（将优秀 HTML 提升为参考）

```bash
python scripts/import_reference.py html/<name>.html \
  --id <kebab-id> --title "<中文标题>" \
  --task-types 综合评估,专项检测 --tags 无人机,边境,多源印证
```

脚本自动：反向提取 spec → 生成 `references/<id>/`（layout-spec.json + reference.html + meta.json）→ 更新本索引。
