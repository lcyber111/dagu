# HTML 输出模块化改造计划

> 目标版本：2026-07
> 状态：已实施（含加固：JSON Schema 单一契约 + 数据形状不变量 + ECharts SSR 行为校验 + 存量重建）
> 关联：`README.md`、`shared/*`、`templates/*`、`scripts/*`、`lib/*`、`.opencode/agents/*`

---

## 一、本次要解决的问题

当前所有 HTML 大屏由智能体**每次从零手写**，单体文件 547~900 行（CSS + HTML + JS + 内嵌 JSON 一体），存在 4 个问题：

| # | 问题 | 证据 |
|---|------|------|
| 1 | **样板代码重复** | 10/10 文件都有 `echarts.init` / `registerMap` / `resize`；5/10 引入 Chart.js |
| 2 | **CSS 风格漂移** | `us-carrier-ais-anomaly-20260728.html` 与 `khamenei-relation-network-20260721.html` 卡片/表头/滚动条互不一致 |
| 3 | **Token 消耗高** | 每次生成 600-900 行，大量浪费在抄样板 |
| 4 | **语法错误率高** | 骨架/CSS/接线 JS 是 LLM 最易写错的部分，靠 `qa-html.md` 的"3 轮修正"兜底 |

另有两个**存量冲突**，本计划的处理方式随"改造完成后删除旧智能体与旧 HTML"的决定一并简化：

- **内联副本作废**：旧智能体（如 `us-carrier-ais-anomaly-detector.md` L447/480/532）内联了"7项自检""工具使用指南""视觉方案"的旧版副本，同时又在读 shared 模块。由于**旧智能体将被删除**，该冲突随删除消失，**无需**再向 shared 文档添加"作废声明"。
- **Chart.js 依赖**：`lib/chartjs/chart.umd.min.js` 被 5 个存量大屏实际使用。旧大屏删除后"存量维护"理由消失，新流程统一 ECharts；库文件保留（零成本）但文档不再作为产出路径描述。

---

## 二、方案概述

把"智能体手写 HTML"改为**「声明式 spec + 共享静态资产 + 构建脚本渲染」**：

```
智能体产出 spec JSON（声明式，约100-250行）
        │
        ▼
python scripts/build_dashboard.py spec.json
        │  读取 spec → 严格校验 → 注入 theme → 组装样板 → 转义数据 → 输出
        ▼
html/<name>.html（完整大屏，与现在同构）
```

分工原则：

| 谁 | 做什么 |
|----|--------|
| `lib/dashboard/dashboard.css` + `dashboard.js` | 样板一次性写好并验证，**永久复用**（骨架/CSS/echarts接线/KPI动画/表格渲染） |
| `scripts/build_dashboard.py` | 拼装器：JSON 严格校验失败立即报错终止，杜绝"生成800行HTML再碰运气修" |
| 智能体 | 只产出 spec JSON（数据 + 图表声明 + 布局声明），LLM 出错面大幅收窄 |

**布局与表达不降级**：不同任务（航母态势/舰载机对比/哈梅内伊关系）通过 spec 的 `rows` 布局声明 + 6 类图表类型呈现不同格局；复杂图（力导向图、多层覆盖圈）走 `echarts` 一等公民透传，option 本体仍由智能体编写。

---

## 三、详细设计

### 3.1 spec JSON schema（智能体唯一产出物）

```jsonc
{
  "name": "us-carrier-ais-anomaly-20260728",   // 输出文件名（kebab-case）
  "title": "美航母AIS异常态势监控大屏",
  "title_en": "US CARRIER AIS ANOMALY",        // 可选，标题栏大写区
  "subtitle": "美航母AIS异常态势监控 · 过去6个月",
  "time": "2026-07-28 17:54:10",
  "refresh": 300,                              // 可选，自动刷新秒数
  "header_icon": "fas fa-satellite",           // 可选，FontAwesome 图标
  "theme": {                                   // 可选，缺省=军绿（表3.2）
    "primary": "#ff6b00",                      // 主色（支持表外自定义色）
    "background": "#0a0e17"                    // 可选，背景色
  },
  "footer": [{"label": "数据来源", "value": "Doris · ais_ship_track"}],

  "kpis": [                                    // 数量/含义随任务变化
    {"label": "监测航母数", "value": {"text": "9"}, "color": "#00ff88", "sub": "异常总数"},
    {"label": "身份层级", "value": {"text": "63", "sub": "/131/29"}, "color": "#ffd93d"}
  ],

  "rows": [                                    // 布局声明 —— 决定大屏格局
    {"grid": "2fr 1fr", "cells": [
      {"chart": "mapChart"},
      {"stack": ["barChart", "trendChart"]}    // 右侧纵排两个小图
    ]},
    {"grid": "1fr 1fr", "cells": [{"chart": "pieChart"}, {"chart": "seaChart"}]},
    {"grid": "1fr", "cells": [{"table": "eventTable"}]}
  ],

  "charts": [
    {"id": "mapChart", "title": "全球态势地图 · 异常事件分布", "type": "map", "height": 520,
     "markers":   [{"category": "off", "value": [62, 22], "name": "CVN-72", "extra": {...}}],
     "categories": {"off": {"color": "#ff0044", "effect": true, "symbol": "diamond", "size": 14}},
     "lines":   [{"coords": [[62,22],[63,23]], "color": "#ff0044"}],
     "circles": [{"center": [62,22], "radiusKm": 300, "color": "rgba(255,68,68,0.4)"}],
     "legend": ["初始位置", "AIS ON", "AIS OFF"],
     "tooltip": [{"label": "舷号", "field": "hull_no"}, {"label": "时间", "field": "time"}]},

    {"id": "barChart", "title": "各航母异常次数对比", "type": "bar", "height": 260,
     "data": {"categories": [...], "series": [...], "unit": "次"}},

    {"id": "pieChart", "title": "异常类型分布", "type": "pie", "height": 260,
     "data": {"values": [{"name": "...", "value": 12}]}},

    // 复杂图一等公民：完整 ECharts option 透传（力导向图等）
    {"id": "forceChart", "title": "关系网络", "type": "echarts",
     "height": 450, "option": {"series": [{"type": "graph", "layout": "force", ...}]}}
  ],

  "tables": [
    {"title": "异常事件清单", "id": "eventTable", "maxHeight": 320,
     "columns": ["时间", "航母", "类型"],
     "rows": [["2026-02-19 02:54", "尼米兹号", "Initial AIS ON"], ...],
     "formatters": {"类型": {"tag": {"初始位置": "tag-init", "AIS OFF": "tag-off", "AIS ON": "tag-on"}}}}
  ]
}
```

### 3.2 图表类型集合（6 类）

| 类型 | 说明 | 典型场景 |
|------|------|---------|
| `map` | 声明式地理图：多类别标记 + 轨迹线 + 覆盖圈 + 标签 | 航母AIS、台海打击覆盖 |
| `bar` / `line` / `pie` / `scatter` | 声明式统计图（统一 ECharts） | 对比/趋势/分布 |
| `echarts` | **一等公民** option 透传（非"兜底"） | 力导向图等复杂图 |

**主题单一来源**：领域色表（军绿 `#00ff88`、蓝 `#00a6ff`、金 `#ffd93d`、红 `#ff6b6b`、紫 `#c882ff`、青 `#00d4aa`）迁入 `shared/viz-dark-theme.md`，`build_dashboard.py` 消费 `spec.theme`，缺省军绿；`theme` 允许表外自定义色（承接 strike 的 `#ff6b00`）。

**KPI 值结构化**：`value` 支持 `{"text": "9"}` 或 `{"text": "63", "sub": "/131/29"}`（sub 渲染为灰小字），**禁止智能体注入原始 HTML**。

**单元格样式白名单**：`formatters` 仅支持 `tag`（映射到内置 tag 类）与颜色映射，不做裸 HTML 模板。

### 3.3 build_dashboard.py 职责

1. **严格校验**：JSON 可解析、必填字段、chart 类型在允许表内、`rows` 引用的 chart/table id 必须存在、`echarts` 类型 `option.series` 必须为数组——任一不通过立即报错退出
2. **theme 注入**：按 `spec.theme` 输出 `:root{...}` CSS 变量覆盖段
3. **样板组装**：加载 `dashboard.css` / `dashboard.js` 引用 + 渲染 header/KPI/rows/图表容器/表格/footer
4. **数据转义**：内嵌数据中的 `</script>`、控制字符等转义，杜绝注入破坏页面
5. **输出摘要**：打印生成路径与行数，供智能体确认后接 `validate_html.py`

### 3.4 共享静态资产

- `lib/dashboard/dashboard.css`：CSS 变量驱动的深色主题（header/KPI/card/grid/table/tag/footer/滚动条/图例/动画/响应式），默认军绿
- `lib/dashboard/dashboard.js`：`initMap()`（init+registerMap+resize+错误边界）、KPI 计数动画、表格渲染器、Chart.js 初始化助手（库文件保留备选，新流程统一 ECharts）

---

## 四、文件清单

### 新增 6 个

| 文件 | 内容 |
|------|------|
| `lib/dashboard/dashboard.css` | 共享主题样式（CSS 变量） |
| `lib/dashboard/dashboard.js` | 共享 JS 助手 |
| `scripts/build_dashboard.py` | 渲染器（校验/渲染/转义/theme） |
| `templates/dashboard-spec-example.json` | 标准看板冒烟样例（bar/line/pie/table） |
| `templates/dashboard-spec-map-example.json` | 地图冒烟样例（多类标记+覆盖圈+轨迹线） |
| `templates/dashboard-spec-echarts-example.json` | 透传冒烟样例（力导向图） |

### 修改 6 个

| 文件 | 改动 |
|------|------|
| `shared/html-output.md` | 改为构建脚本流程（新流程统一 ECharts；Chart.js 库保留但不再作为产出路径） |
| `shared/qa-html.md` | 三步流程（写 spec → 跑 build → validate_html.py）+ 保留 3 轮修正（透传 option 语义错误） |
| `shared/viz-dark-theme.md` | 迁入 6 领域色表（单一来源） |
| `templates/analysis-agent.md` | Step 3.5 改为 spec 流程；Boot Sequence 引用更新 |
| `.opencode/agents/agent-generator.md` | 领域色表改为引用 shared/viz-dark-theme.md；`{{dashboard_layout}}` 规则；self-check #5 更新 |
| `README.md` | 架构图/QA/快速参考章节反映新链路 |

> 相比旧版计划**减少 1 个改动文件**（`shared/tools-guide.md` 无需再加"作废声明"），并**移除全部"内联版本作废"声明**——旧智能体与旧大屏将被删除，冲突源消失。

### 存量处理（改造完成并验证通过后删除）

- 现有 10 个大屏 `html/*.html` **全部删除**
- 旧生成智能体 `.opencode/agents/us-carrier-ais-anomaly-detector.md` **删除**
- **保留** `.opencode/agents/agent-generator.md`（核心生成器，随计划更新，不可删）
- 删除在**步骤 5 端到端验证通过后**执行；项目已纳入 git，删除后可随时从版本库恢复
- README 中提到的 `khamenei-network-intel.md` / `simulated-strike-process-intel.md` 当前磁盘不存在（文档过时），无需处理

---

## 五、实施顺序与验证

| 步骤 | 内容 | 验证 |
|------|------|------|
| 0 | **洞C 反推**：用 `strike-analysis` 地图 + `khamenei-network` 力导向图反推为 spec，确认 schema 可完整表达 | 反推对照表 |
| 1 | 写 `dashboard.css`（CSS 变量）+ `dashboard.js` | — |
| 2 | 写 `build_dashboard.py`（含 theme 注入 + 三类一等校验） | 错误 spec 能报错退出 |
| 3 | 写 3 个 spec 样例 → 跑 `build_dashboard.py` + `validate_html.py` | 三类样例全部双通过 |
| 4 | 更新 6 个文档（含措辞降预期） | — |
| 5 | 端到端：新流程重跑一个现有分析任务（此时旧大屏仍保留作视觉基线） | 产出大屏视觉/结构一致 |
| 6 | **清理**：删除 `html/*.html` 全部旧大屏 + `.opencode/agents/us-carrier-ais-anomaly-detector.md` | 目录内仅剩新产物；git 可回退 |

---

## 六、措辞与预期管理

- **对标准图表场景**（柱/饼/折线/表格/声明式地图）：显著降低语法错误、token 消耗、风格漂移
- **对复杂场景**（力导向图、多层覆盖圈）：脚本负责接线与校验，option 本体仍由智能体编写，**语义错误仍需迭代修正**（3 轮修正机制保留）
- 文档中不写"60-70% 错误消除""不再需要 3 轮修正"这类绝对化表述

---

## 七、兼容性与回退

- `../lib/dashboard/*` 依赖方式与现有 `../lib/echarts` 完全一致，离线双击 / 浏览器 / localhost:7001 均不受影响
- `echarts` 透传与 `custom` 原样注入段保证表达力不降级
- **旧产物删除策略**：步骤 5 端到端验证通过后才执行删除；项目已纳入 git，如需回退旧智能体/旧大屏，从版本库恢复即可
- 若在删除后发现问题，新产物与旧产物互不冲突（不同文件名），可并行共存排查
