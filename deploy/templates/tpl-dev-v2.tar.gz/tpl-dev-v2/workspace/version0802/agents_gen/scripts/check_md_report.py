"""
大屏配套 MD 校验器
用法: python scripts/check_md_report.py <md文件路径>
返回: 通过输出 "OK" (exit 0)，失败输出错误列表 (exit 1)

校验项:
  ✅ 文件存在且非空
  ✅ 五章必备标题齐全（前缀正则匹配，容忍空格/全角标点差异）
  ✅ 每章标题后非空正文（剔除标题/引用/空行后仍含 CJK 文本）
  ✅ 头部含 "配套大屏" 字段且带 html/ 相对路径（不校验 URL 可访问性）
  ✅ 配套大屏真实存在（同目录 html/<base>.html）
"""

import os
import re
import sys

# 五章必备标题（章节号 + 关键词），前缀正则容忍排版差异
REQUIRED_SECTIONS = [
    (1, "用户需求分析"),
    (2, "数据来源与取数逻辑"),
    (3, "分析逻辑与判据"),
    (4, "关键发现与结论"),
    (5, "数据时效与局限"),
]

HEADING_RE = re.compile(r"^#{1,6}\s+(.+?)\s*$")
# 章节标题前缀正则：`## N` 后可带半/全角句点或冒号及任意空格，容忍 agent 排版差异
SECTION_HEAD_RE = re.compile(r"^##\s*([1-5])\s*(?:[.．:：]\s*)?")
CJK_RE = re.compile(r"[\u4e00-\u9fff]")


def _strip_md(s):
    """剔除引用行/标题行/空行/行内 markdown 标记后的纯文本。"""
    lines = []
    for ln in s.split("\n"):
        t = ln.strip()
        if not t:
            continue
        if t.startswith(">"):
            continue
        if re.match(r"^#{1,6}\s+", t):
            continue
        t = re.sub(r"^[-*+]\s+", "", t)
        t = re.sub(r"`([^`]*)`", r"\1", t)
        t = re.sub(r"\*\*([^*]+)\*\*", r"\1", t)
        lines.append(t)
    return "\n".join(lines)


def _section_ranges(lines):
    """按 '## N.' 标题切分各章节 [start, end) 行区间。标题本身属于该节头部。"""
    markers = []
    for i, ln in enumerate(lines):
        m = SECTION_HEAD_RE.match(ln.strip())
        if m:
            markers.append((i, int(m.group(1))))
    ranges = []
    for idx, (i, num) in enumerate(markers):
        end = markers[idx + 1][0] if idx + 1 < len(markers) else len(lines)
        ranges.append((num, lines[i:end]))
    return ranges


def check(path):
    """校验单个 md 文件，返回错误列表（空 = 通过）。"""
    errors = []
    if not os.path.isfile(path):
        return [f"文件不存在: {path}"]
    with open(path, "r", encoding="utf-8") as f:
        content = f.read()
    if not content.strip():
        return [f"文件为空: {path}"]

    lines = content.split("\n")

    # 1. 五章标题齐全（前缀正则）
    found = {}
    for ln in lines:
        m = SECTION_HEAD_RE.match(ln.strip())
        if m:
            found[int(m.group(1))] = ln.strip()
    for num, kw in REQUIRED_SECTIONS:
        got = found.get(num)
        if not got:
            errors.append(f"缺必备章节 ## {num}. {kw}")
        elif kw not in got:
            errors.append(f"章节 {num} 标题不符（应为「## {num}. {kw}」，实际「{got}」）")

    # 2. 每节非空正文
    for num, body in _section_ranges(lines):
        stripped = _strip_md("\n".join(body))
        if not CJK_RE.search(stripped):
            errors.append(f"章节 {num} 正文为空（标题/引用/空行之外需有中文内容）")

    # 3. 头部 配套大屏 字段（相对路径占位）
    head = content[:800]
    if "配套大屏" not in head:
        errors.append("头部缺少「配套大屏」字段")
    elif not re.search(r"配套大屏[^\n]*html/", head):
        errors.append("「配套大屏」字段应为相对路径 html/<name>.html")

    # 4. 配套大屏真实存在
    base = os.path.basename(path)
    if base.endswith(".md"):
        html_path = os.path.join(os.path.dirname(path), base[:-3] + ".html")
        if not os.path.isfile(html_path):
            errors.append(f"配套大屏不存在: {html_path}")
    else:
        errors.append(f"文件名应以 .md 结尾: {base}")

    return errors


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if any(a in ("-h", "--help") for a in sys.argv[1:]) or not args:
        print(__doc__)
        sys.exit(0)
    path = args[0]
    errors = check(path)
    if errors:
        print("MD 校验失败:")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    print("OK")
    sys.exit(0)


if __name__ == "__main__":
    main()
