"""test_db_query.py — db_query 网关单元测试（不依赖真实数据库）
用法: python scripts/test_db_query.py
"""
import contextlib
import io
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import db_query  # noqa: E402


class TestReadOnly(unittest.TestCase):
    def test_rejects_dml(self):
        for sql in ['DELETE FROM t', 'INSERT INTO t VALUES (1)',
                    'UPDATE t SET a=1', 'DROP TABLE t', 'TRUNCATE t',
                    'CREATE TABLE t(a int)']:
            self.assertFalse(db_query._check_readonly(sql), sql)

    def test_rejects_with_dml_bypass(self):
        # F2：WITH + DML 单语句穿透
        for sql in ['WITH c AS (SELECT 1) DELETE FROM t',
                    'WITH c AS (SELECT 1) UPDATE t SET a=1',
                    'WITH c AS (SELECT 1) INSERT INTO t VALUES (1)']:
            self.assertFalse(db_query._check_readonly(sql), sql)

    def test_rejects_multi_statement(self):
        # F2：多语句注入（SELECT 后接 DML）
        self.assertFalse(db_query._check_readonly('SELECT 1; DROP TABLE t'), '多语句')

    def test_accepts_selects(self):
        for sql in ['SELECT * FROM standard.ais_ship_track', 'SELECT 1',
                    'SHOW TABLES', 'DESCRIBE communication', 'EXPLAIN SELECT 1',
                    'WITH c AS (SELECT 1) SELECT * FROM c',
                    'select * from t;', '/* note */ SELECT 1', '-- note\nSELECT 1',
                    "SELECT * FROM t WHERE note='DELETE'",
                    "SELECT * FROM t WHERE note='limit 5'"]:
            self.assertTrue(db_query._check_readonly(sql), sql)


class TestApplyLimit(unittest.TestCase):
    def test_appends_when_missing(self):
        self.assertTrue(db_query._apply_limit('SELECT * FROM t', 1000).endswith('LIMIT 1000'))

    def test_keeps_existing(self):
        self.assertEqual(db_query._apply_limit('SELECT * FROM t LIMIT 50', 1000),
                         'SELECT * FROM t LIMIT 50')

    def test_handles_semicolon(self):
        self.assertTrue(db_query._apply_limit('SELECT * FROM t;', 1000).endswith('LIMIT 1000'))

    def test_clamps_huge_limit(self):
        # F1：显式超大 LIMIT 收敛到上限
        self.assertEqual(db_query._apply_limit('SELECT * FROM t LIMIT 100000000', 1000),
                         'SELECT * FROM t LIMIT 1000')

    def test_string_literal_limit_not_detected(self):
        # F1：字符串字面量里的 'limit 5' 不误判为已有 LIMIT → 追加
        self.assertTrue(db_query._apply_limit("SELECT * FROM t WHERE note='limit 5'", 1000)
                        .endswith('LIMIT 1000'))

    def test_trailing_comment_not_swallow_limit(self):
        # F1：尾随注释不再吞掉追加的 LIMIT
        sql = db_query._apply_limit('SELECT * FROM t -- 只读', 1000)
        self.assertTrue(sql.endswith('LIMIT 1000'))
        self.assertNotIn('--', sql.split('LIMIT')[0].strip() or 'x')


class TestTables(unittest.TestCase):
    def test_doris(self):
        out = db_query.tables('doris')
        self.assertTrue(out['ok'], out)
        names = {t['name'] for t in out['tables']}
        self.assertIn('ais_ship_track', names)

    def test_mysql(self):
        out = db_query.tables('mysql_gf')
        self.assertTrue(out['ok'], out)
        names = {t['name'] for t in out['tables']}
        self.assertIn('communication', names)

    def test_unknown_source(self):
        out = db_query.tables('nope')
        self.assertFalse(out['ok'])


class TestSchemaFile(unittest.TestCase):
    def test_existing_schema_file_kept(self):
        out = db_query.tables('doris')
        t = next(x for x in out['tables'] if x['name'] == 'ais_ship_track')
        self.assertEqual(t['schema_file'], 'schema/doris_ais_ship_track.md')

    def test_missing_schema_file_is_none(self):
        # schema_file 指向不存在的文件 → 返回 null（列元数据以 --schema 为唯一来源的兜底）
        out = db_query.tables('doris')
        t = next(x for x in out['tables'] if x['name'] == 'carrier_equipment_relation')
        self.assertEqual(t['schema_file'], 'schema/doris_carrier_equipment_relation.md')

    def test_all_doris_tables_have_schema_file(self):
        # Task 2：Doris 全部表已建档（判读规则 + 探查档案两段式），schema_file 均应指向存在的文件
        out = db_query.tables('doris')
        for t in out['tables']:
            self.assertTrue(t['schema_file'], f"{t['name']} 缺 schema_file")
            self.assertTrue(os.path.exists(os.path.join(db_query.ROOT, t['schema_file'])),
                            f"{t['name']} schema_file 不存在: {t['schema_file']}")


class TestSchemaResolution(unittest.TestCase):
    def test_doris_uses_registry_database(self):
        # doris 源无顶层 database，需从注册表 tables 解析出 standard
        cfg = db_query._load_cfg()['doris']
        self.assertIsNone(cfg.get('database'))
        self.assertEqual(cfg['tables']['ais_ship_track']['database'], 'standard')

    def test_unknown_table_errors(self):
        out = db_query.schema('doris', 'not_a_table')
        self.assertFalse(out['ok'])
        self.assertIn('database', out['error'])


class TestCli(unittest.TestCase):
    def _run(self, argv):
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            with self.assertRaises(SystemExit) as cm:
                db_query.main(argv)
        return cm.exception.code

    def test_sources(self):
        self.assertEqual(self._run(['--sources']), 0)

    def test_non_readonly_rejected(self):
        self.assertEqual(self._run(['--source', 'doris', '--sql', 'DELETE FROM t']), 1)


if __name__ == '__main__':
    unittest.main()
