#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTML 大屏静态文件服务
====================
提供 html/ 目录下的 HTML 大屏文件及其依赖资源（lib/）的访问服务。

URL 规则（对外访问路径）：
  {PUBLIC_BASE_URL}/app-proxy/{侦听端口}/html/...
  例：PUBLIC_BASE_URL=http://106.63.8.234:9088，侦听端口 9088
      → http://106.63.8.234:9088/app-proxy/9088/html/xxx.html

服务主机解析优先级（自上而下，先命中者生效）：
  1. 环境变量 APP_PROXY_BASE_URL（OCC2 多租户网关注入，形如 http://IP:9088/app-proxy）
     或 PUBLIC_BASE_URL（形如 http://IP:9088）——取其中端口作为默认端口
  2. config/server.json 的 baseUrl，如 http://106.63.8.234:7001
  3. 兜底：0.0.0.0:9088
  端口优先级：环境变量 PORT > 上述代理基址中的端口 > 9088。
  监听地址固定 0.0.0.0（OCC2 规范，允许中央网关跨 occ-net 代理）。
  --host / --port（或环境变量 PORT）可显式覆盖上述默认值。

前缀说明：
  - 服务默认同时支持两种路径（兼容反向代理剥离/透传两种场景）：
      带前缀:  /app-proxy/{port}/html/...   （对外 URL 规则）
      无前缀:  /html/...                    （本机直连/代理已剥离前缀）
  - --prefix 可覆盖前缀（传空字符串 "" 可关闭前缀支持）。

设计说明：
  - 安全白名单：仅开放 /html/ 与 /lib/ 两个路径（含前缀形式），
    其余请求一律 403，避免泄露 config/db_sources.json（数据库凭据）、
    .opencode/agents/、schema/、shared/ 等敏感文件。
  - 生成的 HTML 通过相对路径引用资源（如 ../lib/echarts/echarts.min.js），
    因此服务根目录为项目根目录，白名单保证 html/ 与 lib/ 的相对关系不变。
  - 根路径 / 自动重定向到 /html/ 文件列表，方便查看所有大屏。
  - 服务固定监听 0.0.0.0（OCC2 规范），通过端口映射或中央网关
    （/app-proxy/{port}）对外访问。
  - 仅使用 Python 标准库，离线环境可用，无需 pip 安装。

访问方式（端口 9088 示例）：
  大屏列表:    http://<host>:9088/app-proxy/9088/        （自动跳转 /html/）
  HTML 文件:  http://<host>:9088/app-proxy/9088/html/<文件名>.html
  静态资源:   http://<host>:9088/app-proxy/9088/lib/...

用法：
  python3 scripts/serve_html.py                # 使用 APP_PROXY_BASE_URL/PUBLIC_BASE_URL/config/server.json
  APP_PROXY_BASE_URL=http://1.2.3.4:9088/app-proxy python3 scripts/serve_html.py
  python3 scripts/serve_html.py --port 9088
  python3 scripts/serve_html.py --host 0.0.0.0
  python3 scripts/serve_html.py --prefix ""    # 关闭 /app-proxy/{port} 前缀
  python3 scripts/serve_html.py --root /path/to/project
"""

import argparse
import json
import mimetypes
import os
import socket
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "server.json")

# 常见前端资源 MIME 类型兜底，避免浏览器以错误类型解析
mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("application/json", ".json")
mimetypes.add_type("application/geo+json", ".geojson")
mimetypes.add_type("image/svg+xml", ".svg")


def _split_url(url: str):
    """从 baseUrl 字符串解析出 (host, port)；解析失败返回 (None, None)。"""
    if not url:
        return None, None
    if "://" not in url:
        url = "//" + url
    try:
        parts = urlsplit(url)
        return parts.hostname, parts.port
    except Exception:
        return None, None


def env_proxy_base_url():
    """读取环境变量中的代理基址。

    OCC2 多租户网关注入 APP_PROXY_BASE_URL（形如 http://IP:9088/app-proxy）；
    兼容 PUBLIC_BASE_URL（形如 http://IP:9088）。
    返回统一为"去尾斜杠、剥掉 /app-proxy 后缀"的展示基址；未设置返回空串。
    """
    env = os.environ.get("APP_PROXY_BASE_URL", "") or os.environ.get("PUBLIC_BASE_URL", "")
    env = env.rstrip("/")
    if not env:
        return ""
    suffix = "/app-proxy"
    if env.endswith(suffix):
        env = env[: -len(suffix)]
    return env


def read_default_host_port():
    """解析默认监听地址。

    监听地址固定为 0.0.0.0（OCC2 规范：允许中央网关跨 occ-net 代理），
    仅端口需解析。端口优先级：环境变量 PORT > 代理基址中的端口 > server.json > 9088。
    返回 (host, port)。
    """
    try:
        port_env = int(os.environ.get("PORT", ""))
    except (TypeError, ValueError):
        port_env = None

    env = env_proxy_base_url()
    if env:
        host, port = _split_url(env)
        if host:
            return "0.0.0.0", (port_env or port or 9088)
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        host, port = _split_url(cfg.get("baseUrl", ""))
        if host:
            return "0.0.0.0", (port_env or port or 9088)
    except Exception:
        pass
    return "0.0.0.0", (port_env or 9088)


def public_base_url():
    """用于展示的对外访问地址：优先环境变量（APP_PROXY_BASE_URL / PUBLIC_BASE_URL），其次 config/server.json。"""
    base = env_proxy_base_url()
    if base:
        return base
    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        base = cfg.get("baseUrl", "")
        if base:
            return base.rstrip("/")
    except Exception:
        pass
    return ""


class ProjectHandler(SimpleHTTPRequestHandler):
    """仅开放 html/ 与 lib/ 白名单路径的静态文件服务（支持 /app-proxy/{port} 前缀）。"""

    def __init__(self, *args, prefix="", **kwargs):
        self.prefix = prefix.rstrip("/")  # 如 "/app-proxy/9088"
        directory = kwargs.pop("directory", PROJECT_ROOT)
        super().__init__(*args, directory=directory, **kwargs)

    def _process_path(self):
        """归一化 URL 路径：剥离 /app-proxy/{port} 前缀并改写 self.path。

        返回动作字符串：'serve' | 'redirect' | 'forbidden'
        - 剥离前缀后为空 → 根路径 → redirect
        - 仅命中 /html/ /lib/ 白名单 → serve
        - 其余 → forbidden（含路径穿越、越权目录）
        """
        raw_path = self.path
        path = unquote(urlsplit(raw_path).path)
        query = urlsplit(raw_path).query

        if self.prefix:
            if path == self.prefix:
                path = "/"
            elif path.startswith(self.prefix + "/"):
                path = path[len(self.prefix):] or "/"

        # 回写 self.path（保留 query），后续 translate_path 基于归一化路径解析
        self.path = path + ("?" + query if query else "")

        if path != "/" and not (path.startswith("/html") or path.startswith("/lib")):
            return "forbidden"
        if path == "/":
            return "redirect"
        # 第二道闸门：真实文件系统路径必须落在 html/ 或 lib/ 目录内
        if not self._real_allowed():
            return "forbidden"
        return "serve"

    def _real_allowed(self) -> bool:
        """文件系统真实路径校验：规范化（..）后必须仍落在 html/ 或 lib/ 目录内。

        这是防路径穿越的第二道闸门——URL 前缀检查无法拦截
        /html/../../config/db_sources.json 这类经过 ../ 回退的请求。
        """
        translated = self.translate_path(self.path)
        real = os.path.realpath(translated)
        root = os.path.realpath(self.directory)
        for base in (os.path.join(root, "html"), os.path.join(root, "lib")):
            if real == base or real.startswith(base + os.sep):
                return True
        return False

    def _redirect_to_listing(self):
        """根路径重定向到 /html/ 大屏列表（保留 /app-proxy/{port} 前缀）。"""
        self.send_response(302)
        self.send_header("Location", self.prefix + "/html/")
        self.end_headers()

    def do_GET(self):
        action = self._process_path()
        if action == "forbidden":
            self.send_error(403, "Forbidden")
            return
        if action == "redirect":
            self._redirect_to_listing()
            return
        super().do_GET()

    def do_HEAD(self):
        action = self._process_path()
        if action == "forbidden":
            self.send_error(403, "Forbidden")
            return
        if action == "redirect":
            self._redirect_to_listing()
            return
        super().do_HEAD()

    def end_headers(self):
        # 禁止浏览器缓存旧版大屏，避免更新后看到过期内容
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))


def build_server(host: str, port: int, root: str, prefix: str):
    """按 host 创建服务；绑定失败（如端口被占用）时退出并提示。"""
    handler = lambda *a, **kw: ProjectHandler(*a, directory=root, prefix=prefix, **kw)
    try:
        return ThreadingHTTPServer((host, port), handler), host
    except OSError as e:
        print(f"启动失败：{e}（host={host} port={port}）", file=sys.stderr)
        sys.exit(1)


def main():
    default_host, default_port = read_default_host_port()

    parser = argparse.ArgumentParser(description="HTML 大屏静态文件服务（白名单模式）")
    parser.add_argument(
        "--host",
        default=default_host,
        help=f"监听地址，默认取 PUBLIC_BASE_URL / config/server.json（当前：{default_host}）",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=int(os.environ.get("PORT", default_port)),
        help=f"监听端口，默认取 PUBLIC_BASE_URL / config/server.json（当前：{default_port}）",
    )
    parser.add_argument(
        "--prefix",
        default="",
        help='URL 路径前缀，默认 "/app-proxy/{port}"；传 "" 可关闭前缀支持',
    )
    parser.add_argument(
        "--root",
        default=PROJECT_ROOT,
        help="服务根目录，默认项目根目录（保证 html/ 与 lib/ 相对路径不变）",
    )
    args = parser.parse_args()

    if not args.prefix:
        args.prefix = f"/app-proxy/{args.port}"

    if not os.path.isdir(os.path.join(args.root, "html")):
        print("错误：找不到 html/ 目录，请确认在项目根目录运行。", file=sys.stderr)
        sys.exit(1)

    server, bind_host = build_server(args.host, args.port, args.root, args.prefix)

    public = public_base_url()
    ext_host = socket.gethostbyname(socket.gethostname())
    latest = ""
    html_dir = os.path.join(args.root, "html")
    if os.path.isdir(html_dir):
        files = sorted(f for f in os.listdir(html_dir) if f.endswith(".html"))
        if files:
            latest = files[-1]

    print("=" * 60)
    print("HTML 大屏文件服务已启动（白名单：仅 /html/ 与 /lib/）")
    print(f"  监听地址:  {bind_host}:{args.port}")
    print(f"  路径前缀:  {args.prefix}")
    if public:
        print(f"  对外访问:  {public}{args.prefix}/")
        print(f"  大屏列表:  {public}{args.prefix}/html/")
        if latest:
            print(f"  大屏示例:  {public}{args.prefix}/html/{latest}")
    else:
        print(f"  本机访问:  http://127.0.0.1:{args.port}{args.prefix}/")
        print(f"  内网访问:  http://{ext_host}:{args.port}{args.prefix}/")
        print(f"  大屏列表:  http://127.0.0.1:{args.port}{args.prefix}/html/")
    print(f"  服务根目录: {args.root}")
    print("  Ctrl+C 停止服务")
    print("=" * 60)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止。")
        server.server_close()


if __name__ == "__main__":
    main()
