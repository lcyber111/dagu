"""test_capability_matrix.py — 能力矩阵交叉引用一致性测试
用法: python scripts/test_capability_matrix.py
校验:
  1. patterns[].module 对应 lib/analysis/ 模块文件存在
  2. patterns[].rule_source 文件存在于 rag/
  3. table_rules[].tables 的表名存在于 config/db_sources.json 对应源
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))

failures = []


def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def main():
    matrix = load(os.path.join(ROOT, 'config', 'capability-matrix.json'))
    cfg = load(os.path.join(ROOT, 'config', 'db_sources.json'))

    # 1. patterns module / rule_source 文件存在
    for pid, p in matrix.get('patterns', {}).items():
        mod = p['module'].replace('.', os.sep) + '.py'
        if not os.path.exists(os.path.join(ROOT, mod)):
            failures.append(f'patterns[{pid}].module 文件不存在: {mod}')
        if not os.path.exists(os.path.join(ROOT, p['rule_source'])):
            failures.append(f'patterns[{pid}].rule_source 文件不存在: {p["rule_source"]}')

    # 2. table_rules[].tables 存在（按 source 查对应源的表清单）
    for i, r in enumerate(matrix.get('table_rules', [])):
        source = r.get('when', {}).get('source', 'doris')
        tbls = cfg.get(source, {}).get('tables', {})
        for t in r.get('tables', []):
            bare = t.split('.')[-1]
            if bare not in tbls:
                failures.append(f'table_rules[{i}] 表不存在于 {source}: {t}')

    if failures:
        print('[FAIL] capability-matrix 一致性')
        for f in failures:
            print(f'  - {f}')
        sys.exit(1)
    print('OK capability-matrix: patterns={} table_rules={}'.format(
        len(matrix.get('patterns', {})), len(matrix.get('table_rules', []))))
    sys.exit(0)


if __name__ == '__main__':
    main()
