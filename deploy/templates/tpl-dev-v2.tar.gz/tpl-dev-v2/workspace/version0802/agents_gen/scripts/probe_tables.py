"""probe_tables.py — Doris 注册表只读探查，产出每表定量探查档案 markdown

用法: python scripts/probe_tables.py [--source doris] [--table <表名>]
输出: temp/probe-doris.md（每表一段，含 as-of 日期），供并入 schema/*.md「探查档案」节

只读：仅经网关 SELECT/COUNT/GROUP BY/内省，不改任何数据。MySQL 暂不探查（无法连接）。
"""
import argparse
import datetime
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
sys.path.insert(0, HERE)
from db_query import schema as gw_schema, query as gw_query  # noqa: E402

_TIME_RE = re.compile(r'(time|date)', re.I)


def _pick_all(cols, pred, exclude=None):
    return [c['name'] for c in cols
            if not (exclude and c['name'].lower() in exclude) and pred(c['name'])]


def _pick(cols, pred, exclude=None):
    found = _pick_all(cols, pred, exclude)
    return found[0] if found else None


def _qname(database, table):
    return f'{database}.`{table}`'


def probe_table(source, table, database, out):
    cols = gw_schema(source, table).get('columns', [])
    if not cols:
        out.append(f"### {table}（`{database}.{table}`）\n- 内省失败/无列，跳过\n")
        return
    names = [c['name'] for c in cols]
    qname = _qname(database, table)

    lat_col = _pick(cols, lambda n: n.lower() in ('lat', 'latitude'))
    lng_col = _pick(cols, lambda n: n.lower() in ('lng', 'lon', 'longitude'))
    names_lower = [n.lower() for n in names]
    source_col = 'source' if 'source' in names_lower else ('provider' if 'provider' in names_lower else None)

    def q(sql):
        r = gw_query(source, sql, limit=5000)
        return r.get('rows'), r.get('error')

    lines = [f"### {table}（`{database}.{table}`）"]

    rows, err = q(f"SELECT COUNT(*) AS c FROM {qname}")
    cnt = rows[0][0] if (rows and not err) else f'ERR:{err}'
    lines.append(f"- **数据量级**：{cnt}")

    time_col = time_range = None
    for cand in _pick_all(cols, lambda n: _TIME_RE.search(n),
                          exclude={'insert_time', 'update_time', 'update_date'}):
        rows, err = q(f"SELECT MIN({cand}), MAX({cand}) FROM {qname}")
        if rows and not err and rows[0][0] is not None:
            time_col, time_range = cand, f"{rows[0][0]} ~ {rows[0][1]}"
            break
    if time_col:
        lines.append(f"- **时间范围**：`{time_col}` [{time_range}]")
    else:
        lines.append("- **时间范围**：未识别到有效时间列（列: " + ', '.join(names[:8]) + '…）')

    if source_col:
        rows, err = q(f"SELECT {source_col}, COUNT(*) AS c FROM {qname} GROUP BY {source_col} ORDER BY c DESC LIMIT 15")
        if rows and not err:
            dist = ', '.join(f"{r[0]}={r[1]}" for r in rows[:8])
            lines.append(f"- **源分布**（`{source_col}`）：{dist}")
    else:
        lines.append("- **源分布**：无 source/provider 列（单来源或无需甄别）")

    if lat_col and lng_col:
        # 坐标列可能为 STRING 且含 '-'/空占位：CAST 为 DOUBLE 后取 MIN/MAX，非数字自动忽略（NULL）
        rows, err = q(f"SELECT MIN(CAST({lat_col} AS DOUBLE)), MAX(CAST({lat_col} AS DOUBLE)), "
                      f"MIN(CAST({lng_col} AS DOUBLE)), MAX(CAST({lng_col} AS DOUBLE)) FROM {qname}")
        if rows and not err:
            v = rows[0]
            if all(x is None for x in v):
                lines.append("- **坐标范围**：坐标列全为 NULL（无有效坐标）")
            else:
                lines.append(f"- **坐标范围**：{lat_col} [{v[0]}~{v[1]}], {lng_col} [{v[2]}~{v[3]}]")
    else:
        lines.append("- **坐标范围**：无经纬度列（或列名非 lat/lng）")

    # 关联键（常见键列存在性）
    keys = [c for c in names if c.lower() in
            ('uuid', 'hull_no', 'hull_number', 'mmsi', 'name', 'en_name', 'msisdn', 'entity_name')]
    if keys:
        lines.append(f"- **关联键**：{', '.join(keys)}")

    out.append('\n'.join(lines) + '\n')


def main():
    p = argparse.ArgumentParser(description='Doris 注册表只读探查，输出探查档案 markdown')
    p.add_argument('--source', default='doris')
    p.add_argument('--table', default=None, help='仅探查指定表')
    p.add_argument('--out', default=os.path.join(ROOT, 'temp', 'probe-doris.md'))
    args = p.parse_args()

    cfg = json.load(open(os.path.join(ROOT, 'config', 'db_sources.json'), encoding='utf-8'))
    src = cfg.get(args.source)
    if not src:
        print(f'未知数据源: {args.source}', file=sys.stderr)
        sys.exit(1)
    tables = {k: v for k, v in src.get('tables', {}).items() if args.table is None or k == args.table}

    asof = datetime.date.today().isoformat()
    out = [f"# {args.source} 表探查档案（as-of {asof}，`scripts/probe_tables.py` 自动生成）\n"]
    ok = 0
    for tname, tinfo in tables.items():
        print(f'probe {tname} ...', file=sys.stderr)
        probe_table(args.source, tname, tinfo.get('database', src.get('database')), out)
        ok += 1

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(out))
    print(f'done: {ok} tables → {args.out}')
    print(f'时间范围/源分布/坐标范围基于最近一次探查（as-of {asof}），运行时以 3.1 探索三步复核。')


if __name__ == '__main__':
    main()
