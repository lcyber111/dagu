"""
HTML 结构 + JS 语法 + 图表行为 验证工具
用法: python scripts/validate_html.py <html文件路径>
返回: 成功输出 "OK" (exit 0)，失败输出错误列表 (exit 1)
依赖: Python 3 (内置 html.parser) + Node.js (JS 语法 + ECharts SSR 行为校验)

校验项:
  ✅ HTML 结构完整性
  ✅ 资源引用可访问性（相对路径、本地 lib/）
  ✅ Node.js JavaScript 语法检查
  ✅ 图表行为校验（check_dashboard.py：真实构建 + 数据形状断言 + ECharts SSR 渲染非空）
  ✅ 离线可运行性确认
"""

import sys
import os
import re
import subprocess
import tempfile
from html.parser import HTMLParser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from log_util import get  # noqa: E402

log = get('validate')

import check_dashboard


VOID_ELEMENTS = {
    'area', 'base', 'br', 'col', 'embed', 'hr', 'img',
    'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'
}

IMPLICITLY_CLOSABLE = {
    'html', 'head', 'body', 'tbody', 'thead', 'tfoot',
    'colgroup', 'caption', 'col'
}


class HTMLChecker(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tag_stack = []       # [(tag, line), ...]
        self.errors = []
        self._in_script = False
        self._script_code = []
        self._script_start_line = 0
        self.script_blocks = []   # [(html_start_line, code), ...]

    def handle_starttag(self, tag, attrs):
        line, _ = self.getpos()
        t = tag.lower()
        if t == 'script':
            has_src = any(a[0] == 'src' for a in attrs)
            if not has_src:
                self._in_script = True
                self._script_code = []
                self._script_start_line = line
            return
        if t not in VOID_ELEMENTS:
            self.tag_stack.append((t, line))

    def handle_endtag(self, tag):
        line, _ = self.getpos()
        t = tag.lower()
        if t == 'script':
            if self._in_script:
                code = ''.join(self._script_code).strip()
                if code:
                    self.script_blocks.append((self._script_start_line, code))
            self._in_script = False
            self._script_code = []
            return
        if t in VOID_ELEMENTS:
            return

        for i in range(len(self.tag_stack) - 1, -1, -1):
            if self.tag_stack[i][0] == t:
                # Tags between the match and the top are implicitly closed
                for j in range(i + 1, len(self.tag_stack)):
                    ct, cl = self.tag_stack[j]
                    if ct not in IMPLICITLY_CLOSABLE:
                        self.errors.append(
                            f"[HTML] 行 {cl}: 标签 <{ct}> 未显式闭合（被 </{t}> 隐式闭合，建议在前面添加 </{ct}>）")
                self.tag_stack = self.tag_stack[:i]
                return

        self.errors.append(f"[HTML] 行 {line}: 多余的结束标签 </{tag}>")

    def handle_data(self, data):
        if self._in_script:
            self._script_code.append(data)

    def handle_comment(self, data):
        if '--' in data:
            line, _ = self.getpos()
            self.errors.append(f"[HTML] 行 {line}: HTML 注释中包含 '--'")

    def handle_decl(self, decl):
        if decl.upper() != 'DOCTYPE HTML':
            line, _ = self.getpos()
            self.errors.append(f"[HTML] 行 {line}: 非标准 DOCTYPE: {decl[:30]}")


def check_html(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    checker = HTMLChecker()
    try:
        checker.feed(content)
    except Exception as e:
        return [f"[HTML] 解析异常: {e}"], []

    # Report unclosed tags at end of document
    unclosed = []
    for t, line in checker.tag_stack:
        if t not in VOID_ELEMENTS and t not in IMPLICITLY_CLOSABLE:
            unclosed.append(f"[HTML] 行 {line}: 标签 <{t}> 未闭合，请在文件末尾添加 </{t}>")
    errors = checker.errors + unclosed

    if not re.search(r'<!DOCTYPE html', content, re.IGNORECASE):
        errors.insert(0, "[HTML] 行 1: 缺少 <!DOCTYPE html> 声明")

    return errors, checker.script_blocks


def check_js(filepath, script_blocks):
    errors = []
    if not script_blocks:
        return errors

    for start_line, js_code in script_blocks:
        if not js_code.strip():
            continue

        tmp = None
        try:
            tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.js',
                                              delete=False, encoding='utf-8')
            tmp.write(js_code)
            tmp.close()

            result = subprocess.run(
                ['node', '--check', tmp.name],
                capture_output=True, text=True, timeout=15
            )

            if result.returncode != 0:
                js_ln = 0
                for line in result.stderr.split('\n'):
                    s = line.strip()
                    if not s or s.startswith('node:'):
                        continue
                    if re.match(r'^\s*\^+\s*$', s):
                        continue
                    m = re.match(r'.*\.js:(\d+)\s*$', s)
                    if m:
                        js_ln = int(m.group(1))
                        continue
                    m2 = re.match(r'^SyntaxError:\s*(.*)', s)
                    if m2 and js_ln > 0:
                        html_line = start_line + js_ln - 1
                        errors.append(
                            f"[JS] 行 {html_line}: {m2.group(1).strip()}")

        except FileNotFoundError:
            errors.append("[JS] node 不可用（不影响 HTML 检查）")
            break
        except subprocess.TimeoutExpired:
            errors.append("[JS] node --check 超时（跳过）")
        finally:
            if tmp:
                try:
                    os.unlink(tmp.name)
                except OSError:
                    pass

    return errors


def main():
    if len(sys.argv) < 2:
        print("用法: python scripts/validate_html.py <html文件路径>")
        sys.exit(1)

    filepath = sys.argv[1]
    if not os.path.exists(filepath):
        print(f"错误: 文件不存在: {filepath}")
        sys.exit(1)

    html_errors, script_blocks = check_html(filepath)
    js_errors = check_js(filepath, script_blocks)
    data_errors = check_dashboard.run_check(filepath)

    all_errors = html_errors + js_errors + data_errors

    if all_errors:
        log.error(f'校验失败 file={filepath} errors={len(all_errors)} first={all_errors[0]!r}')
        print(f"[ERROR] {filepath}")
        for err in sorted(all_errors):
            print(f"  {err}")
        sys.exit(1)
    else:
        log.info(f'校验通过 {filepath}')
        print("OK")
        sys.exit(0)


if __name__ == '__main__':
    main()
