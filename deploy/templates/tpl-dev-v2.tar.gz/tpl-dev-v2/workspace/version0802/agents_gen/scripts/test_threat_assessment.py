"""test_threat_assessment.py — 威胁等级评估模块单元测试
用法: python scripts/test_threat_assessment.py
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
sys.path.insert(0, ROOT)

from lib.analysis.threat_assessment import assess_threat  # noqa: E402


class TestConflictLevelOverride(unittest.TestCase):
    def test_high(self):
        out = assess_threat(800, 1500, True, conflict_level='high')
        self.assertEqual(out['level'], '严重')

    def test_medium(self):
        out = assess_threat(800, 1500, True, conflict_level='medium')
        self.assertEqual(out['level'], '高')

    def test_low(self):
        out = assess_threat(800, 1500, True, conflict_level='low')
        self.assertEqual(out['level'], '一般')

    def test_override_regardless_of_position(self):
        # 高烈度热点即使远在监视区外也定级严重（新闻独立判据）
        out = assess_threat(5000, 1500, False, conflict_level='high')
        self.assertEqual(out['level'], '严重')


class TestPositionRules(unittest.TestCase):
    def test_outside_monitor_no_threat(self):
        out = assess_threat(5000, 1500, in_monitor_area=False)
        self.assertEqual(out['level'], '无实质')

    def test_in_range_with_lock_severe(self):
        out = assess_threat(800, 1500, True, radar_lock=True)
        self.assertEqual(out['level'], '严重')

    def test_in_range_high(self):
        out = assess_threat(800, 1500, True)
        self.assertEqual(out['level'], '高')

    def test_lock_beyond_range_high(self):
        out = assess_threat(2000, 1500, True, radar_lock=True)
        self.assertEqual(out['level'], '高')

    def test_approaching_high(self):
        out = assess_threat(2000, 1500, True, approaching=True)
        self.assertEqual(out['level'], '高')

    def test_benign_general(self):
        out = assess_threat(2000, 1500, True)
        self.assertEqual(out['level'], '一般')

    def test_boundary_equal_range(self):
        # 距离 == 射程，计入可打击范围
        out = assess_threat(1500, 1500, True, radar_lock=True)
        self.assertEqual(out['level'], '严重')


class TestInputHandling(unittest.TestCase):
    def test_illegal_conflict_level(self):
        out = assess_threat(2000, 1500, True, conflict_level='nuclear')
        self.assertEqual(out['level'], '一般')
        self.assertEqual(len(out['warnings']), 1)

    def test_missing_distance(self):
        out = assess_threat(None, 1500, True)
        self.assertEqual(out['level'], '无实质')
        self.assertEqual(len(out['warnings']), 1)

    def test_reasons_present(self):
        out = assess_threat(800, 1500, True, radar_lock=True)
        self.assertTrue(out['reasons'])


class TestRegistry(unittest.TestCase):
    def test_get_and_list(self):
        from lib.analysis import get, list_patterns
        self.assertIn('threat-assessment', list_patterns())
        self.assertIs(get('threat-assessment'), assess_threat)


if __name__ == '__main__':
    unittest.main()
