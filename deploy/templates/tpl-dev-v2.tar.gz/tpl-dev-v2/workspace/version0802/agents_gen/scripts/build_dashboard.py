"""
build_dashboard.py — 大屏构建脚本（声明式 spec → HTML）

用法: python scripts/build_dashboard.py <spec.json>
产出: html/<spec.name>.html
返回: 成功打印 "OK html/<name>.html (N 行)" (exit 0)；失败打印错误列表 (exit 1)

职责:
  1. 严格校验 spec（JSON/必填/图表类型/id 引用/theme）
  2. 渲染 HTML 骨架（header/KPI/rows/图表容器/表格/footer）
  3. 注入 spec.theme 为 CSS 变量覆盖段
  4. 转义注入的数据（防 </script> 破坏）
  5. 复杂图（type:"echarts" + js）原样注入脚本块

图表逻辑全部在 lib/dashboard/dashboard.js 客户端声明式渲染，本脚本保持薄。
"""

import json
import re
import sys
import html as htmlmod
import os
import jsonschema

ALLOWED_TYPES = {'map', 'bar', 'line', 'pie', 'scatter', 'echarts'}
NAME_RE = re.compile(r'^[a-z0-9][a-z0-9-]*$')
HEX_RE = re.compile(r'^#[0-9a-fA-F]{6}$')
GRID_RE = re.compile(r'^(\d+(?:\.\d+)?(?:fr|px|%|rem|em)?)(\s+\d+(?:\.\d+)?(?:fr|px|%|rem|em)?)*$')
CSS_VAR_MAP = {
    'primary': '--primary',
    'background': '--bg',
    'bg_soft': '--bg-soft',
    'accent': '--accent',
}


def error(msg):
    print(f'[ERROR] {msg}')
    sys.exit(1)


SCHEMA_PATH = os.path.normpath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), '..', 'templates', 'dashboard-spec.schema.json'))


def validate_schema(spec):
    """按 JSON Schema（唯一契约源）深度校验 spec 结构。"""
    try:
        with open(SCHEMA_PATH, 'r', encoding='utf-8') as f:
            schema = json.load(f)
    except Exception as e:
        error(f'无法加载 schema 文件 {SCHEMA_PATH}: {e}')
    try:
        jsonschema.validate(spec, schema)
    except jsonschema.ValidationError as e:
        path = 'spec' + ''.join(f'[{p}]' if isinstance(p, int) else f'.{p}' for p in e.absolute_path)
        error(f'{path}: {e.message}')


def check_chart_data(spec):
    """跨字段不变量（JSON Schema 无法表达字段间比较），返回错误列表。"""
    errs = []
    for cs in spec['charts']:
        cid = cs['id']
        ctype = cs['type']
        d = cs.get('data', {})
        if ctype in ('bar', 'line'):
            vals = d.get('values')
            if not isinstance(vals, list) or not vals:
                continue  # 必填/非空由 schema 兜底
            if isinstance(vals[0], list):
                n = len(vals)
                for field, label in (('legend', '图例'), ('colors', '颜色')):
                    if field in d and (not isinstance(d[field], list) or len(d[field]) != n):
                        errs.append(f'charts[{cid}].data.{field}({len(d[field]) if isinstance(d[field], list) else "非数组"}) 与序列数({n})不一致')
                for i, v in enumerate(vals):
                    if not isinstance(v, list) or not v:
                        errs.append(f'charts[{cid}].data.values[{i}] 序列为空')
                    elif not all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in v):
                        errs.append(f'charts[{cid}].data.values[{i}] 含非数字元素')
            else:
                if not all(isinstance(x, (int, float)) and not isinstance(x, bool) for x in vals):
                    errs.append(f'charts[{cid}].data.values 含非数字元素')
                cats = d.get('categories')
                if ctype == 'bar' and isinstance(d.get('colors'), list) and d['colors'] and (
                        not isinstance(cats, list) or len(d['colors']) != len(cats)):
                    errs.append(f'charts[{cid}].data.colors({len(d["colors"])}) 与 categories({len(cats) if isinstance(cats, list) else "非数组"})不一致（单序列 bar 的 colors 为逐柱配色）')
    return errs


def validate(spec):
    if not isinstance(spec, dict):
        error('spec 必须是 JSON 对象')

    name = spec.get('name')
    if not name or not isinstance(name, str) or not NAME_RE.match(name):
        error("spec.name 缺失或非法（需 kebab-case：小写字母/数字/连字符，如 'carrier-ais-20260728'）")

    if not spec.get('title') or not isinstance(spec['title'], str):
        error('spec.title 缺失')

    for field in ('kpis', 'rows', 'charts'):
        if field not in spec or not isinstance(spec[field], list):
            error(f'spec.{field} 缺失或不是数组')

    # theme 校验
    theme = spec.get('theme', {})
    if not isinstance(theme, dict):
        error('spec.theme 必须是对象')
    for k, v in theme.items():
        if k not in CSS_VAR_MAP:
            error(f'spec.theme 未知字段: {k}（允许: {", ".join(CSS_VAR_MAP)}）')
        if not isinstance(v, str) or not HEX_RE.match(v):
            error(f'spec.theme.{k} 必须是 #RRGGBB 十六进制颜色')

    # kpis 校验
    for k in spec.get('kpis', []):
        if not isinstance(k, dict):
            error('spec.kpis[] 必须是对象')
        color = k.get('color')
        if color is not None and (not isinstance(color, str) or not HEX_RE.match(color)):
            error(f'spec.kpis[].color 必须是 #RRGGBB 十六进制颜色: {color}')

    # charts 校验
    chart_ids = set()
    for cs in spec['charts']:
        cid = cs.get('id')
        if not cid or not isinstance(cid, str):
            error('charts[].id 缺失')
        if cid in chart_ids:
            error(f'charts[].id 重复: {cid}')
        chart_ids.add(cid)

        ctype = cs.get('type')
        if ctype not in ALLOWED_TYPES:
            error(f'charts[{cid}].type 非法: {ctype}（允许: {", ".join(sorted(ALLOWED_TYPES))}）')

        if ctype == 'echarts':
            if 'option' not in cs and 'js' not in cs:
                error(f'charts[{cid}] type=echarts 必须提供 option(JSON) 或 js(原始脚本) 之一')
            if 'option' in cs and not isinstance(cs['option'], dict):
                error(f'charts[{cid}].option 必须是对象')
            if 'option' in cs and 'series' in cs['option'] and not isinstance(cs['option']['series'], list):
                error(f'charts[{cid}].option.series 必须是数组')
            if 'js' in cs and not isinstance(cs['js'], str):
                error(f'charts[{cid}].js 必须是字符串')

        if ctype == 'map':
            for key in ('markers', 'circles', 'lines'):
                if key in cs and not isinstance(cs[key], list):
                    error(f'charts[{cid}].{key} 必须是数组')
            if 'categories' in cs and not isinstance(cs['categories'], dict):
                error(f'charts[{cid}].categories 必须是对象')
            if 'geo' in cs and not isinstance(cs['geo'], dict):
                error(f'charts[{cid}].geo 必须是对象')

    # tables 校验
    table_ids = set()
    for t in spec.get('tables', []):
        tid = t.get('id')
        if not tid or not isinstance(tid, str):
            error('tables[].id 缺失')
        if tid in table_ids:
            error(f'tables[].id 重复: {tid}')
        table_ids.add(tid)
        if not t.get('title') or not isinstance(t['title'], str):
            error(f'tables[{tid}].title 缺失')
        if 'columns' not in t or not isinstance(t['columns'], list) or not t['columns']:
            error(f'tables[{tid}].columns 缺失或为空')
        if 'rows' not in t or not isinstance(t['rows'], list):
            error(f'tables[{tid}].rows 缺失')
        if 'formatters' in t and not isinstance(t['formatters'], dict):
            error(f'tables[{tid}].formatters 必须是对象')
        for col, fmt in t.get('formatters', {}).items():
            if not isinstance(fmt, dict):
                continue
            col_def = fmt.get('color')
            if isinstance(col_def, str) and not HEX_RE.match(col_def):
                error(f'tables[{tid}].formatters[{col}].color 必须是 #RRGGBB 十六进制颜色: {col_def}')
            elif isinstance(col_def, dict):
                for val, c in col_def.items():
                    if not isinstance(c, str) or not HEX_RE.match(c):
                        error(f'tables[{tid}].formatters[{col}].color[{val}] 必须是 #RRGGBB 十六进制颜色: {c}')

    # rows 布局引用校验
    for row in spec['rows']:
        if not isinstance(row, dict):
            error('rows[] 必须是对象')
        grid = row.get('grid', '1fr')
        if not isinstance(grid, str) or not GRID_RE.match(grid):
            error(f'rows[].grid 非法: {grid}（需如 "1fr"、"2fr 1fr"）')
        cells = row.get('cells')
        if not isinstance(cells, list) or not cells:
            error('rows[].cells 缺失或为空')
        for cell in cells:
            if 'chart' in cell:
                if cell['chart'] not in chart_ids:
                    error(f"rows 引用了不存在的图表 id: {cell['chart']}")
            elif 'table' in cell:
                if cell['table'] not in table_ids:
                    error(f"rows 引用了不存在的表格 id: {cell['table']}")
            elif 'stack' in cell:
                for iid in cell['stack']:
                    if iid not in chart_ids:
                        error(f"rows stack 引用了不存在的图表 id: {iid}")
            else:
                error(f'rows[].cells 项非法: {cell}（需含 chart/table/stack 之一）')
    return True


def esc(s):
    return htmlmod.escape(str(s), quote=False)


def render_header(spec, has_fa):
    title = spec['title']
    title_en = spec.get('title_en')
    subtitle = spec.get('subtitle')
    icon = spec.get('header_icon', '')
    badge = spec.get('header_badge', '离线部署')
    time = spec.get('time', '')

    logo = f'<div class="header-logo"><i class="{esc(icon)}"></i></div>' if icon and has_fa else ''
    if title_en:
        h1 = f'<h1>{esc(title_en)}</h1>'
        sub_parts = [esc(title)]
    else:
        h1 = f'<h1><span>{esc(title)}</span></h1>'
        sub_parts = []
    if subtitle:
        sub_parts.append(esc(subtitle))
    sub_html = f'<div class="subtitle">{" &middot; ".join(sub_parts)}</div>' if sub_parts else ''

    time_html = f'<span class="time"><i class="far fa-clock"></i> {esc(time)}</span>' if time else ''
    badge_icon = '<i class="fas fa-database"></i> ' if has_fa else ''
    badge_html = f'<span class="badge">{badge_icon}{esc(badge)}</span>'

    return f'''<div class="header">
  <div class="header-left">
    {logo}
    <div>
      {h1}
      {sub_html}
    </div>
  </div>
  <div class="header-right">
    {time_html}
    {badge_html}
  </div>
</div>'''


def render_kpis(spec):
    cards = []
    for k in spec.get('kpis', []):
        label = k.get('label', '')
        color = k.get('color', 'var(--primary)')
        v = k.get('value', '')
        if isinstance(v, dict):
            text = str(v.get('text', ''))
            sub = v.get('sub')
            sub_cls = ' inline' if sub else ''
        else:
            text = str(v)
            sub = k.get('sub')
            sub_cls = ' inline' if sub else ''
        if sub is None:
            sub = ''
            sub_cls = ''
        data_value = ''
        if re.fullmatch(r'[0-9]+(?:\.[0-9]+)?', text):
            data_value = f' data-value="{text}"'
        sub_html = f'<div class="kpi-sub{sub_cls}">{esc(sub)}</div>' if sub else ''
        cards.append(f'''  <div class="kpi-card"{data_value}>
    <div class="kpi-label">{esc(label)}</div>
    <div class="kpi-value" style="color:{esc(color)}">{esc(text)}</div>
    {sub_html}
  </div>''')
    if not cards:
        return ''
    return '<div class="kpi-row">\n' + '\n'.join(cards) + '\n</div>'


def render_table_card(t):
    col_fmt = t.get('formatters', {})
    max_h = t.get('maxHeight')
    style = f' style="max-height:{int(max_h)}px"' if max_h else ''
    thead = ''.join(f'<th>{esc(c)}</th>' for c in t['columns'])
    body_rows = []
    for row in t['rows']:
        tds = []
        for idx, col in enumerate(t['columns']):
            raw = row[idx] if idx < len(row) else ''
            val = esc(raw)
            fmt = col_fmt.get(col, {})
            if isinstance(fmt, dict):
                # tag 白名单映射
                tag_map = fmt.get('tag')
                if isinstance(tag_map, dict) and raw in tag_map:
                    val = f'<span class="tag {esc(tag_map[raw])}">{val}</span>'
                # color 映射（固定色或按值映射）
                col_def = fmt.get('color')
                color = None
                if isinstance(col_def, str):
                    color = col_def
                elif isinstance(col_def, dict):
                    color = col_def.get(raw)
                if color:
                    weight = f';font-weight:{int(fmt.get("weight", 600))}' if fmt.get('weight') else ''
                    val = f'<span style="color:{esc(color)}{weight}">{val}</span>'
                # bold
                if fmt.get('bold'):
                    val = f'<strong>{val}</strong>'
                # truncate
                tc = fmt.get('truncate')
                if isinstance(tc, int):
                    val = f'<span style="max-width:{tc}px;display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;vertical-align:bottom">{val}</span>'
            tds.append(f'<td>{val}</td>')
        body_rows.append('      <tr>' + ''.join(tds) + '</tr>')
    return f'''  <div class="card">
    <div class="card-header"><h3>{esc(t["title"])}</h3></div>
    <div class="card-body no-pad">
      <div class="table-wrap"{style}>
        <table>
          <thead><tr>{thead}</tr></thead>
          <tbody>
{chr(10).join(body_rows)}
          </tbody>
        </table>
      </div>
    </div>
  </div>'''


def render_chart_card(cs):
    title = cs.get('title')
    legend = cs.get('header_legend', [])
    legend_html = ''
    if isinstance(legend, list) and legend:
        items = ''.join(
            f'<span class="legend-item"><span class="legend-dot" style="background:{esc(l["color"])}"></span>{esc(l["label"])}</span>'
            for l in legend)
        legend_html = f'<div class="legend-row">{items}</div>'
    head = ''
    if title:
        head = f'<div class="card-header"><h3>{esc(title)}</h3></div>'
    elif legend_html:
        head = f'<div class="card-header"><div>{legend_html}</div></div>'

    h = int(cs.get('height', 400))
    hstyle = f' style="height:{h}px"'
    body = f'<div id="{cs["id"]}" class="chart-box"{hstyle}></div>'
    return f'  <div class="card">\n{head}\n    <div class="card-body no-pad">{body}</div>\n  </div>'


def render_rows(spec):
    by_chart = {cs['id']: cs for cs in spec['charts']}
    by_table = {t['id']: t for t in spec.get('tables', [])}
    rows_html = []
    for row in spec['rows']:
        grid = esc(row.get('grid', '1fr'))
        cells = []
        for cell in row['cells']:
            if 'chart' in cell:
                cells.append(render_chart_card(by_chart[cell['chart']]))
            elif 'table' in cell:
                cells.append(render_table_card(by_table[cell['table']]))
            elif 'stack' in cell:
                inner = '\n'.join(render_chart_card(by_chart[iid]) for iid in cell['stack'])
                cells.append(f'  <div class="stack">\n{inner}\n  </div>')
        rows_html.append(
            f'<div class="grid-row" style="grid-template-columns:{grid}">\n' + '\n'.join(cells) + '\n</div>')
    return '\n'.join(rows_html)


def render_footer(spec):
    items = spec.get('footer', [])
    parts = []
    for it in items:
        parts.append(f'<span class="ft-item"><span class="label">{esc(it.get("label", ""))}:</span> {esc(it.get("value", ""))}</span>')
    time = spec.get('time')
    if time:
        parts.append(f'<span class="ft-item"><span class="label">分析时间:</span> {esc(time)}</span>')
    body = '\n    '.join(parts)
    return f'<div class="footer">\n  <div>\n    {body}\n  </div>\n  <div class="ft-right">离线大屏 &middot; 本地 lib/ 资源</div>\n</div>'


def _hex_rgba(hexstr, alpha):
    hexstr = hexstr.lstrip('#')
    r = int(hexstr[0:2], 16)
    g = int(hexstr[2:4], 16)
    b = int(hexstr[4:6], 16)
    return f'rgba({r},{g},{b},{alpha})'


def theme_override(spec):
    theme = spec.get('theme', {})
    if not theme:
        return ''
    lines = []
    for k, v in theme.items():
        lines.append(f'  {CSS_VAR_MAP[k]}: {v};')
    primary = theme.get('primary')
    if primary:
        lines.append(f'  --primary-soft: {_hex_rgba(primary, 0.08)};')
        lines.append(f'  --border: {_hex_rgba(primary, 0.12)};')
        lines.append(f'  --border-strong: {_hex_rgba(primary, 0.3)};')
    vars_ = '\n'.join(lines)
    return f'<style>\n:root {{\n{vars_}\n}}\n</style>'


def safe_js_embed(obj):
    s = json.dumps(obj, ensure_ascii=False)
    s = s.replace('</', '<\\/').replace('<!--', '<\\!--')
    return s


def render(spec):
    has_fa = bool(spec.get('header_icon')) or bool(spec.get('header_badge'))
    has_fa = True  # 固定引入 FontAwesome，保持图标一致性
    title = esc(spec['title'])
    refresh = ''
    if spec.get('refresh'):
        refresh = f'<meta http-equiv="refresh" content="{int(spec["refresh"])}">'

    # 从注入给客户端的 spec 中剥离原始 js（由下方单独注入），并打标记供渲染器/校验器跳过
    client_spec = json.loads(json.dumps(spec))
    for cs in client_spec.get('charts', []):
        if 'js' in cs:
            cs['js_embedded'] = True
            cs.pop('js', None)
    spec_embed = safe_js_embed(client_spec)

    # 原始 JS 块（type=echarts + js）
    js_blocks = []
    for cs in spec['charts']:
        if cs.get('js'):
            raw_js = cs['js'].replace('</script', '<\\/script').replace('<!--', '<\\!--')
            js_blocks.append(f'''<script>
(function () {{
  'use strict';
  var dom = document.getElementById({json.dumps(cs['id'])});
  if (!dom) return;
  try {{
{raw_js}
  }} catch (e) {{
    console.error({json.dumps('[dashboard] 图表渲染失败(' + cs['id'] + '):')}, e);
    dom.innerHTML = '<div style="color:#ff6b6b;text-align:center;padding:40px">图表渲染失败，请查看控制台</div>';
  }}
}})();
</script>''')

    return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
{refresh}
<link rel="stylesheet" href="../lib/fontawesome/css/all.min.css">
<link rel="stylesheet" href="../lib/dashboard/dashboard.css">
{theme_override(spec)}
</head>
<body>

{render_header(spec, has_fa)}

{render_kpis(spec)}

{render_rows(spec)}

{render_footer(spec)}

<script src="../lib/echarts/echarts.min.js"></script>
<script src="../lib/echarts-maps/world.js"></script>
<script src="../lib/dashboard/chart-builders.js"></script>
<script>
window.DASHBOARD_SPEC = {spec_embed};
</script>
<script src="../lib/dashboard/dashboard.js"></script>
{''.join(js_blocks)}
</body>
</html>'''


def main():
    if len(sys.argv) < 2:
        print('用法: python scripts/build_dashboard.py <spec.json>')
        sys.exit(1)
    path = sys.argv[1]
    if not os.path.exists(path):
        print(f'[ERROR] 文件不存在: {path}')
        sys.exit(1)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            spec = json.load(f)
    except json.JSONDecodeError as e:
        print(f'[ERROR] spec JSON 解析失败: 行 {e.lineno} 列 {e.colno}: {e.msg}')
        sys.exit(1)
    except Exception as e:
        print(f'[ERROR] 读取失败: {e}')
        sys.exit(1)

    validate_schema(spec)
    validate(spec)

    data_errs = check_chart_data(spec)
    if data_errs:
        for e in data_errs:
            print(f'[ERROR] {e}')
        sys.exit(1)

    out_name = spec['name'] + '.html'
    out_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'html')
    out_path = os.path.normpath(os.path.join(out_dir, out_name))
    html_str = render(spec)

    os.makedirs(out_dir, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(html_str)

    lines = html_str.count('\n') + 1
    print(f'OK html/{out_name} ({lines} 行, {len(html_str.encode("utf-8"))} bytes)')


if __name__ == '__main__':
    main()
