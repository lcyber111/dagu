"""validate_agent.py — 生成 agent 结构/引用/权限校验器（轻量，独立无侵入）

用法: python scripts/validate_agent.py .opencode/agents/<id>.md
校验:
  - front matter（pyyaml）：display_name 非空中文 / color 带引号 #RRGGBB / temperature ∈ [0,1]
  - 文件名 kebab-case
  - Boot Sequence 内 `read shared/*.md` 路径真实存在（引用完整性）
  - 权限块：webfetch/websearch 必须 deny；核心读工具 read/glob/grep/bash/edit 必须 allow
  - `{{` 残留为零（生成物不得含模板占位符）
输出: `OK <file>` (exit 0) / 错误列表 (exit 1)
"""
import os
import re
import sys

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))

NAME_RE = re.compile(r'^[a-z0-9][a-z0-9-]*$')
HEX_RE = re.compile(r'^#[0-9a-fA-F]{6}$')
CJK_RE = re.compile(r'[\u4e00-\u9fff]')
CORE_ALLOW = {'read', 'glob', 'grep', 'bash', 'edit'}
DENY_NET = {'webfetch', 'websearch'}


def validate(path):
    errs = []
    base = os.path.basename(path)
    stem = base[:-3] if base.endswith('.md') else base
    if not NAME_RE.match(stem):
        errs.append(f'文件名非 kebab-case: {base}')

    with open(path, encoding='utf-8') as f:
        text = f.read()

    m = re.match(r'^---\s*\n(.*?)\n---\s*\n', text, re.S)
    if not m:
        errs.append('缺 front matter（--- 包裹）')
    else:
        try:
            fm = yaml.safe_load(m.group(1)) or {}
        except yaml.YAMLError as e:
            errs.append(f'front matter YAML 解析失败: {e}')
            fm = {}
        if not (isinstance(fm.get('display_name'), str) and CJK_RE.search(fm['display_name'])):
            errs.append('display_name 缺失或非中文')
        color = fm.get('color')
        if not (isinstance(color, str) and HEX_RE.match(color)):
            errs.append(f'color 必须为带引号 #RRGGBB: {color!r}')
        temp = fm.get('temperature')
        if temp is not None and not (isinstance(temp, (int, float)) and 0 <= float(temp) <= 1):
            errs.append(f'temperature 须在 [0,1]: {temp!r}')
        perm = fm.get('permission') or {}
        for k in DENY_NET:
            if perm.get(k) != 'deny':
                errs.append(f'permission.{k} 必须为 deny（离线约束）')
        for k in CORE_ALLOW:
            if perm.get(k) != 'allow':
                errs.append(f'permission.{k} 必须为 allow（核心读工具）')

    for ref in re.findall(r'read\s+shared/([\w.\-]+\.md)', text):
        if not os.path.exists(os.path.join(ROOT, 'shared', ref)):
            errs.append(f'Boot Sequence 引用不存在的共享模块: shared/{ref}')

    if '{{' in text:
        errs.append('产物含模板占位符 {{（未闭合）')

    return errs


def main(argv=None):
    argv = argv if argv is not None else sys.argv[1:]
    if len(argv) != 1:
        print('用法: python scripts/validate_agent.py <agent 文件路径>', file=sys.stderr)
        sys.exit(2)
    path = argv[0]
    if not os.path.isfile(path):
        print(f'文件不存在: {path}', file=sys.stderr)
        sys.exit(1)
    errs = validate(path)
    if errs:
        print(f'[FAIL] {path}')
        for e in errs:
            print(f'  - {e}')
        sys.exit(1)
    print(f'OK {path}')
    sys.exit(0)


if __name__ == '__main__':
    main()
