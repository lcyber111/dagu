"""strip_schema_docs.py — schema 判读文档化

剥离 `schema/*.md` 的「基本信息/字段列表」，只留「业务判读规则」；对纯元数据文件按规则删除。

设计（三层单一来源，列元数据归网关）:
  - 列元数据唯一来源 = 网关 `scripts/db_query.py --schema <表>`（实时 INFORMATION_SCHEMA）
  - `schema/*.md` 只保留不可从库中恢复的业务判读规则
  - 含 `## 业务判读规则` 的文件：保留该标题起的内容，标题改为 `# <原名去「字段说明」> 判读规则`，
    CRLF 统一为 LF 后写回
  - 不含判读规则（纯元数据）的文件：
      * 表已注册且 COLUMN_COMMENT 覆盖良好（连库验证确认）→ 删除
      * 未注册到 config/db_sources.json、或列注释覆盖不足 → 保留（字段语义仅存于此文档）

用法:
  python scripts/strip_schema_docs.py --dry-run   # 报告剥离/删除/保留清单，不改动
  python scripts/strip_schema_docs.py --execute   # 执行剥离与删除（删除仅限 DELETABLE 清单）
"""
import glob
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
SCHEMA_DIR = os.path.join(ROOT, 'schema')
RULES_MARKER = '## 业务判读规则'

# 无判读规则、但表未注册或列注释覆盖不足 → 保留（字段语义仅存于此文档，连库验证结论）
KEEP_PURE_METADATA = {
    'doris_alarm_agent.md',               # 未注册到 config/db_sources.json
    'doris_person_force_relation.md',     # 未注册
    'doris_roles_carrier_infomation.md',  # 未注册
    'doris_unstructed_data_info.md',      # standard.unstructed_data_info 11 列中 10 列 COLUMN_COMMENT 为空
}


def plan():
    to_strip = []
    to_delete = []
    to_keep = []
    for path in sorted(glob.glob(os.path.join(SCHEMA_DIR, '*.md'))):
        with open(path, encoding='utf-8') as f:
            content = f.read()
        idx = content.find(RULES_MARKER)
        if idx == -1:
            base = os.path.basename(path)
            if base in KEEP_PURE_METADATA:
                to_keep.append(path)
            else:
                to_delete.append(path)
            continue
        first = content.lstrip('\ufeff').splitlines()[0].strip() if content.splitlines() else ''
        new_title = re.sub(r'^(?:#\s*)+', '', first).replace('字段说明', '判读规则').strip() or '判读规则'
        to_strip.append((path, new_title))
    return to_strip, to_delete, to_keep


def execute():
    to_strip, to_delete, to_keep = plan()
    for path, new_title in to_strip:
        with open(path, encoding='utf-8') as f:
            content = f.read()
        idx = content.find(RULES_MARKER)
        kept = content[idx:].replace('\r\n', '\n').replace('\r', '\n').strip() + '\n'
        kept = f'# {new_title}\n\n{kept}'
        with open(path, 'w', encoding='utf-8') as f:
            f.write(kept)
        print(f'STRIP  {os.path.basename(path)}')
    for path in to_delete:
        try:
            os.remove(path)
            print(f'DELETE {os.path.basename(path)}')
        except FileNotFoundError:
            print(f'DELETE {os.path.basename(path)} (已删除)')
    for path in to_keep:
        print(f'KEEP   {os.path.basename(path)}')


def main(argv=None):
    import sys
    if '--dry-run' in (argv or sys.argv[1:]):
        to_strip, to_delete, to_keep = plan()
        print(f'剥离（保留判读规则）: {len(to_strip)} 个')
        for p, t in to_strip:
            print(f'  STRIP {os.path.basename(p)} -> {t}')
        print(f'删除（纯元数据+已注册+注释可覆盖）: {len(to_delete)} 个')
        for p in to_delete:
            print(f'  DEL   {os.path.basename(p)}')
        print(f'保留（未注册/注释覆盖不足）: {len(to_keep)} 个')
        for p in to_keep:
            print(f'  KEEP  {os.path.basename(p)}')
    elif '--execute' in (argv or sys.argv[1:]):
        execute()
    else:
        print('用法: strip_schema_docs.py --dry-run | --execute')
        sys.exit(1)


if __name__ == '__main__':
    main()
