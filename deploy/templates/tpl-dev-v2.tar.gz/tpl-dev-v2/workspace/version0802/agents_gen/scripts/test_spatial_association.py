"""test_spatial_association.py — 空间关联分析模块单元测试
用法: python scripts/test_spatial_association.py
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
sys.path.insert(0, ROOT)

from lib.analysis.spatial_association import (  # noqa: E402
    haversine_km, associate, _alt_layer, _is_carrier_type)


def carrier(cid, lat, lon, **kw):
    c = {'id': cid, 'lat': lat, 'lon': lon}
    c.update(kw)
    return c


def plane(aid, lat, lon, alt, atype='F/A-18E/F', **kw):
    a = {'id': aid, 'lat': lat, 'lon': lon, 'altitude_ft': alt, 'aircraft_type': atype}
    a.update(kw)
    return a


class TestHaversine(unittest.TestCase):
    def test_beijing_shanghai(self):
        # 北京(39.90,116.40) ↔ 上海(31.23,121.47) ≈ 1067 km
        d = haversine_km(39.90, 116.40, 31.23, 121.47)
        self.assertAlmostEqual(d, 1067.0, delta=8.0)

    def test_equator_one_degree(self):
        # 赤道上经度 1° ≈ 111.19 km
        d = haversine_km(0.0, 0.0, 0.0, 1.0)
        self.assertAlmostEqual(d, 111.19, delta=0.3)

    def test_same_point_zero(self):
        self.assertEqual(haversine_km(12.3, 45.6, 12.3, 45.6), 0.0)

    def test_symmetry(self):
        self.assertAlmostEqual(haversine_km(10, 20, 30, 40), haversine_km(30, 40, 10, 20))


class TestAltLayer(unittest.TestCase):
    def test_layers(self):
        self.assertEqual(_alt_layer(0), '地面')
        self.assertEqual(_alt_layer(None), '地面')
        self.assertEqual(_alt_layer(150), '<200ft')
        self.assertEqual(_alt_layer(200), '200-1000ft')
        self.assertEqual(_alt_layer(1000), '200-1000ft')
        self.assertEqual(_alt_layer(2000), '>1000ft')


class TestIsCarrierType(unittest.TestCase):
    def test_prefix_match(self):
        self.assertTrue(_is_carrier_type('F/A-18E/F', ('F/A-18',)))
        self.assertTrue(_is_carrier_type('MH-60R', ('MH-60',)))
        self.assertFalse(_is_carrier_type('B737', ('F/A-18', 'E-2D')))
        self.assertFalse(_is_carrier_type(None, ('F/A-18',)))


class TestAssociate(unittest.TestCase):
    def test_carrier_aircraft(self):
        # 33km 内、高度 150ft、机型 F/A-18E/F → 归属华盛顿号
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 0.3, 150)
        out = associate([cv], [ac])
        row = out['aircraft'][0]
        self.assertTrue(row['is_carrier_aircraft'])
        self.assertEqual(row['carrier_id'], 'CVN-73')
        self.assertEqual(row['altitude_layer'], '<200ft')

    def test_type_mismatch_not_carrier(self):
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 0.3, 150, atype='B737')
        out = associate([cv], [ac])
        self.assertFalse(out['aircraft'][0]['is_carrier_aircraft'])

    def test_high_altitude_not_carrier_but_layer(self):
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 0.3, 500)
        out = associate([cv], [ac])
        self.assertFalse(out['aircraft'][0]['is_carrier_aircraft'])
        self.assertEqual(out['layers']['CVN-73']['200-1000ft'], 1)

    def test_overlap_nearest_carrier(self):
        # 两航母相距 ~77.8km，飞机距 C1 35.6km / C2 42.2km → 归 C1
        c1 = carrier('C1', 0.0, 0.0)
        c2 = carrier('C2', 0.0, 0.7)
        ac = plane('ICAO1', 0.0, 0.32, 100)
        out = associate([c1, c2], [ac])
        row = out['aircraft'][0]
        self.assertTrue(row['is_carrier_aircraft'])
        self.assertEqual(row['carrier_id'], 'C1')

    def test_altitude_filters(self):
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 0.3, 12000)
        out = associate([cv], [ac])
        self.assertFalse(out['aircraft'][0]['is_carrier_aircraft'])
        self.assertEqual(out['layers']['CVN-73']['<200ft'], 0)
        self.assertEqual(len(out['warnings']), 1)

    def test_distance_hard_threshold(self):
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 1.4, 100)  # ~155km
        out = associate([cv], [ac])
        self.assertFalse(out['aircraft'][0]['is_carrier_aircraft'])
        self.assertEqual(len(out['warnings']), 1)

    def test_beyond_radius_but_within_threshold(self):
        # 80km：在硬阈值内保留、不参与 50km 半径统计
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 0.72, 100)
        out = associate([cv], [ac])
        self.assertEqual(len(out['aircraft']), 1)
        self.assertFalse(out['aircraft'][0]['is_carrier_aircraft'])
        self.assertEqual(out['layers']['CVN-73']['<200ft'], 0)

    def test_ground_excluded_from_association(self):
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = plane('ICAO1', 0.0, 0.3, 0)
        out = associate([cv], [ac])
        self.assertFalse(out['aircraft'][0]['is_carrier_aircraft'])
        self.assertEqual(out['aircraft'][0]['altitude_layer'], '地面')
        self.assertEqual(out['layers']['CVN-73']['地面'], 1)

    def test_empty_carriers(self):
        out = associate([], [plane('ICAO1', 0.0, 0.3, 100)])
        self.assertEqual(out['aircraft'][0]['carrier_id'], None)
        self.assertTrue(out['warnings'])

    def test_empty_aircraft(self):
        out = associate([carrier('CVN-73', 0.0, 0.0)], [])
        self.assertEqual(out['aircraft'], [])
        self.assertEqual(out['layers']['CVN-73']['<200ft'], 0)

    def test_bad_coords_skipped(self):
        cv = carrier('CVN-73', 0.0, 0.0)
        ac = {'id': 'BAD', 'lat': 200, 'lon': 0, 'altitude_ft': 100, 'aircraft_type': 'F/A-18'}
        out = associate([cv], [ac])
        self.assertEqual(len(out['aircraft']), 0)
        self.assertEqual(len(out['warnings']), 1)


class TestRegistry(unittest.TestCase):
    def test_get_and_list(self):
        from lib.analysis import get, list_patterns
        self.assertIn('spatial-association', list_patterns())
        self.assertIs(get('spatial-association'), associate)


if __name__ == '__main__':
    unittest.main()
