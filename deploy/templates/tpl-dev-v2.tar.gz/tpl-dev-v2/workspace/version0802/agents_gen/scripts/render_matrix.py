"""render_matrix.py — capability-matrix.json → markdown（供生成器 LLM 读取）

生成器在生成期运行: python scripts/render_matrix.py
输出: temp/capability-matrix.md（生成器直接读这份 markdown 做决策）

理由: LLM 读 markdown 表格比读 JSON 稳；JSON 是校验/测试的规范源，
markdown 由 JSON 派生，两者永不漂移。
"""
import argparse
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))


def render(matrix):
    lines = []
    lines.append('# 领域能力矩阵（capability-matrix，机器生成勿手改）')
    lines.append(f'> domain: {matrix.get("domain")} | version: {matrix.get("version")}')
    lines.append('')

    patterns = matrix.get('patterns', {})
    if patterns:
        lines.append('## 资产化模式注册表')
        lines.append('| 模式 id | 规则源 | 调用方式 | 用途 | 契约 |')
        lines.append('|---------|--------|---------|------|------|')
        for pid, p in patterns.items():
            lines.append(f'| `{pid}` | `{p["rule_source"]}` | `{p["cli"]}` | {p["purpose"]} | {p.get("contract_ref","")} |')
        lines.append('')

    trules = matrix.get('table_rules', [])
    if trules:
        lines.append('## 数据库表匹配规则（特征 → 表）')
        lines.append('| 特征 | 注入的表 |')
        lines.append('|------|---------|')
        for r in trules:
            when = ' / '.join(f'{k}={v}' for k, v in r.get('when', {}).items())
            lines.append(f'| {when} | `{"` + `".join(r["tables"])}` |')
        lines.append('')

    return '\n'.join(lines)


def main():
    p = argparse.ArgumentParser(description='能力矩阵 JSON → markdown')
    p.add_argument('--matrix', default=os.path.join(ROOT, 'config', 'capability-matrix.json'))
    p.add_argument('--out', default=os.path.join(ROOT, 'temp', 'capability-matrix.md'))
    args = p.parse_args()

    with open(args.matrix, encoding='utf-8') as f:
        matrix = json.load(f)
    md = render(matrix)
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, 'w', encoding='utf-8') as f:
        f.write(md)
    print(f'OK {args.out} ({len(md)} chars)')


if __name__ == '__main__':
    main()
