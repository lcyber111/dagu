"""test_ais_event_assembly.py — AIS 事件装配模块单元测试
用法: python scripts/test_ais_event_assembly.py
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
sys.path.insert(0, ROOT)

from lib.analysis.ais_event_assembly import assemble_events  # noqa: E402

W = {'start': '2026-02-10 00:00:00', 'end': '2026-08-10 23:59:59'}


def anchor(hull, t, etype, lat=32.0, lon=-117.0):
    return {'hull_no': hull, 'event_time': t, 'event_type': etype, 'lat': lat, 'lon': lon}


def types_of(out, hull=None):
    evs = out['events']
    if hull:
        evs = [e for e in evs if e['hull_no'] == hull]
    evs = sorted(evs, key=lambda e: e['event_time'])
    return [(e['event_type'], e['event_time']) for e in evs]


class TestAssembly(unittest.TestCase):
    def test_initial_and_alternation(self):
        # 首条早于窗口 → Initial AIS ON；锚点 OFF→ON 正常交替
        data = {'window': W, 'threshold_hours': 24,
                'anchors': [anchor('CVN-68', '2026-03-01 10:00:00', 'AIS OFF'),
                            anchor('CVN-68', '2026-03-02 10:00:00', 'AIS ON')],
                'firsts': {'CVN-68': {'event_time': '2026-01-05 08:00:00', 'lat': 47.5, 'lon': -122.6}},
                'lasts': {}, 'pres': {}}
        out = assemble_events(data)
        self.assertEqual([t for t, _ in types_of(out, 'CVN-68')],
                         ['Initial AIS ON', 'AIS OFF', 'AIS ON'])

    def test_pre_gap_recovery(self):
        # 首条在窗口内且存在 pre 状态 → 合成 pre-OFF（基点）+ ON（恢复）
        data = {'window': W, 'threshold_hours': 24,
                'anchors': [anchor('CVN-68', '2026-03-05 10:00:00', 'AIS OFF'),
                            anchor('CVN-68', '2026-03-06 10:00:00', 'AIS ON')],
                'firsts': {'CVN-68': {'event_time': '2026-03-01 08:00:00', 'lat': 32.0, 'lon': -117.0}},
                'lasts': {}, 'pres': {'CVN-68': {'event_time': '2026-02-01 08:00:00', 'lat': 32.5, 'lon': -117.2}}}
        out = assemble_events(data)
        self.assertEqual([t for t, _ in types_of(out, 'CVN-68')],
                         ['AIS OFF', 'AIS ON', 'AIS OFF', 'AIS ON'])

    def test_zero_record_synthesis(self):
        # at_sea → 合成静默 OFF；in_port → 不合成（防误报）
        data = {'window': W, 'threshold_hours': 24,
                'zero_record': [
                    {'hull_no': 'CVN-72', 'status': 'at_sea',
                     'last_known': {'event_time': '2026-01-20 16:16:00', 'lat': 6.4, 'lon': 94.7}},
                    {'hull_no': 'CVN-74', 'status': 'in_port',
                     'last_known': {'event_time': '2026-01-10 00:00:00', 'lat': 37.0, 'lon': -76.3}}]}
        out = assemble_events(data)
        self.assertEqual(types_of(out, 'CVN-72'), [('AIS OFF', W['start'])])
        self.assertEqual(types_of(out, 'CVN-74'), [])

    def test_bug1_cross_hull_no_timestamp_bleed(self):
        # 回归 bug①：跨舰不得串时间戳（CVN-71 须用自身 initial 时间，不是 CVN-72 的）
        data = {'window': W, 'threshold_hours': 24,
                'firsts': {'CVN-71': {'event_time': '2026-02-03 23:17:36', 'lat': 32.7, 'lon': -117.2},
                           'CVN-72': {'event_time': '2026-02-04 10:00:00', 'lat': 6.4, 'lon': 94.7}},
                'lasts': {}, 'pres': {}}
        out = assemble_events(data)
        self.assertEqual(types_of(out, 'CVN-71')[0][1], '2026-02-03 23:17:36')
        self.assertEqual(types_of(out, 'CVN-72')[0][1], '2026-02-04 10:00:00')

    def test_bug2_no_double_processing(self):
        # 回归 bug②：同一 (hull,time) 只保留一条（CVN-72 不得重复处理）
        data = {'window': W, 'threshold_hours': 24,
                'anchors': [anchor('CVN-72', '2026-03-01 10:00:00', 'AIS OFF'),
                            anchor('CVN-72', '2026-03-01 10:00:00', 'AIS OFF'),
                            anchor('CVN-72', '2026-03-02 10:00:00', 'AIS ON')],
                'firsts': {'CVN-72': {'event_time': '2026-01-05 08:00:00', 'lat': 6.4, 'lon': 94.7}},
                'lasts': {}, 'pres': {}}
        out = assemble_events(data)
        ts = types_of(out, 'CVN-72')
        self.assertEqual(sum(1 for _, tm in ts if tm == '2026-03-01 10:00:00'), 1)

    def test_bug3_same_timestamp_conflict(self):
        # 回归 bug③a：同刻 OFF+ON 按"分组前最后保留事件"交替取一种
        data = {'window': W, 'threshold_hours': 24,
                'anchors': [anchor('CVN-68', '2026-03-01 10:00:00', 'AIS OFF'),
                            anchor('CVN-68', '2026-03-01 10:00:00', 'AIS ON'),
                            anchor('CVN-68', '2026-03-02 10:00:00', 'AIS ON')],
                'firsts': {'CVN-68': {'event_time': '2026-02-01 08:00:00', 'lat': 32.0, 'lon': -117.0}},
                'lasts': {}, 'pres': {}}
        out = assemble_events(data)
        # Initial@Feb1 → 同刻(Mar1)取交替 OFF → ON@Mar2（同刻 ON 被消解）
        self.assertEqual([t for t, _ in types_of(out, 'CVN-68')],
                         ['Initial AIS ON', 'AIS OFF', 'AIS ON'])

    def test_bug3_consecutive_same_type_dedup(self):
        # 回归 bug③b：连续同类型（ON→ON→ON）收敛，保持交替不变式
        data = {'window': W, 'threshold_hours': 24,
                'anchors': [anchor('CVN-73', '2026-03-02 10:00:00', 'AIS ON'),
                            anchor('CVN-73', '2026-03-03 10:00:00', 'AIS ON'),
                            anchor('CVN-73', '2026-03-04 10:00:00', 'AIS ON')],
                'firsts': {'CVN-73': {'event_time': '2026-02-01 08:00:00', 'lat': 35.2, 'lon': 139.6}},
                'lasts': {}, 'pres': {}}
        out = assemble_events(data)
        types = [t for t, _ in types_of(out, 'CVN-73')]
        self.assertEqual(types, ['Initial AIS ON', 'AIS ON'])
        self.assertIn('连续同类型', ' '.join(out['warnings']))


if __name__ == '__main__':
    unittest.main()
