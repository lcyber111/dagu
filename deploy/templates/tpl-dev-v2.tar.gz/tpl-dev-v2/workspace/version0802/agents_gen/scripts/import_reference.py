"""import_reference.py — 精调 HTML 提升为参考大屏资产（入库）

用法:
  python scripts/import_reference.py html/<name>.html \
    --id <kebab-id> --title "<中文标题>" \
    [--task-types 综合评估,专项检测] [--tags 无人机,边境,多源印证] [--priority gold|normal]

产出:
  references/<id>/layout-spec.json   # 从 HTML 反向提取的 spec（布局骨架，可复用）
  references/<id>/reference.html     # 精调 HTML 副本（视觉对照）
  references/<id>/meta.json          # 资产元数据
  并自动更新 references/README.md 资产索引

原理: 复用 check_dashboard.extract_spec 从 window.DASHBOARD_SPEC 反解析 spec。
"""
import argparse
import datetime
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
REFERENCES_DIR = os.path.join(ROOT, 'references')
INDEX_PATH = os.path.join(REFERENCES_DIR, 'README.md')

sys.path.insert(0, HERE)
from check_dashboard import extract_spec  # noqa: E402

PRIORITIES = ('gold', 'normal')
ID_RE = re.compile(r'^[a-z0-9][a-z0-9-]*$')


def update_index(ref_id, meta):
    """在 references/README.md 资产索引表中追加/更新一行。"""
    if not os.path.exists(INDEX_PATH):
        print(f'[ERROR] 缺少 references/README.md（索引）', file=sys.stderr)
        sys.exit(1)
    with open(INDEX_PATH, encoding='utf-8') as f:
        content = f.read()

    # 定位索引表起始（标题行后紧跟分隔行）
    m = re.search(r'\| 资产 id .*\|\n\|[-| ]+\|\n', content)
    if not m:
        print('[ERROR] 索引表头未找到（references/README.md 结构异常）', file=sys.stderr)
        sys.exit(1)
    header_end = m.end()

    tags = ','.join(meta.get('scenario_tags', []))
    task_types = ','.join(meta.get('task_types', []))
    row = f'| `{ref_id}` | {meta.get("title", "")} | {task_types} | {tags} | {meta.get("priority", "normal")} |'

    # 若该 id 已存在则替换，否则插入表头后
    row_re = re.compile(r'\| `' + re.escape(ref_id) + r'` .*\n')
    if row_re.search(content[header_end:]):
        content = content[:header_end] + row_re.sub(row + '\n', content[header_end:], count=1)
    else:
        content = content[:header_end] + row + '\n' + content[header_end:]

    with open(INDEX_PATH, 'w', encoding='utf-8') as f:
        f.write(content)


def main():
    p = argparse.ArgumentParser(description='精调 HTML → 参考大屏资产')
    p.add_argument('html', help='精调 HTML 路径（html/<name>.html）')
    p.add_argument('--id', required=True, help='资产 id（kebab-case）')
    p.add_argument('--title', required=True, help='资产中文标题')
    p.add_argument('--task-types', default='', help='任务类型，逗号分隔（态势监控/规律挖掘/综合评估/专项检测）')
    p.add_argument('--tags', default='', help='场景标签，逗号分隔（无人机/边境/航母 等）')
    p.add_argument('--priority', default='normal', choices=PRIORITIES, help='优先级（gold 精调精品 / normal 普通）')
    args = p.parse_args()

    if not ID_RE.match(args.id):
        print(f'[ERROR] --id 必须为 kebab-case: {args.id}', file=sys.stderr)
        sys.exit(1)

    html_path = os.path.join(ROOT, args.html) if not os.path.isabs(args.html) else args.html
    if not os.path.exists(html_path):
        print(f'[ERROR] HTML 文件不存在: {html_path}', file=sys.stderr)
        sys.exit(1)

    # 1. 反向提取 spec
    spec = extract_spec(html_path)
    if spec is None:
        print(f'[ERROR] 未找到 window.DASHBOARD_SPEC（该 HTML 非构建脚本产物?）: {html_path}', file=sys.stderr)
        sys.exit(1)

    # 2. 建资产目录 + 三件套
    asset_dir = os.path.join(REFERENCES_DIR, args.id)
    os.makedirs(asset_dir, exist_ok=True)

    spec_path = os.path.join(asset_dir, 'layout-spec.json')
    with open(spec_path, 'w', encoding='utf-8') as f:
        json.dump(spec, f, ensure_ascii=False, indent=2)

    html_copy = os.path.join(asset_dir, 'reference.html')
    shutil.copy2(html_path, html_copy)

    meta = {
        'id': args.id,
        'title': args.title,
        'task_types': [t.strip() for t in args.task_types.split(',') if t.strip()],
        'scenario_tags': [t.strip() for t in args.tags.split(',') if t.strip()],
        'style': spec.get('style') or 'command',
        'priority': args.priority,
        'added': datetime.date.today().isoformat(),
        'source': args.html,
    }
    with open(os.path.join(asset_dir, 'meta.json'), 'w', encoding='utf-8') as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

    # 3. 更新索引
    update_index(args.id, meta)

    print(f'OK references/{args.id}/')
    print(f'  layout-spec.json   ({spec_path})')
    print(f'  reference.html     ({html_copy})')
    print(f'  meta.json          ({os.path.join(asset_dir, "meta.json")})')
    print(f'  索引已更新         ({INDEX_PATH})')
    sys.exit(0)


if __name__ == '__main__':
    main()
