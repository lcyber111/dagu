"""test_carrier_state.py — 航母状态判定模块单元测试
用法: python scripts/test_carrier_state.py
"""
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
sys.path.insert(0, ROOT)

from lib.analysis.carrier_state import assess_carrier_state  # noqa: E402


def base(**kw):
    d = {'hull_no': 'CVN-73', 'berthed': False, 'speed_kts': 12.0, 'stationary_hours': 0.0,
         'duty_days': 10, 'sorties_per_day': None, 'sortie_streak_days': 0,
         'e2d_sorties_per_day': 0, 'replenisher_distance_m': None,
         'replenisher_duration_min': None, 'replenisher_sync': False,
         'escort_spacing_nm': None, 'escort_count': None,
         'news_flags': {'official_combat': False, 'official_exercise': False,
                        'official_repair': False, 'social_rest': False}}
    d.update(kw)
    return d


class TestCarrierState(unittest.TestCase):
    def test_rest(self):
        out = assess_carrier_state(base(berthed=True, speed_kts=1.0, stationary_hours=30))
        self.assertEqual(out['state'], '休整')
        self.assertGreaterEqual(out['confidence'], 0.7)

    def test_repair_duty(self):
        out = assess_carrier_state(base(duty_days=30))
        self.assertEqual(out['state'], '维修')

    def test_repair_berth_conflict(self):
        # 靠泊(休整信号) + 执勤超25天(维修) → 维修优先
        out = assess_carrier_state(base(berthed=True, speed_kts=1.0, stationary_hours=30, duty_days=30))
        self.assertEqual(out['state'], '维修')

    def test_training(self):
        out = assess_carrier_state(base(sorties_per_day=60))
        self.assertEqual(out['state'], '训练')

    def test_alert_full(self):
        out = assess_carrier_state(base(escort_spacing_nm=15, e2d_sorties_per_day=3))
        self.assertEqual(out['state'], '警戒')
        self.assertGreaterEqual(out['confidence'], 0.7)

    def test_alert_partial(self):
        out = assess_carrier_state(base(escort_spacing_nm=15))
        self.assertEqual(out['state'], '警戒')

    def test_exercise_official(self):
        out = assess_carrier_state(base(news_flags={
            'official_combat': False, 'official_exercise': True,
            'official_repair': False, 'social_rest': False}))
        self.assertEqual(out['state'], '演习')

    def test_combat_streak(self):
        out = assess_carrier_state(base(sorties_per_day=180, sortie_streak_days=4))
        self.assertEqual(out['state'], '作战')
        self.assertGreaterEqual(out['confidence'], 0.7)

    def test_combat_single(self):
        out = assess_carrier_state(base(sorties_per_day=180, sortie_streak_days=1))
        self.assertEqual(out['state'], '作战')
        self.assertLess(out['confidence'], 0.7)

    def test_replenish(self):
        out = assess_carrier_state(base(replenisher_distance_m=150, replenisher_duration_min=120,
                                        replenisher_sync=True))
        self.assertEqual(out['state'], '补给')

    def test_official_overrides_quant(self):
        # 官方作战公告 vs 靠泊休整信号 → 作战优先
        out = assess_carrier_state(base(berthed=True, speed_kts=1.0, stationary_hours=30, news_flags={
            'official_combat': True, 'official_exercise': False,
            'official_repair': False, 'social_rest': False}))
        self.assertEqual(out['state'], '作战')

    def test_default(self):
        out = assess_carrier_state(base())
        self.assertEqual(out['state'], '常态/未知')
        self.assertEqual(out['confidence'], 0.0)


if __name__ == '__main__':
    unittest.main()
