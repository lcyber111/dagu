"""check_table_tools.py — table-tools.js 行为断言（执行检查）
用法: python scripts/check_table_tools.py
返回: "OK" (exit 0)；断言失败逐条输出 "FAIL ..." (exit 1)
原理: node require 真实 lib/dashboard/table-tools.js，对 sort/filter/paginate 跑边界用例。
"""
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
TOOLS_PATH = os.path.join(ROOT, 'lib', 'dashboard', 'table-tools.js')

HARNESS = r'''
var T = require(TOOLS);
var failures = [];
function assert(name, cond) {
  if (!cond) failures.push(name);
}
// --- parseCell / sortRows ---
assert('parseCell number-string', T.parseCell('1,234') === 1234);
assert('parseCell plain string', T.parseCell('abc') === 'abc');
assert('parseCell percent', T.parseCell('12%') === 12);
var rows = [['b', '2'], ['a', '10'], ['c', '1']];
var s = T.sortRows(rows, 1, 'asc');
assert('sort asc numeric', s[0][0] === 'c' && s[1][0] === 'b' && s[2][0] === 'a');
var s2 = T.sortRows(rows, 1, 'desc');
assert('sort desc numeric', s2[0][0] === 'a' && s2[2][0] === 'c');
assert('sort non-mutating', rows[0][0] === 'b');
var s3 = T.sortRows([['乙'], ['甲']], 0, 'asc');
assert('sort zh', s3[0][0] === '甲' && s3[1][0] === '乙');
// --- filterRows ---
var f = T.filterRows(rows, '10');
assert('filter hit', f.length === 1 && f[0][0] === 'a');
assert('filter case-insensitive', T.filterRows([['ABC']], 'abc').length === 1);
assert('filter empty query', T.filterRows(rows, '').length === 3);
assert('filter whitespace query', T.filterRows(rows, '  ').length === 3);
// --- paginate ---
var p = T.paginate(rows, 1, 2);
assert('paginate page1', p.rows.length === 2 && p.pages === 2 && p.total === 3 && p.page === 1);
var p2 = T.paginate(rows, 9, 2);
assert('paginate clamp upper', p2.page === 2);
var p3 = T.paginate(rows, -1, 2);
assert('paginate clamp lower', p3.page === 1);
var p4 = T.paginate([], 1, 10);
assert('paginate empty', p4.rows.length === 0 && p4.pages === 1);
if (failures.length) {
  failures.forEach(function (f) { console.log('FAIL ' + f); });
  process.exit(1);
}
console.log('OK table-tools cases=' + 18);
process.exit(0);
'''


def main():
    if not os.path.exists(TOOLS_PATH):
        print('[ERROR] 缺少 lib/dashboard/table-tools.js')
        sys.exit(1)
    fd, tmp = tempfile.mkstemp(suffix='.js', prefix='table_tools_check_')
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(HARNESS.replace('TOOLS', repr(TOOLS_PATH)))
        r = subprocess.run(['node', tmp], capture_output=True, text=True, timeout=60)
        if r.returncode != 0:
            lines = [l for l in r.stdout.splitlines() if l.strip()] or ['node 退出码非 0']
            for l in lines:
                print(l)
            sys.exit(1)
        print(r.stdout.strip())
        sys.exit(0)
    except FileNotFoundError:
        print('[ERROR] node 不可用')
        sys.exit(1)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass


if __name__ == '__main__':
    main()
