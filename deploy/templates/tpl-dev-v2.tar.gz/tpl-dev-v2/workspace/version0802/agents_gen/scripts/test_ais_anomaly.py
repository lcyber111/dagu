"""test_ais_anomaly.py — AIS 异常判定模块单元测试
用法: python scripts/test_ais_anomaly.py
"""
import os
import sys
import unittest
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
sys.path.insert(0, ROOT)

from lib.analysis.ais_anomaly import detect_anomalies, dedupe  # noqa: E402


def ev(hull, days, etype, **kw):
    e = {'hull_no': hull, 'event_time': datetime(2026, 1, 1) + timedelta(days=days),
         'event_type': etype}
    e.update(kw)
    return e


class TestInitialOnNotAnomaly(unittest.TestCase):
    def test_initial_on_not_counted(self):
        events = [ev('CVN-73', 0, 'Initial AIS ON')]
        out = detect_anomalies(events)
        self.assertEqual(out['anomalies'], [])
        self.assertEqual(out['levels']['CVN-73'], '正常')


class TestTransitions(unittest.TestCase):
    def test_off_then_on(self):
        events = [ev('CVN-73', 0, 'Initial AIS ON'),
                  ev('CVN-73', 1, 'AIS OFF'),
                  ev('CVN-73', 2, 'AIS ON')]
        out = detect_anomalies(events)
        self.assertEqual(len(out['anomalies']), 2)
        self.assertEqual([a['kind'] for a in out['anomalies']], ['off', 'on'])

    def test_repeated_same_type_not_anomaly(self):
        events = [ev('CVN-73', 0, 'Initial AIS ON'),
                  ev('CVN-73', 1, 'AIS OFF'),
                  ev('CVN-73', 2, 'AIS OFF')]
        out = detect_anomalies(events)
        self.assertEqual(len(out['anomalies']), 1)


class TestFaultProtection(unittest.TestCase):
    def test_short_interval_marked_fault(self):
        events = [ev('CVN-73', 0, 'Initial AIS ON'),
                  ev('CVN-73', 0.5 / 24, 'AIS OFF')]
        out = detect_anomalies(events)
        self.assertTrue(out['anomalies'][0]['suspected_fault'])
        self.assertEqual(len(out['warnings']), 1)

    def test_long_interval_not_fault(self):
        events = [ev('CVN-73', 0, 'Initial AIS ON'),
                  ev('CVN-73', 2, 'AIS OFF')]
        out = detect_anomalies(events)
        self.assertFalse(out['anomalies'][0]['suspected_fault'])
        self.assertEqual(len(out['warnings']), 0)


class TestLevels(unittest.TestCase):
    def _seq(self, n_off_on_pairs):
        events = [ev('X', 0, 'Initial AIS ON')]
        for i in range(1, n_off_on_pairs + 1):
            events.append(ev('X', i * 2, 'AIS OFF'))
            events.append(ev('X', i * 2 + 1, 'AIS ON'))
        return events

    def test_levels(self):
        # 0 次切换 → 正常
        self.assertEqual(detect_anomalies(self._seq(0))['levels']['X'], '正常')
        # 单次 OFF → 1 次异常 → 关注
        self.assertEqual(detect_anomalies(
            [ev('X', 0, 'Initial AIS ON'), ev('X', 1, 'AIS OFF')])['levels']['X'], '关注')
        # 1 对 OFF/ON → 2 次异常 → 关注
        self.assertEqual(detect_anomalies(self._seq(1))['levels']['X'], '关注')
        # 2 对 OFF/ON → 4 次异常 → 警示
        self.assertEqual(detect_anomalies(self._seq(2))['levels']['X'], '警示')
        # 3 对 OFF/ON → 6 次异常 → 严重
        self.assertEqual(detect_anomalies(self._seq(3))['levels']['X'], '严重')


class TestDedupe(unittest.TestCase):
    def test_same_timestamp_deduped(self):
        events = [ev('CVN-73', 1, 'AIS OFF'),
                  ev('CVN-73', 1, 'AIS OFF'),
                  ev('CVN-73', 2, 'AIS ON')]
        self.assertEqual(len(dedupe(events)), 2)


class TestWindowSemantics(unittest.TestCase):
    """等级窗口为固定绝对窗口（跨舰一致，相对数据末端），不按各舰末次异常回推。"""

    def test_window_relative_to_data_end(self):
        # 数据末端 day400（B 提供）；A 的 2 次异常在 day100/200，早于末端 6 个月（窗口 [220,400] 外）
        events = [ev('A', 0, 'Initial AIS ON'),
                  ev('A', 100, 'AIS OFF'),
                  ev('A', 200, 'AIS ON'),
                  ev('B', 0, 'Initial AIS ON'),
                  ev('B', 400, 'AIS ON')]
        out = detect_anomalies(events)
        self.assertEqual(out['levels']['A'], '正常')

    def test_recent_anomalies_counted(self):
        # A 的 2 次异常（day300/400）在数据末端 6 个月内（窗口 [220,400] 内）→ 关注
        events = [ev('A', 0, 'Initial AIS ON'),
                  ev('A', 300, 'AIS OFF'),
                  ev('A', 400, 'AIS ON'),
                  ev('B', 0, 'Initial AIS ON'),
                  ev('B', 400, 'AIS ON')]
        out = detect_anomalies(events)
        self.assertEqual(out['levels']['A'], '关注')


class TestRegistry(unittest.TestCase):
    def test_get_and_list(self):
        from lib.analysis import get, list_patterns
        self.assertIn('ais-anomaly', list_patterns())
        fn = get('ais-anomaly')
        self.assertEqual(fn, detect_anomalies)

    def test_unknown_pattern(self):
        from lib.analysis import get
        with self.assertRaises(KeyError):
            get('nope')


if __name__ == '__main__':
    unittest.main()
