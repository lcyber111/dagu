"""
selftest.py — 大屏管线回归测试
用法: python scripts/selftest.py
验证:
  正例: 全部 templates/dashboard-spec-*.json 构建+校验全过
  负例: 构造的坏 spec（空数据/序列数不匹配/非数字）必须被构建拒绝
  存量: html/ 下所有 *.html 通过 validate_html（含行为校验）
返回: 全部通过输出 "SELFTEST OK" (exit 0)；任一失败 exit 1
"""

import glob
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
BUILD = [sys.executable, os.path.join(HERE, 'build_dashboard.py')]
VALIDATE = [sys.executable, os.path.join(HERE, 'validate_html.py')]

failures = []


def build(spec_path):
    r = subprocess.run(BUILD + [spec_path], capture_output=True, text=True, timeout=120)
    return r


def validate(html_path):
    r = subprocess.run(VALIDATE + [html_path], capture_output=True, text=True, timeout=120)
    return r


def tmp_spec(payload):
    fd, path = tempfile.mkstemp(suffix='.json', prefix='selftest_')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    return path


def main():
    # 1. 正例：template 样例
    samples = sorted(glob.glob(os.path.join(ROOT, 'templates', 'dashboard-spec-*.json')))
    samples = [s for s in samples if not s.endswith('schema.json')]
    if not samples:
        failures.append('未找到 dashboard-spec-*.json 样例')
    for s in samples:
        try:
            with open(s, 'r', encoding='utf-8') as f:
                spec_name = json.load(f).get('name', '')
        except Exception:
            spec_name = ''
        r = build(s)
        if r.returncode != 0:
            failures.append(f'正例构建失败: {os.path.basename(s)}\n{r.stdout}\n{r.stderr}')
            continue
        if not spec_name:
            failures.append(f'正例缺少 name 字段: {os.path.basename(s)}')
            continue
        html = os.path.join(ROOT, 'html', spec_name + '.html')
        rv = validate(html)
        if rv.returncode != 0:
            failures.append(f'正例校验失败: {os.path.basename(html)}\n{rv.stdout}\n{rv.stderr}')
        else:
            print(f'  OK {os.path.basename(s)} -> {os.path.basename(html)}')
    # 2. 负例：必须被构建拒绝
    negatives = [
        ('空数据', {'name': 'neg-empty', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                    'charts': [{'id': 'c1', 'type': 'bar', 'data': {'categories': ['a', 'b'], 'values': []}}]}),
        ('多序列缺legend', {'name': 'neg-nolegend', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                            'charts': [{'id': 'c1', 'type': 'line', 'data': {'categories': ['a', 'b'], 'values': [[1, 2], [3, 4]]}}]}),
        ('legend长度不符', {'name': 'neg-len', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                           'charts': [{'id': 'c1', 'type': 'bar', 'data': {'categories': ['a', 'b'], 'values': [[1, 2], [3, 4]], 'legend': ['x']}}]}),
        ('非数字', {'name': 'neg-nan', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                    'charts': [{'id': 'c1', 'type': 'bar', 'data': {'categories': ['a', 'b'], 'values': ['1', 2]}}]}),
        ('pie缺value', {'name': 'neg-pie', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                        'charts': [{'id': 'c1', 'type': 'pie', 'data': {'values': [{'name': 'a', 'value': 'x'}]}}]}),
    ]
    for label, payload in negatives:
        p = tmp_spec(payload)
        r = build(p)
        os.unlink(p)
        if r.returncode == 0:
            failures.append(f'负例未被拒绝: {label}')
        else:
            print(f'  FAIL(as-expected) {label}')

    # 2.5 check_md_report 校验器：正例（五章全）exit 0；负例（缺章/空节/孤儿）exit 1
    MD_CHECK = [sys.executable, os.path.join(HERE, 'check_md_report.py')]
    md_tmp = os.path.join(ROOT, 'html', 'selftest-mdcheck.md')
    md_html = os.path.join(ROOT, 'html', 'selftest-mdcheck.html')
    good_md = (
        '# 自测 —— 分析设计说明\n\n'
        '> 生成时间：2026-08-17 10:00 ｜ 数据时效：近6个月 ｜ 配套大屏：html/selftest-mdcheck.html\n\n'
        '## 1. 用户需求分析\n- 专项检测；时间范围近6个月\n\n'
        '## 2. 数据来源与取数逻辑\n- Doris ais_ship_track；排除快照型源\n\n'
        '## 3. 分析逻辑与判据\n- AIS OFF 判定间隔 ≥24h\n\n'
        '## 4. 关键发现与结论\n- 发现异常静默\n\n'
        '## 5. 数据时效与局限\n- as-of 2026-08；零记录段标注缺失\n'
    )
    os.makedirs(os.path.dirname(md_tmp), exist_ok=True)
    with open(md_tmp, 'w', encoding='utf-8') as f:
        f.write(good_md)
    open(md_html, 'w', encoding='utf-8').write('<html></html>')
    r = subprocess.run(MD_CHECK + [md_tmp], capture_output=True, text=True, timeout=60)
    if r.returncode != 0:
        failures.append(f'check_md_report 正例未通过\n{r.stdout}\n{r.stderr}')
    else:
        print('  OK check_md_report 正例（五章全）')
    # 负例：缺 ## 3 章
    with open(md_tmp, 'w', encoding='utf-8') as f:
        f.write(good_md.replace('\n## 3. 分析逻辑与判据\n- AIS OFF 判定间隔 ≥24h\n', '\n'))
    r = subprocess.run(MD_CHECK + [md_tmp], capture_output=True, text=True, timeout=60)
    if r.returncode == 0:
        failures.append('check_md_report 负例（缺章）未被拒绝')
    else:
        print('  FAIL(as-expected) check_md_report 缺章负例')
    # 负例：孤儿 MD（对应 html 不存在）
    os.unlink(md_html)
    r = subprocess.run(MD_CHECK + [md_tmp], capture_output=True, text=True, timeout=60)
    if r.returncode == 0:
        failures.append('check_md_report 负例（孤儿 MD）未被拒绝')
    else:
        print('  FAIL(as-expected) check_md_report 孤儿 MD 负例')
    os.unlink(md_tmp)

    # 3. 存量 html 全量校验
    htmls = sorted(glob.glob(os.path.join(ROOT, 'html', '*.html')))
    for h in htmls:
        r = validate(h)
        if r.returncode != 0:
            failures.append(f'存量校验失败: {os.path.basename(h)}\n{r.stdout}\n{r.stderr}')
        else:
            print(f'  OK {os.path.basename(h)}')

    # 4. 单元测试（db 网关 / 分析模式模块 / 表格交互纯函数）
    unit_tests = [
        os.path.join(HERE, 'test_db_query.py'),
        os.path.join(HERE, 'test_ais_anomaly.py'),
        os.path.join(HERE, 'test_ais_event_assembly.py'),
        os.path.join(HERE, 'test_carrier_state.py'),
        os.path.join(HERE, 'test_spatial_association.py'),
        os.path.join(HERE, 'test_threat_assessment.py'),
        os.path.join(HERE, 'check_table_tools.py'),
        os.path.join(HERE, 'test_capability_matrix.py'),
    ]
    for t in unit_tests:
        if not os.path.exists(t):
            continue
        r = subprocess.run([sys.executable, t], capture_output=True, text=True, timeout=120)
        if r.returncode != 0:
            failures.append(f'单测失败: {os.path.basename(t)}\n{r.stdout}\n{r.stderr}')
        else:
            print(f'  OK {os.path.basename(t)}')

    # 5. 网关只读负例：非只读 SQL 必须被拒绝（不访问数据库，白名单判定）
    #    含 F1/F2 加固：WITH+DML 单语句穿透、多语句注入
    for bad in ['DELETE FROM t', 'DROP TABLE t', 'UPDATE t SET a=1',
                'WITH c AS (SELECT 1) DELETE FROM t',
                'SELECT 1; DROP TABLE t']:
        r = subprocess.run(
            [sys.executable, os.path.join(HERE, 'db_query.py'),
             '--source', 'doris', '--sql', bad],
            capture_output=True, text=True, timeout=60)
        if r.returncode == 0:
            failures.append(f'只读负例未被拒绝: {bad}')
        else:
            print(f'  FAIL(as-expected) 只读负例 {bad}')

    # 6. 生成器校验（validate_agent.py）：对存在的非生成器 agent 校验通过（回归防线）
    validate_agent = os.path.join(HERE, 'validate_agent.py')
    agent_dir = os.path.join(ROOT, '.opencode', 'agents')
    agents = ([f for f in os.listdir(agent_dir)
               if f.endswith('.md') and f != 'agent-generator.md']
              if os.path.isdir(agent_dir) else [])
    if not agents:
        print('  SKIP validate_agent（无已生成 agent，校验锚点待新 agent 落地）')
    else:
        for a in agents:
            p = os.path.join(agent_dir, a)
            r = subprocess.run([sys.executable, validate_agent, p],
                               capture_output=True, text=True, timeout=60)
            if r.returncode != 0:
                failures.append(f'{a} 未通过 validate_agent.py:\n{r.stdout}\n{r.stderr}')
            else:
                print(f'  OK validate_agent.py {a}')

    # 7. 参考大屏资产完整性（references/）：每资产三件套 + 索引一致
    ref_dir = os.path.join(ROOT, 'references')
    refs = ([d for d in os.listdir(ref_dir)
             if os.path.isdir(os.path.join(ref_dir, d)) and d != '__pycache__']
            if os.path.isdir(ref_dir) else [])
    if not refs:
        print('  SKIP references（参考资产库为空）')
    else:
        index_text = ''
        try:
            with open(os.path.join(ref_dir, 'README.md'), encoding='utf-8') as f:
                index_text = f.read()
        except OSError:
            failures.append('references/README.md 索引缺失')
        for r in refs:
            for part in ('layout-spec.json', 'reference.html', 'meta.json'):
                if not os.path.exists(os.path.join(ref_dir, r, part)):
                    failures.append(f'参考资产 {r} 缺 {part}')
            if index_text and f'| `{r}` |' not in index_text:
                failures.append(f'参考资产 {r} 未登记于 references/README.md 索引')
            else:
                print(f'  OK references/{r}')

    if failures:
        print('\nSELFTEST FAILED')
        for f in failures:
            print('-' * 60)
            print(f)
        sys.exit(1)
    print('\nSELFTEST OK')


if __name__ == '__main__':
    main()
