"""
selftest.py — 大屏管线回归测试
用法: python scripts/selftest.py
验证:
  正例: 全部 templates/dashboard-spec-*.json 构建+校验全过
  负例: 构造的坏 spec（空数据/序列数不匹配/非数字）必须被构建拒绝
  存量: html/ 下所有 *.html 通过 validate_html（含行为校验）
返回: 全部通过输出 "SELFTEST OK" (exit 0)；任一失败 exit 1
"""

import glob
import json
import os
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
BUILD = [sys.executable, os.path.join(HERE, 'build_dashboard.py')]
VALIDATE = [sys.executable, os.path.join(HERE, 'validate_html.py')]

failures = []


def build(spec_path):
    r = subprocess.run(BUILD + [spec_path], capture_output=True, text=True, timeout=120)
    return r


def validate(html_path):
    r = subprocess.run(VALIDATE + [html_path], capture_output=True, text=True, timeout=120)
    return r


def tmp_spec(payload):
    fd, path = tempfile.mkstemp(suffix='.json', prefix='selftest_')
    with os.fdopen(fd, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False)
    return path


def main():
    # 1. 正例：template 样例
    samples = sorted(glob.glob(os.path.join(ROOT, 'templates', 'dashboard-spec-*.json')))
    samples = [s for s in samples if not s.endswith('schema.json')]
    if not samples:
        failures.append('未找到 dashboard-spec-*.json 样例')
    for s in samples:
        try:
            with open(s, 'r', encoding='utf-8') as f:
                spec_name = json.load(f).get('name', '')
        except Exception:
            spec_name = ''
        r = build(s)
        if r.returncode != 0:
            failures.append(f'正例构建失败: {os.path.basename(s)}\n{r.stdout}\n{r.stderr}')
            continue
        if not spec_name:
            failures.append(f'正例缺少 name 字段: {os.path.basename(s)}')
            continue
        html = os.path.join(ROOT, 'html', spec_name + '.html')
        rv = validate(html)
        if rv.returncode != 0:
            failures.append(f'正例校验失败: {os.path.basename(html)}\n{rv.stdout}\n{rv.stderr}')
        else:
            print(f'  OK {os.path.basename(s)} -> {os.path.basename(html)}')
    # 2. 负例：必须被构建拒绝
    negatives = [
        ('空数据', {'name': 'neg-empty', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                    'charts': [{'id': 'c1', 'type': 'bar', 'data': {'categories': ['a', 'b'], 'values': []}}]}),
        ('多序列缺legend', {'name': 'neg-nolegend', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                            'charts': [{'id': 'c1', 'type': 'line', 'data': {'categories': ['a', 'b'], 'values': [[1, 2], [3, 4]]}}]}),
        ('legend长度不符', {'name': 'neg-len', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                           'charts': [{'id': 'c1', 'type': 'bar', 'data': {'categories': ['a', 'b'], 'values': [[1, 2], [3, 4]], 'legend': ['x']}}]}),
        ('非数字', {'name': 'neg-nan', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                    'charts': [{'id': 'c1', 'type': 'bar', 'data': {'categories': ['a', 'b'], 'values': ['1', 2]}}]}),
        ('pie缺value', {'name': 'neg-pie', 'title': 't', 'kpis': [], 'rows': [{'cells': [{'chart': 'c1'}]}],
                        'charts': [{'id': 'c1', 'type': 'pie', 'data': {'values': [{'name': 'a', 'value': 'x'}]}}]}),
    ]
    for label, payload in negatives:
        p = tmp_spec(payload)
        r = build(p)
        os.unlink(p)
        if r.returncode == 0:
            failures.append(f'负例未被拒绝: {label}')
        else:
            print(f'  FAIL(as-expected) {label}')

    # 3. 存量 html 全量校验
    htmls = sorted(glob.glob(os.path.join(ROOT, 'html', '*.html')))
    for h in htmls:
        r = validate(h)
        if r.returncode != 0:
            failures.append(f'存量校验失败: {os.path.basename(h)}\n{r.stdout}\n{r.stderr}')
        else:
            print(f'  OK {os.path.basename(h)}')

    if failures:
        print('\nSELFTEST FAILED')
        for f in failures:
            print('-' * 60)
            print(f)
        sys.exit(1)
    print('\nSELFTEST OK')


if __name__ == '__main__':
    main()
