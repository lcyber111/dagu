"""
check_dashboard.py — 大屏行为校验（执行检查，非结构检查）
用法: python scripts/check_dashboard.py <html文件路径>
返回: 所有声明式图表均能构建 + 数据形状合法 + ECharts SSR 渲染非空 => "OK" (exit 0)；否则逐图输出错误 (exit 1)

原理:
  用与浏览器完全相同的构建代码（lib/dashboard/chart-builders.js）在 Node 中执行每个图表：
  1. 真实 builder 构建 ECharts option（形状非法会 throw —— 失败显性化）
  2. validateChartOption 二次断言数据形状（空图/坏数据的确定性判据）
  3. ECharts 5.5 SSR（renderer=svg, renderToSVGString）真实渲染，断言非空
  4. type=echarts + js 的图跳过（任意 JS 无法通用执行，仅由 validate_html.py 做语法检查）

依赖: Node.js + lib/ 下的 echarts / world.js / chart-builders.js（全部本地，离线）
"""

import json
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
ECHARTS_PATH = os.path.join(ROOT, 'lib', 'echarts', 'echarts.min.js')
WORLD_PATH = os.path.join(ROOT, 'lib', 'echarts-maps', 'world.js')
BUILDERS_PATH = os.path.join(ROOT, 'lib', 'dashboard', 'chart-builders.js')


def extract_spec(html_path):
    with open(html_path, 'r', encoding='utf-8') as f:
        content = f.read()
    m = re.search(r'window\.DASHBOARD_SPEC\s*=\s*', content)
    if not m:
        return None
    # 括号配对提取（非贪婪正则会在字符串值含 '};' 时提前截断，改用配对扫描）
    start = m.end()
    depth = 0
    in_str = None
    i = start
    n = len(content)
    while i < n:
        ch = content[i]
        if in_str:
            if ch == '\\':
                i += 2
                continue
            if ch == in_str:
                in_str = None
        elif ch in ("'", '"'):
            in_str = ch
        elif ch == '{':
            depth += 1
        elif ch == '}':
            depth -= 1
            if depth == 0:
                raw = content[start:i + 1]
                raw = raw.replace('<\\/', '</').replace('<\\!--', '<!--')
                try:
                    return json.loads(raw)
                except json.JSONDecodeError as e:
                    raise ValueError(f'DASHBOARD_SPEC 解析失败: 行 {e.lineno} 列 {e.colno}: {e.msg}')
        i += 1
    return None


HARNESS_TMPL = r'''
global.window = {};
require(%(world)r);
var echarts = require(%(echarts)r);
var B = require(%(builders)r);
echarts.registerMap('world', global.window.WORLD_GEOJSON);
var spec = require(%(spec)r);
var failures = [];
var checked = 0;
(spec.charts || []).forEach(function (cs) {
  if (cs.js || cs.js_embedded) return;  // 原始 JS 图：跳过（仅语法检查）
  checked++;
  try {
    var option = (cs.type === 'echarts') ? (cs.option || {}) : B.BUILDERS[cs.type](cs);
    var errs = (B.validateChartOption && B.validateChartOption(cs.type, option)) || [];
    if (errs.length) throw new Error('数据异常: ' + errs.join('; '));
    var chart = echarts.init(null, null, { renderer: 'svg', ssr: true, width: 800, height: cs.height || 400 });
    chart.setOption(option);
    var svg = chart.renderToSVGString();
    chart.dispose();
    if (!svg || svg.length < 50) throw new Error('渲染结果为空');
  } catch (e) {
    failures.push(cs.id + ' [' + cs.type + ']: ' + String(e && e.message || e));
  }
});
if (failures.length) {
  failures.forEach(function (f) { console.log('FAIL ' + f); });
  process.exit(1);
}
console.log('OK charts=' + checked);
process.exit(0);
'''


def run_check(html_path):
    try:
        spec = extract_spec(html_path)
    except ValueError as e:
        return ['[CHECK] ' + str(e)]
    if spec is None:
        return ['[CHECK] 未找到 window.DASHBOARD_SPEC']
    if not os.path.exists(ECHARTS_PATH) or not os.path.exists(BUILDERS_PATH):
        return ['[CHECK] 缺少本地渲染资源（lib/echarts 或 lib/dashboard/chart-builders.js）']

    spec_tmp = None
    js_tmp = None
    try:
        fd, spec_tmp = tempfile.mkstemp(suffix='.json', prefix='dash_spec_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(spec, f, ensure_ascii=False)

        harness = HARNESS_TMPL % {
            'world': WORLD_PATH,
            'echarts': ECHARTS_PATH,
            'builders': BUILDERS_PATH,
            'spec': spec_tmp,
        }
        fd2, js_tmp = tempfile.mkstemp(suffix='.js', prefix='dash_check_')
        with os.fdopen(fd2, 'w', encoding='utf-8') as f:
            f.write(harness)

        result = subprocess.run(
            ['node', js_tmp], capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            lines = [l for l in result.stdout.splitlines() if l.strip()] or ['node 退出码非 0']
            return lines
        return []
    except FileNotFoundError:
        return ['[CHECK] node 不可用']
    except subprocess.TimeoutExpired:
        return ['[CHECK] node 渲染超时（跳过）']
    finally:
        for p in (spec_tmp, js_tmp):
            if p:
                try:
                    os.unlink(p)
                except OSError:
                    pass


def main():
    if len(sys.argv) < 2:
        print('用法: python scripts/check_dashboard.py <html文件路径>')
        sys.exit(1)
    filepath = sys.argv[1]
    if not os.path.exists(filepath):
        print(f'错误: 文件不存在: {filepath}')
        sys.exit(1)
    errors = run_check(filepath)
    if errors:
        print(f'[ERROR] {filepath}')
        for e in errors:
            print(f'  {e}')
        sys.exit(1)
    print('OK')
    sys.exit(0)


if __name__ == '__main__':
    main()
