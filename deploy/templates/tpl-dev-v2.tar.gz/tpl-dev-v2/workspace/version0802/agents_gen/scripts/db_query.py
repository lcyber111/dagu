"""db_query.py — Doris/MySQL 统一只读查询网关

凭据只在 `config/db_sources.json` 内读取，永不进入 LLM 提示词上下文。

用法:
  python scripts/db_query.py --sources                                   # 列出数据源
  python scripts/db_query.py --source doris --tables                     # 表清单（读注册表）
  python scripts/db_query.py --source doris --schema ais_ship_track      # 表结构内省
  python scripts/db_query.py --source doris --sql "SELECT ..." [--limit N]  # 只读查询

只读约束: 仅允许 SELECT/SHOW/DESCRIBE/EXPLAIN/WITH（剥离注释后判定）。
无 LIMIT 的 SELECT 自动追加 LIMIT <limit>（默认 1000，上限 5000），超限截断并标记 truncated。
失败统一返回 {"ok": false, "error": ...} 并 exit 1。
"""
import argparse
import json
import os
import re
import sys
import time

import pymysql

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..'))
CONFIG_PATH = os.path.join(ROOT, 'config', 'db_sources.json')

sys.path.insert(0, HERE)
from log_util import get  # noqa: E402

log = get('db_query')
log_sql = get('sql')

MAX_LIMIT = 5000
DEFAULT_LIMIT = 1000
_ALLOWED_STARTS = ('select', 'show', 'describe', 'desc', 'explain', 'with')
# 深度 0 出现即拒绝的 DML/DDL（覆盖 WITH+...、多语句注入、尾随语句）
_FORBIDDEN_WORDS = {
    'delete', 'update', 'insert', 'drop', 'truncate', 'alter', 'create',
    'replace', 'merge', 'grant', 'revoke', 'call', 'load',
}
_LIMIT_CLAUSE = re.compile(r'\blimit\s+(\d+)(?:\s*,\s*(\d+))?(?:\s+offset\s+\d+)?\s*$', re.I)


def _strip_comments_outside_strings(sql):
    """剔除注释（`--`/`#`/`/* */`），保留字符串字面量原样（防误删字符串内的 --/limit 等）。"""
    out = []
    i, n = 0, len(sql)
    in_s = False
    while i < n:
        c = sql[i]
        if in_s:
            out.append(c)
            if c == '\\' and i + 1 < n:
                out.append(sql[i + 1]); i += 2
                continue
            if c == "'":
                in_s = False
            i += 1
            continue
        if c == "'":
            in_s = True
            out.append(c); i += 1
            continue
        if c == '"':
            out.append(c); i += 1
            continue
        if c == '-' and i + 1 < n and sql[i + 1] == '-':
            while i < n and sql[i] != '\n':
                i += 1
            continue
        if c == '#':
            while i < n and sql[i] != '\n':
                i += 1
            continue
        if c == '/' and i + 1 < n and sql[i + 1] == '*':
            i += 2
            while i + 1 < n and not (sql[i] == '*' and sql[i + 1] == '/'):
                i += 1
            i += 2
            continue
        out.append(c); i += 1
    return ''.join(out)


def _sanitize_sql(sql):
    """清洗副本：注释剔除 + 字符串字面量替换为 ''，用于只读判定（防 note='DELETE' 误伤）。"""
    return re.sub(r"'(?:[^'\\]|\\.)*'", "''", _strip_comments_outside_strings(sql))


def _forbidden_at_depth0(scan):
    """扫描清洗副本中括号深度 0 的 DML/DDL 词。"""
    depth = 0
    i, n = 0, len(scan)
    while i < n:
        ch = scan[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif depth == 0 and (ch.isalpha() or ch == '_'):
            j = i
            while j < n and (scan[j].isalnum() or scan[j] == '_'):
                j += 1
            if scan[i:j].lower() in _FORBIDDEN_WORDS:
                return True
            i = j
            continue
        i += 1
    return False


def _load_cfg():
    with open(CONFIG_PATH, encoding='utf-8') as f:
        return json.load(f)


def _source_names():
    return sorted(_load_cfg().keys())


def _connect(source):
    cfg = _load_cfg()[source]
    kwargs = dict(host=cfg['host'], port=cfg['port'], user=cfg['user'],
                  password=cfg['password'], connect_timeout=5)
    if cfg.get('database'):
        kwargs['database'] = cfg['database']
        kwargs['charset'] = 'utf8mb4'
    return pymysql.connect(**kwargs), cfg


def _check_readonly(sql):
    scan = _sanitize_sql(sql)
    if not scan.strip():
        return False
    if _forbidden_at_depth0(scan):
        return False
    first = scan.split(None, 1)[0].lower().rstrip(';')
    return first in _ALLOWED_STARTS


def _apply_limit(sql, limit):
    """加固：先剔注释（防尾随注释吞 LIMIT），在清洗副本上定位尾部 LIMIT 子句并收敛到 limit。"""
    cleaned = _strip_comments_outside_strings(sql)
    base = cleaned.rstrip().rstrip(';').rstrip()
    m = _LIMIT_CLAUSE.search(base)
    if m:
        cnt = int(m.group(2) if m.group(2) is not None else m.group(1))
        if cnt <= limit:
            return base
        return re.sub(_LIMIT_CLAUSE, f'LIMIT {limit}', base, count=1)
    return base + f' LIMIT {limit}'


def query(source, sql, limit=DEFAULT_LIMIT):
    """只读查询。返回 {ok, source, sql, columns, rows, row_count, truncated}。

    用 LIMIT <limit+1> 探测截断：多于 limit 行则保留前 limit 行并置 truncated=True。
    """
    if not _check_readonly(sql):
        log.warning(f'只读拒绝 sql={sql[:120]!r}')
        return {'ok': False, 'error': '禁止非只读语句，仅允许 SELECT/SHOW/DESCRIBE/EXPLAIN/WITH'}
    limit = min(max(int(limit), 1), MAX_LIMIT)
    final_sql = _apply_limit(sql, limit + 1)
    t0 = time.time()
    try:
        conn, _ = _connect(source)
        try:
            with conn.cursor() as cur:
                cur.execute(final_sql)
                columns = [d[0] for d in (cur.description or [])]
                rows = cur.fetchall()
            truncated = len(rows) > limit
            if truncated:
                rows = rows[:limit]
            duration_ms = round((time.time() - t0) * 1000, 1)
            log_sql.info(f'source={source} row_count={len(rows)} duration_ms={duration_ms} '
                         f'truncated={truncated} sql={final_sql!r}')
            if truncated:
                log.warning(f'结果被截断 source={source} limit={limit} row_count={len(rows)} '
                            f'truncated=true sql={final_sql[:120]!r}')
            return {'ok': True, 'source': source, 'sql': final_sql,
                    'columns': columns, 'rows': rows,
                    'row_count': len(rows), 'truncated': truncated}
        finally:
            conn.close()
    except Exception as e:  # noqa: BLE001
        log.error(f'查询失败 source={source} error={type(e).__name__}: {e} sql={final_sql[:120]!r}')
        return {'ok': False, 'error': f'{type(e).__name__}: {e}'}


def tables(source):
    """读注册表表清单（不访问数据库）。返回 {ok, source, tables}。"""
    cfg = _load_cfg().get(source)
    if cfg is None:
        return {'ok': False, 'error': f'未知数据源: {source}，可用: {_source_names()}'}
    items = []
    for name, info in cfg.get('tables', {}).items():
        sf = info.get('schema_file')
        if sf and not os.path.exists(os.path.join(ROOT, sf)):
            sf = None
        items.append({
            'name': name,
            'database': info.get('database'),
            'cn_name': info.get('cn_name'),
            'record_count': info.get('record_count'),
            'category': info.get('category'),
            'description': info.get('description'),
            'schema_file': sf,
        })
    return {'ok': True, 'source': source, 'tables': items}


def schema(source, table):
    """表结构内省（真实查询 INFORMATION_SCHEMA）。返回 {ok, columns}。

    始终按 TABLE_SCHEMA + TABLE_NAME 过滤：Doris 下同名表可能存在于多个库，
    仅按表名过滤会返回跨库重复列。
    """
    cfg = _load_cfg().get(source)
    if cfg is None:
        return {'ok': False, 'error': f'未知数据源: {source}，可用: {_source_names()}'}
    db = cfg.get('database') or cfg.get('tables', {}).get(table, {}).get('database')
    if not db:
        return {'ok': False, 'error': f'无法确定表 {table} 所属 database，请在注册表 tables 中补全'}
    try:
        conn, _ = _connect(source)
        try:
            sql = ("SELECT COLUMN_NAME, COLUMN_TYPE, COLUMN_COMMENT "
                   "FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=%s "
                   "AND TABLE_NAME=%s ORDER BY ORDINAL_POSITION")
            with conn.cursor() as cur:
                cur.execute(sql, (db, table))
                cols = [{'name': r[0], 'type': r[1], 'comment': r[2] or ''} for r in cur.fetchall()]
            return {'ok': True, 'source': source, 'table': table, 'columns': cols}
        finally:
            conn.close()
    except Exception as e:  # noqa: BLE001
        log.error(f'内省失败 source={source} table={table} error={type(e).__name__}: {e}')
        return {'ok': False, 'error': f'{type(e).__name__}: {e}'}


def main(argv=None):
    p = argparse.ArgumentParser(description='Doris/MySQL 统一只读查询网关')
    p.add_argument('--sources', action='store_true', help='列出可用数据源')
    p.add_argument('--source', help='数据源名: doris / mysql_gf')
    p.add_argument('--tables', action='store_true', help='列出数据源表清单')
    p.add_argument('--schema', metavar='TABLE', help='内省表结构')
    p.add_argument('--sql', help='只读查询语句')
    p.add_argument('--limit', type=int, default=DEFAULT_LIMIT,
                   help=f'返回行数上限（默认 {DEFAULT_LIMIT}，最大 {MAX_LIMIT}）')
    args = p.parse_args(argv)

    if args.sources:
        out = {'ok': True, 'sources': _source_names()}
    elif args.source and args.tables:
        out = tables(args.source)
    elif args.source and args.schema:
        out = schema(args.source, args.schema)
    elif args.source and args.sql:
        out = query(args.source, args.sql, args.limit)
    else:
        out = {'ok': False, 'error': '用法见模块 docstring；用 --help 查看'}
    print(json.dumps(out, ensure_ascii=False, default=str))
    sys.exit(0 if out.get('ok') else 1)


if __name__ == '__main__':
    main()
