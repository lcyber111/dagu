# 智能体生成器架构优化与重构方案

> 版本：v2.0　|　日期：2026-08　|　状态：待专家评审
> 适用范围：`workspace/version0731/agents_gen` 全项目
> 关联：`README.md`、`shared/*`、`templates/*`、`scripts/*`、`lib/*`、`config/*`、`.opencode/agents/*`
> 本版变更：v2.1 新增「开发计划（前置）」「对话层：专家式决定性提问」（§4.5，内容级改进，不建 schema 机制）与
> 「整链路模块化视图」（§4.6，文档级契约，不实施运行时机制）；明确 P5 智能应用推迟、P2 回归画像化；
> 明确离线保证无仓库内攻坚（LLM 切换与网络层为部署期配置），P0 冒烟聚焦 skills/权限验证。
> v2.0 新增「平台机制选型：shared 模块 vs 原生 Skills」章节（§5），重构离线保证为三层模型（§8），
> 修正生成器定位与自包含/可审计性表述，补充 app 输出类型化、阈值单一来源等设计点。

---

## 开发计划（分步执行）

> **使用方式**：把序号（如"完成 1-3 号"）连同该条目内容交给开发智能体执行；每完成一批，
> 按该批的**验证**跑一遍——确认改动生效、且未引入新问题——再进入下一批。任何一批验证不过，
> 就地修正，不带着问题往后走。7 号（P5/P6）为推迟项，仅在触发条件满足后启动。

**1. 环境验证与 P0 冒烟（所有后续步骤的前置门）**
- **解决的问题**：fork 是否支持原生 skills 未验证（可能白做）；`Test-Path` 在 Linux 容器必然失败。
- **思路**：容器内建 `smoke` skill 冒烟，确认 `available_skills` 可见 + `permission.skill` 门控生效；失败则回退保守方案（保持 shared + Boot Sequence）。权限层验证：persona `webfetch/websearch: deny` 强制生效、`permission.bash` 网络命令 glob 加固在 fork 中是否支持（支持则加，不支持则跳过）。修复 `Test-Path` 3 处（改为 `python3 -c "import os; os.path.exists(...)"`）。
- **验证**：`python scripts/selftest.py` 全过；存量 2 个 agent 行为等价。
- **注**：离线保证不做仓库内攻坚——前端 `lib/` 已本地化、构建/校验脚本本地、DB 内网地址，均已离线；LLM provider 切换与网络层兜底属**部署期配置**（见 §8），不在本仓库改动。

**2. 对话体验改进（§4.5 内容级，不改架构）**
- **解决的问题**：3 轮问答僵硬笼统、"为交互而交互"、NL 已含信息仍机械追问。
- **思路**：按四种问题类型（规则澄清/范围收窄/缺口提醒/偏好确认）重写 `agent-generator.md` 第1-3轮的问题文本与选项；问题区与决策区在文件内分区存放、注释隔开；加"NL 已含则跳过该问"的推断逻辑。
- **验证**：3 组模拟问答（需求明确 / 模糊 / 自带规则）→ 生成的 agent 过 selftest；用户切 Tab 实测提问是否变专业。

**3. SOP 单份 + 能力技能化（P1）**
- **解决的问题**：模板改一次、存量 agent 全漂移；9 个 shared 模块清单两处维护。
- **思路**：从 `templates/analysis-agent.md` 抽出通用 SOP → `shared/analysis-runtime.md`（persona 直读、强制保序）；9 个 shared 模块按 §5.4 映射迁为 `.opencode/skills/`（env-offline 拆权限/说明两层）；模板瘦身删 Boot Sequence。
- **验证**：模板行数显著下降；容器内 skills 可见；存量 us-carrier 走新链路过 `validate_html.py`（行为等价）。

**4. 画像化（P2）**
- **解决的问题**：改知识要重生成 agent、覆盖手工调整；生成物无法 diff/审计；决策表散文硬编码。
- **思路**：新增 `templates/domain-profile.schema.json`；生成器从"填 20+ 占位符"改为"决策画像字段"，输出薄 persona + `config/domains/<domain>.json`；存量 us-carrier / khamenei 迁移。
- **验证**：生成产物过 Schema 校验；selftest 扩展画像正/负例；存量场景行为等价。

**5. 分析模式资产化（P3）**
- **解决的问题**：AIS 异常等业务逻辑以提示词伪代码内嵌，不可复用/测试/版本化；阈值 KB 与代码双源漂移。
- **思路**：新建 `lib/analysis/`，先迁 AIS 异常判定模块（含入参 schema + 单测）；画像 `analysis_patterns` 改为引用模块 id；阈值 params 单一来源（KB 只解释语义）。
- **验证**：模块可单测；同一模式被多画像引用；selftest 覆盖。

**6. 输出类型化（P4）**
- **解决的问题**："智能应用"只覆盖静态大屏、三处 dashboard-only 硬编码。
- **思路**：新增 `templates/app-manifest.schema.json`；拆除三处"必须输出 HTML 大屏"硬编码；画像 `output` 扩展为 app_manifest，`app_type: dashboard` 映射到现有 spec 管线。
- **验证**：现有 6 个 html 产物通过新管线零行为变化回归。

**7. 前后端应用模板（P5）+ 动态路由（P6）——推迟，触发后再细化**
- **触发条件**：出现明确的前后端应用需求，且镜像已预装 fastapi/flask 运行时。P6 仅当出现"意图模糊/不想维护入口"需求时实施。

---

## 1. 文档目的与读者

本文档回答一个问题：**"当前智能体生成器的设计方式是否最优？"**，并给出完整的优化重构方案。

- **读者**：架构评审专家、系统维护者、后续实施者。
- **你要评估的核心主张**：当前"生成器 + 自包含胖 agent"形态存在结构性问题；应重构为
  **"身份与能力分离"三层架构**（薄 persona + 领域画像 + 共享运行时），能力资产承载于
  **opencode 原生 skills**（平台发现 / 懒加载 / 权限门控），把"大屏生成"升级为
  "智能应用生成"管线（app_manifest 抽象），并改善**对话体验**——唯一面向用户的界面从
  "机械三轮表单"改进为"专家式决定性提问"（内容级改进，见 §4.5）。
- **事实基准**：文档中所有"现状"描述均基于对仓库的实际检查（目录、文件、代码路径），
  并标注了关键证据位置（`文件:行号`），非臆测。已实施部分（严格离线、display_name、
  禁用官方 agent、server.json 迁移）已合并进现状。

---

## 2. 用户需求澄清

### 2.1 原始需求

> 通过自然语言描述清楚，生成垂域专业智能体，并能够生成智能应用。

拆解为以下能力目标：

| # | 能力 | 含义 |
|---|------|------|
| R1 | 自然语言 → 垂域专业智能体 | 用户用业务语言描述需求，系统自动生成一个"能独立处理该类问题"的专业智能体 |
| R2 | 垂域智能体 → 智能应用 | 生成的智能体执行任务时，产出**可运行、可交互、可部署**的智能应用，而非文本/表格 |
| R3 | 规模化与可演进 | 垂域智能体预期达到**几十个**规模；知识、数据、应用形态持续演化，不能推倒重建 |
| R4 | 专家式对话体验 | 生成过程中的追问必须让用户感到专业、决定性：要么澄清未说明的规则、要么收窄数据范围、要么提醒遗漏维度；不是机械的三轮表单（用户重点诉求，改进见 §4.5） |

### 2.2 环境约束（硬约束）

| 约束 | 现状 | 影响 |
|------|------|------|
| **严格离线** | 禁止 websearch/webfetch/pip/外部下载；情报仅来自本地知识库 + 内网数据库 | 一切能力必须离线可运行；离线保证是**三层模型**（见 §8） |
| **内网 LLM** | 权威配置 = docker-compose 只读挂载的 `config/opencode.json` → 容器 `/root/.config/opencode/opencode.json`；provider `ds` = openai-compatible → `api.deepseek.com`（**调测期公网**）。另有 `agents_gen/config.json`（disabled qwen）为第二处 | 部署切内网 vLLM 仅改 baseURL + apiKey，无需动代码 |
| **内网数据库** | Doris + MySQL 均部署于内网（`config/db_sources.json`） | 连接配置指向内网地址 |
| **容器化部署** | opencode serve（:4096）+ nginx 静态服务（:7001），Docker Compose 编排 | 智能应用需适配容器内运行 |
| **业务系统前端** | 已定制：列出智能体（读 `display_name`），官方内置 agent 已禁用，默认 `agent-generator` | 生成的智能体必须可作为前端实体列出 |

### 2.3 边界与当前不在范围

- LLM 推理服务本身的搭建（内网已有）
- 数据库数据同步（内网已有）
- nginx / 静态服务打包（当前不作为重点）
- 生成产物的版本化入库（当前继续 gitignore，见 §10.1 治理注记）

---

## 3. 现状架构（AS-IS）

### 3.1 技术栈与部署形态

```
Docker Compose
├─ opencode 服务   smanx/opencode:1.17.10-custom-nods-python-pandas 自定义镜像
│                   （bun 单文件二进制 + 内嵌 openai-compatible provider）
│                   + python3(pandas/pymysql/jsonschema) + node + ECharts 离线库
│                   只读挂载 config/opencode.json → /root/.config/opencode/opencode.json
│                   （default_agent=agent-generator，禁用 build/plan/general/explore）
│                   working_dir=/workspace/version0731/agents_gen
└─ nginx 服务       static 托管 workspace（html/ 大屏 + 目录浏览，端口 7001）
```

### 3.2 业务路径（当前实际运行流程）

```
① 用户自然语言描述需求
② agent-generator（设计顾问）意图路由 + 3 轮业务问答
     问任务类型 / 问分析视角 / 问分析深度（question 工具）
③ 内部决策（决策表）→ 匹配唯一模板 analysis-agent.md → 填充 20+ 占位符
④ 写 .opencode/agents/<domain>.md   （自包含"胖 agent"）
⑤ 用户切 Tab 使用该 agent
⑥ agent Boot Sequence 读 9 个共享模块（env-offline/env-server/db-*/analysis-common/html-output/qa-html/viz-dark-theme/tools-guide）
⑦ 连接 Doris/MySQL 查询 → 按内嵌"专用分析模式"分析
⑧ 产出声明式 spec JSON → build_dashboard.py（JSON Schema 深度校验）→ html/<name>.html
⑨ validate_html.py 三层校验（结构 + JS 语法 + ECharts SSR 行为）→ OK 交付
⑩ 读取 config/server.json 拼接内网查看链接，汇报
```

### 3.3 资产清单（已沉淀的可用资产）

| 层 | 资产 | 说明 |
|----|------|------|
| 元智能体 | `agent-generator.md`（566 行） | 生成器本体：意图路由 + 3 轮问答 + 决策表 + 占位符填充 |
| 模板 | `analysis-agent.md`（239 行） | 唯一生成模板（SOP Step1-4 + 占位符 + Boot Sequence） |
| 共享模块 | `shared/` 9 个 | env-offline / env-server / tools-guide / db-doris / db-mysql / analysis-common / html-output / qa-html / viz-dark-theme |
| 数据层 | `config/db_sources.json` | Doris + MySQL 源注册表（23+10 张表、凭据、schema 引用） |
| | `config/server.json` | 内网查看地址（已迁移至此，原 .opencode/server.json） |
| 配置层 | `config/opencode.json`（仓库根） | 权威配置：默认 agent + 禁用内置 agent + provider ds（docker-compose 只读挂载） |
| 知识层 | `schema/*.md` 37 个 | 字段定义与判读规则 |
| | `rag/*.md` 6 个 | 领域知识库 |
| 工具层 | `scripts/` 4 个 | build_dashboard / validate_html / check_dashboard / selftest |
| 前端资产 | `lib/dashboard/` | chart-builders.js（图表唯一实现）/ dashboard.css / dashboard.js |
| | `lib/echarts/` + `lib/echarts-maps/world.js` | 离线地图渲染 |
| 契约 | `templates/dashboard-spec.schema.json` | 大屏 spec 唯一校验源 |
| 生成物 | `.opencode/agents/{us-carrier,khamenei}-intel.md` | 2 个存量垂域 agent（gitignored，421/392 行） |

> 注：全仓库**当前不存在 `.opencode/skills/`**，所有能力模块均通过 shared + Boot Sequence 在提示词层传递。

### 3.4 已确认有效的设计（重构必须保留）

1. **声明式 spec + 构建脚本 + JSON Schema 深度校验**——LLM 不手写 HTML，格式/数据形状非法
   当场拒绝，杜绝"结构合法但图空"。这是全体系最硬的资产。
2. **三层行为校验**——结构 + JS 语法 + 真实 builders 在 node 中构建并 ECharts SSR 渲染非空；
   浏览器与校验共用同一份 `chart-builders.js`，契约不漂移。
3. **共享模块 + Boot Sequence**——基础设施知识（DB 连接 / Haversine / 主题 / QA 流程）
   已从生成物中分离，避免最坏情况（全内联）。
4. **离线优先**——所有前端资源本地化，生成物双击可运行，无任何外部引用。
5. **质量回归**——`selftest.py` 正例全过 + 构造负例必败，已在容器内验证。
6. **权限层而非仅提示词层**——生成物 `webfetch/websearch: deny` 是 opencode **权限机制**
   生效（平台级强制），证明该 fork 的 permission 门控可用，为 skills 权限控制铺路（见 §5）。

### 3.5 结构性问题（重构的动因，均带实测证据）

| # | 问题 | 证据 |
|---|------|------|
| P1 | **生成物是"自包含胖 agent"**，由两类内容叠加：(a) 模板 SOP Step1-4（约 200 行）全文拷入；(b) 领域数据（15 张表清单 / 15 个 schema 引用 / 6 个 KB 引用 / 10 条路由规则 / 6 个分析模式 / 默认偏好）以散文内联 | `us-carrier-intel.md` 前 190 行为模板 SOP 拷贝 + 中间为领域数据（表清单/引用/模式/路由），L102-185 为 6 个内嵌分析模式 |
| P2 | **SOP 双份维护**：模板文件本身写死 SOP（Step1-4），生成时再拷一份进 agent；模板一改，存量全部漂移 | 历史：模板内联"7项自检"与 shared 冲突；本轮为改离线/display_name 手动 patch 了 2 个生成物 |
| P3 | **知识过期**：DB schema / KB / 分析逻辑演化后，不重新生成就过期；重新生成又覆盖手工调整 | schema 37 个文件会演进；当前无增量更新机制 |
| P4 | **分析模式不可资产化**：AIS 异常判定、空间关联、威胁分级等业务逻辑以"提示词里的伪代码"形式每 agent 抄一遍——不可复用、不可测试、不可版本化 | `us-carrier-intel.md` L102-185 的 6 个分析模式全部内嵌 |
| P5 | **输出形态结构化不足 + 决策逻辑散文化**：生成器决策表已相当丰富（意图路由 / 3 轮问答 / 模式选择 / 双库表匹配），但**输出物是 20+ 占位符内联的胖文本**，无法校验、无法 diff、无法增量演进；决策表以散文硬编码在生成器内，新增数据源/模式要改 prose | 决策表 `agent-generator.md:262-350`，占位符表 `agent-generator.md:312-332` |
| P6 | **"智能应用"只覆盖静态大屏**：spec 管线到静态 HTML 为止，无法表达前后端逻辑、交互、部署；且 `env-offline.md#5`、模板 `analysis-agent.md:184`、生成器能力清单三处硬编码"必须输出 HTML 大屏" | 产物为单文件 html/，无 app 抽象层；三处 dashboard-only 硬编码（拆除清单见 §7） |
| P7 | **对话层僵硬**：3 轮问答固定（任务类型/视角/深度），问题文本与决策表耦合在同一散文里（改问答必动决策）、领域无关、NL 已含信息仍机械追问，用户感知"为交互而交互" | `agent-generator.md:182-245` 三个 question 调用 + 答案解析硬编码；问题无"规则澄清/范围收窄/缺口提醒"类型设计（拆解见 §4.5） |

> 注意：P2 已于本轮部分缓解（离线/display_name 改动通过模板 + 手动 patch 存量同步），
> 但这是"人工同步"，不是"架构解决"。只要模板再次演进，漂移必然复发。

### 3.6 现存跨平台不一致（顺带修复项）

- `shared/tools-guide.md`、`shared/env-offline.md`、`agent-generator.md:459/461` 仍使用
  PowerShell 专属的 `Test-Path`，而运行环境（容器）为 Linux，命令必然失败。
  server.json 读取已改为跨平台 `python3 -c ...`，`Test-Path` 应统一替换为
  `python3 -c "import os; print(os.path.exists('...'))"`。

---

## 4. 目标架构（TO-BE）

### 4.1 核心设计主张

**把"身份"与"能力"分离，把"差异化"做成结构化、可校验、可演进的资产；能力承载于平台原生机制。**

- **身份** = 薄的、稳定的 persona（一个垂域一个入口，前端可列）
- **能力** = 共享的运行时 SOP（persona 直读，一份，永不复制）+ 可复用能力技能（原生 skills）
- **差异化** = 领域画像（JSON，运行时加载，Schema 校验，改它不重生成 agent）
- **业务逻辑** = 分析模式资产库（可复用 Python 模块，不是提示词伪代码）
- **智能应用** = 应用清单（app_manifest）抽象，静态大屏只是其一特例
- **平台机制** = 可复用能力以 opencode **原生 skills** 承载（平台发现 / 懒加载 / 权限门控）
- **对话** = 专家式决定性提问（四种问题类型作为生成器提问原则；内容级改进，不建 schema 机制，见 §4.5）
- **流程** = 整链路环节化视图（生成/运行共 11 环节，文档级契约，不实施运行时机制，见 §4.6）

### 4.2 分层架构

```
┌─────────────────────────────────────────────────────────────────┐
│  [设计期] 智能体生成器（LLM，唯一 primary 设计入口）                │
│    NL 需求 → 决策 → ①薄 persona + ②领域画像(含 app_manifest)       │
└─────────────────────────────────────────────────────────────────┘
                              │ 产物
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  [资产层]（单一来源，可演进、可校验）                                │
│  config/domains/*.json      领域画像 + app_manifest（数据资产）    │
│  .opencode/skills/*/SKILL.md 可复用能力（原生 skills，按需发现）   │
│  shared/analysis-runtime.md 运行时 SOP（persona 直读，强制保序）   │
│  lib/analysis/              分析模式（可复用 Python 模块）         │
│  lib/app-templates/         应用模板（前后端骨架）                 │
│  lib/dashboard/            大屏引擎（现有，保留）                  │
│  templates/*.schema.json    profile/manifest/spec 契约           │
└─────────────────────────────────────────────────────────────────┘
                              │ 运行时加载
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│  [运行期] persona（不携带 SOP 与能力清单）                          │
│  读画像(JSON) → 读 SOP → 按需调 skill(能力) → 取数据(DB)          │
│  → 按 app_manifest 产出工程 → 构建 → 校验 → 容器内部署            │
└─────────────────────────────────────────────────────────────────┘
```

### 4.3 各层设计

#### 4.3.1 薄 persona（`.opencode/agents/<domain>.md`）

生成器产出的小文件，职责只有"身份声明 + 指向画像 + 最小权限"。**不再写 9 行 Boot Sequence**
（能力由平台 skills 列表可见）：

```yaml
---
description: <一句话描述>
display_name: <中文显示名，前端 Tab 用>
mode: primary
color: "<hex>"
temperature: <0.1-0.3>
permission:
  read: allow / glob: allow / grep: allow / bash: allow
  webfetch: deny / websearch: deny
  bash:                       # 离线加固：禁止网络类命令（见 §8）
    "*": allow
    "curl*": deny / "wget*": deny / "pip*": deny / "npm*": deny
---
你是"{display_name}"——{领域角色一句话}。

执行任务前：
1. read config/domains/{domain}.json（你的领域画像：数据/知识/路由/模式/输出）
2. read shared/analysis-runtime.md（统一运行时 SOP，必须完整执行，不得省略步骤）
3. 按需通过 skill 工具加载能力模块（见 available_skills 列表，只加载用得到的）
4. 按画像中的路由规则与数据源执行分析，产物走共享构建管线。
```

**persona 永不过期**：知识演进只改画像/KB/技能，不需要重新生成 agent。

#### 4.3.2 领域画像（`config/domains/<domain>.json`）——生成器真正的产物

```jsonc
{
  "domain": "carrier-intel",            // 唯一 id
  "display_name": "美军航母情报综合分析",
  "description": "…",
  "data_sources": [                     // 引用于 config/db_sources.json 注册表
    {"ref": "doris", "tables": ["ais_ship_track", "carrier_attribution", "…"]},
    {"ref": "mysql_gf", "tables": ["…"]}
  ],
  "schema_refs": ["schema/doris_ais_ship_track.md", "…"],   // 引用，不拷贝
  "kb_refs": ["rag/carrier_intel_report.md", "…"],
  "analysis_patterns": [                // 引用 lib/analysis/ 模块 id；阈值为 params 单一来源
    {"pattern": "ais-anomaly", "params": {"off_window_months": 6, "min_interval_hours": 1}}
  ],
  "routing_rules": [                    // 用户表述 → 数据源/表/模式 的路由
    {"keyword": "异常|AIS OFF", "target": "ais-anomaly"}
  ],
  "extraction_rules": ["舷号", "海域", "状态"],   // 信息提取要素
  "output": {                           // 智能应用偏好（见 §7）
    "app_type": "dashboard",
    "theme": {"primary": "#00ff88"}
  }
}
```

受 `templates/domain-profile.schema.json` 校验（复用 dashboard-spec 的哲学）。生成质量从
"读文本挑错"变为"Schema 校验 + 冒烟测试"，可自动化、可审计。

> **画像 vs skills 的边界**：画像承载**领域数据**（哪些表/库/路由/模式/阈值），skills 承载
> **通用能力指令**（怎么连库、怎么写大屏）。skills 替代不了画像——一个"如何查 Doris"的技能
> 被任何垂域复用，但"本域用哪几张表、异常阈值是多少"是每个域不同的数据。

#### 4.3.3 共享运行时（`shared/analysis-runtime.md`）——SOP 唯一来源

从 `analysis-agent.md` 模板抽出的通用执行 SOP（需求理解 → 数据路由 → 数据获取 →
质量检查 → 分析 → 产物构建 → 汇报）。**模板不再复制 SOP**，只留 persona 骨架 + 画像指针。

**为什么 SOP 不迁为 skill**：SOP 是"必须完整、按序执行"的过程，而 skills 是**懒加载、由模型
按 description 自主决定是否加载**——把"必读"语义交给懒加载等于放弃保证。因此 SOP 由
persona 第 2 步直读（显式、强制、保序），可复用能力的"怎么做"才进 skills。

#### 4.3.4 分析模式资产库（`lib/analysis/`）

把 P4 的"提示词内嵌伪代码"抽成可复用、可单测、可版本化的 Python 模块：

```
lib/analysis/
├── ais_anomaly.py          # AIS 异常判定（OFF/ON 序列、等级、误判防范）
├── spatial_association.py  # 航母-舰载机空间关联（Haversine + 高度分层）
├── threat_assessment.py    # 威胁分级
├── __init__.py             # 模式注册表：id → 函数 + 入参 schema
```

任务时 agent 只做"**选模式 + 传参 + 装配数据**"，不再重新发明逻辑。

**阈值单一来源（防双源漂移）**：分析模式的阈值（如 <50km+<200ft、200 海里联动、1 小时
误判防范）目前散在 KB 散文里。抽取后规定：
- **阈值 = 画像 `analysis_patterns[].params`**（配置项，可被校验）；
- **KB（rag/*.md）管语义**——解释"为什么是这些阈值、适用什么场景"；
- **模块管执行**——读 params，不含魔法数字；
- 变更只改画像一处，KB 与代码都不动。

#### 4.3.5 智能应用抽象（`app_manifest`，见 §7）

#### 4.3.6 质量保障（贯穿）

```
契约层   domain-profile.schema.json / app-manifest.schema.json / dashboard-spec.schema.json
生成期   persona+画像 产出后自动校验（JSON Schema）+ skills 冒烟（容器内 available_skills 可见）
构建期   build_dashboard.py 深度校验（数据形状不变量）
验证期   validate_html.py 三层（结构 + JS 语法 + 行为 SSR）
回归期   selftest.py 正例全过 + 负例必败
```

### 4.4 功能实现逻辑（端到端数据流，TO-BE）

```
① NL 需求
② 生成器对话 + 决策（不再是填文本，而是填画像字段）：
   对话按 §4.5 原则提出决定性追问（规则澄清/范围收窄/缺口提醒/偏好确认）→
   决策：识别领域 → 选数据源/表 → 选 KB/schema 引用 → 选分析模式 → 定 app_type/主题
③ 产出：薄 persona（小 md，无 Boot Sequence）+ 领域画像（json，含 manifest 偏好）
④ persona 通过 Schema/前端校验，注册进业务系统 Tab；能力 skills 平台可见
⑤ 运行时：用户点开 persona → 读画像 + 直读 SOP → 按 routing_rules 解析任务
⑥ 取数（DB）→ 按需加载能力 skill → 装配分析模式（lib/analysis）→ 产出 spec / manifest
⑦ build_dashboard.py（或 app 构建器）→ 校验 → 部署
```

### 4.5 对话层：专家式决定性提问（用户重点诉求）

> 定位：**内容级改进，不是架构改造**。不建 schema、不动生成器决策结构，只改问题设计原则。

#### 4.5.1 为什么单独成层

3 轮问答（`agent-generator.md:182-245`）是整条链路**唯一面向用户**的界面，此前却被当作"给定的、不动的东西"。它是用户感知体验的**唯一杠杆**——模板/画像/技能/分析库的优化用户都看不见，只有对话是可见的。

现状三个问题：

1. **耦合**：问题文本、答案解析、决策表同处 566 行散文，"改问答不动决策"做不到，没人敢动。
2. **领域无关**：固定"任务类型/视角/深度"三选一，是为喂饱决策表设计，不是为搞清楚业务设计。
3. **不可推断**：NL 已包含的信息（如"分析林肯号航母"）仍被机械追问，用户感到"为交互而交互"。

#### 4.5.2 重新定义对话目标

从"填满决策表的 3 个字段"改为：

> **用最少的关键问题，把任务确定性提高到足以生成正确智能体的程度。**

每个问题必须满足四种作用之一（**决定性判定**）：

| 类型 | 作用 | 示例 |
|------|------|------|
| **规则澄清** | 阐述用户没说的判定规则/阈值，直接定义后续分析逻辑 | "AIS 关闭多久算异常？6 个月窗口、1 小时防误判？" |
| **范围收窄** | 缩小数据表/地理范围/时间窗，决定注入哪些表与过滤条件 | "关注南海还是全球？只盯航母编队还是含舰载机？" |
| **缺口提醒** | 提醒用户遗漏的关键维度（时间范围、输出形态、数据来源） | "你只说了目标，没提时间范围" |
| **偏好确认** | 输出深度/形态/主题，仅当 NL 未给出时才问 | "输出要大屏还是表格/报告？" |

**判定标准**：一个问题若回答后不影响生成物（注入的表/模式/规则/形态），就不该问。问出来的每个问题都应让用户感到"懂行的参谋在确认关键细节"，而非"表单走流程"。

#### 4.5.3 落地方案（最小改动）

1. 重写 `agent-generator.md` 第1-3轮的问题文本与选项，按上表四种类型重构，并加"NL 已含则跳过该问"的推断逻辑（自适应，不做 fixed/adaptive 策略抽象）。
2. 在 `agent-generator.md` 内把"问题区"与"决策区"分区存放、注释隔开，消除"改一问必动决策"的耦合感知。
3. 规则澄清型问题的答案流入画像 `analysis_patterns[].params`（与 §4.3.4 阈值单一来源闭环）：对话把"用户心里的规则"显式化，画像结构化，模块执行。

> **数据化触发条件（保留，不提前做）**：对话体验改善以内容级完成。仅当"问题需按域差异化 + 垂域 > 5 + 已反复修改"三项同时成立时，才考虑把问题区抽为可配置数据（如 `config/dialog/*.json`）。当前 N=2，散文够用。

#### 4.5.4 代价（诚实列出）

- 对话质量上限依赖 LLM 依循提问原则的执行力——用验证（生成产物 Schema 校验 + 冒烟）兜底，而非机制强制。
- 自适应"能推断就不问"使测试面变广（需覆盖"哪些情况该问/不该问"），在 P2 冒烟中补跳问分支样例。

### 4.6 整链路模块化视图（流程视角）

> 定位：**文档级对齐视图，不是运行时机制**。用于暴露"哪些环节已可独立优化、哪些仍耦合"，指导重构优先级；不为 11 个环节建立任何契约文件或运行时调度。

#### 4.6.1 环节划分

从"用户任务"到"最终 HTML 交付"的整条链路切分如下（含现状独立度）：

| # | 环节模块 | 阶段 | 现状实现位置 | 独立度 |
|---|---------|------|-------------|--------|
| M1 | 意图路由（NL→意图分类） | 生成期 | `agent-generator.md` L144-178 散文表 | ✗ 耦合 |
| M2 | 对话编排（问什么/问几轮） | 生成期 | L182-245 硬编码 question 调用 | ✗ 耦合 |
| M3 | 决策映射（答案→画像字段） | 生成期 | L262-350 散文决策表 | ✗ 耦合 |
| M4 | 产物装配（persona+画像 写出） | 生成期 | L312-332 占位符填充 | △ 半独立 |
| M5 | 需求解析（运行期任务路由） | 运行期 | 生成物内嵌 routing_rules | △ 改后需重生成 |
| M6 | 数据获取（DB 连接/查询） | 运行期 | `shared/db-*.md` | ✓ 模块 |
| M7 | 分析模式（业务逻辑） | 运行期 | 生成物内嵌伪代码 L102-185 | ✗ 耦合（P3 修复） |
| M8 | 产物声明（spec/manifest） | 运行期 | 手写 spec JSON | ✓ 有 Schema |
| M9 | 构建（spec→HTML） | 运行期 | `scripts/build_dashboard.py` | ✓ |
| M10 | 校验（三层 QA） | 运行期 | `scripts/validate_html.py` | ✓ |
| M11 | 汇报/部署（server.json 拼链接） | 运行期 | 生成物内嵌 + `shared/env-server.md` | △ |

#### 4.6.2 原则（本方案对"环节独立优化"的边界）

环节独立优化成立需三点：接口契约、单点修改、独立测试。**本方案只对已受益环节做契约化**：

- **M8-M10 已模块化**（spec Schema + 构建/校验脚本）——保留，不扩大；
- **M7 分析模式**→ `lib/analysis/` 可复用 Python 模块（P3），可单测、可版本化；
- **M1-M4 生成器散文**：靠分区存放 + 决策画像化（P2）解耦，**不建环节契约文件**；
- **其余环节保持现状**，不做运行时机制。

> **显式声明：本节只作认知对齐，不实施任何运行时契约/调度（B 方案的反对理由见 §10）。** 防止误读为要做 11 个环节的独立运行。

---

## 5. 平台机制选型：shared 模块 vs 原生 Skills

> 本节回答：现有"shared/*.md + Boot Sequence"规则体系，对比 opencode 原生 skills 系统的优缺点，
> 以及本项目应采取的策略。

### 5.1 本质判断

**现有这套 `shared/*.md + Boot Sequence` 就是一套手写的类-skill 系统**——只是没有使用平台
原生机制：靠"提示词要求 agent read 文件"模拟了 skills 的"按需加载"，靠模板/生成器硬编码清单
模拟了"发现"。理解这一点后，选型问题变成"继续维护手写版本，还是迁到平台原生版本"。

opencode 原生 skills 事实（官方 docs/skills，2026-07-31）：
- 位置：`.opencode/skills/<name>/SKILL.md`（另有 `~/.config/opencode/skills/`、`.claude/skills/`）
- 前置字段：`name`（必填，kebab-case，须与目录同名）+ `description`（必填，用于发现）
- 发现：平台把所有 skill 的 name+description 注入 `available_skills` 列表，**任何 agent 天然可见**
- 加载：`skill` 工具按需懒加载 body（`skill({name: "..."})`）
- 权限：`permission.skill` 支持 allow/ask/deny + 通配 + 按 agent 覆盖 + 可整体禁用

### 5.2 对比

| 维度 | 现状（shared + Boot Sequence） | 原生 Skills |
|------|---------------------------|------------|
| 发现 | 硬编码 Boot Sequence（模板写死 9 模块清单）；agent 不知道清单外的模块 | 平台自动把全部 skill 的 name+description 注入 available_skills，任何 agent 可见 |
| 加载 | 每任务 eager read 9 个模块，上下文随模块增长线性膨胀 | skill 工具按需懒加载，只读命中的 body |
| 上下文成本 | 9 个模块约 450 行全部进上下文 | description 常驻（几十字节/个），body 按需 |
| 权限 | 无平台级门控，只能提示词约束 | permission.skill: allow/ask/deny + 通配 + 按 agent 覆盖 + 禁用 |
| 强制 | "必须加载"是提示词要求，模型可能跳过 | 同为模型自主判断，但平台可见性显著提高命中率 |
| 互操作 | 自造约定，外系统不认识 | 标准 SKILL.md，兼容 Claude/agents 生态 |
| 维护 | 模块清单两处维护（模板 Boot Seq + 生成器第7轮），已见漂移 | 单一来源（SKILL.md 自带 description） |
| 对生成器 | 每个 agent 要写 9 行 Boot Sequence | persona 无需 Boot Sequence，skill 描述天然可见 |

### 5.3 skills 的三个硬局限

1. **懒加载依赖模型自主选择**——"必读"语义无法平台保证。关键不变量（离线规则、必须构建 +
   验证、按 app_type 输出）**不能只靠技能**。
2. **fork 支持未验证**——容器镜像是 `smanx/opencode:1.17.10-custom-nods`，与本运行环境同代
   （当前环境已见 skill 工具 + available_skills），但需在容器内冒烟确认。
3. **只承载指令，不承载 Python 逻辑**——`lib/analysis` 等执行代码仍须独立存在（现状亦然）。

### 5.4 决策：混合式（推荐）

| 资产 | 去向 | 理由 |
|------|------|------|
| 9 个 shared 能力模块（db-doris / db-mysql / analysis-common / html-output / qa-html / viz-dark-theme / tools-guide / env-server） | 迁移为 `.opencode/skills/` | 平台发现 + 懒加载 + 权限门控；消除双处清单 |
| env-offline 离线规则 | **拆两层**：硬约束 → persona 权限（webfetch deny + bash 网络命令 deny）+ 网络层；说明性内容 → 技能 | 离线是不可讨价的硬保证，不能交给懒加载 |
| analysis-runtime SOP | persona 直读（强制保序） | 懒加载无法保证"必须完整执行" |
| 领域画像 config/domains/*.json | 保持 JSON 数据资产 | 技能是能力指令，不是领域数据 |
| persona | 最小化，无 Boot Sequence | 生成器不再写 9 行清单 |

**迁移方式**：每个 shared/*.md 包装为 `SKILL.md`（加 name/description 前置字段，正文原样），
删除 persona 的 Boot Sequence；`agent-generator.md` 与模板同步改。映射表：

```
shared/env-server.md        →  skills/env-server/SKILL.md
shared/tools-guide.md       →  skills/tools-guide/SKILL.md
shared/db-doris.md          →  skills/db-doris/SKILL.md
shared/db-mysql.md          →  skills/db-mysql/SKILL.md
shared/analysis-common.md   →  skills/analysis-common/SKILL.md（Haversine 与 lib/analysis 共用）
shared/html-output.md       →  skills/dashboard-output/SKILL.md
shared/qa-html.md           →  skills/html-qa/SKILL.md
shared/viz-dark-theme.md    →  skills/viz-theme/SKILL.md
shared/env-offline.md       →  拆分为 persona 权限 + 说明性技能（保留文档）
shared/analysis-runtime.md  →  留在 shared/，persona 直读
```

### 5.5 容器冒烟验收（P0 前置）

```
1. 容器内建 .opencode/skills/smoke/SKILL.md（name: smoke, description: 冒烟验证）
2. 打开任意 agent，确认 available_skills 列表出现 smoke
3. 确认 permission.skill 门控（allow/deny）生效
4. 冒烟通过 → 走 P1 迁移；失败 → 回退保守方案（保持 shared + Boot Sequence，skills 仅作设想）
```

---

## 6. 对比分析：现状 vs 目标

| 维度 | 现状（胖 agent） | 目标（身份/能力分离） | 收益 |
|------|----------------|---------------------|------|
| **一致性** | SOP 每 agent 一份，模板一改全漂移 | SOP 单份 + 能力技能单份，persona 只留骨架 | 消除双份维护 |
| **可维护性** | 改知识要重生成 + 覆盖手工调整 | 改画像/KB/技能即时生效 | 增量演进，不推倒 |
| **可测试性** | 分析逻辑在提示词里，无法单测 | lib/analysis 模块可单测 + 入参校验 | 质量可自动化 |
| **可扩展性** | 新增垂域 = 整套静态文件复制 | 新增垂域 = 一个画像 json（Schema 校验） | 几十个规模可控 |
| **资产化** | 分析模式/应用逻辑随 agent 发散 | 分析库/技能/应用模板/画像/契约分层沉淀 | 复用 + 可版本化 |
| **生成器定位** | 输出 20+ 占位符内联的胖文本；决策散文硬编码 | 决策画像字段，输出结构化 JSON | 输出可校验、可 diff |
| **对话体验** | 机械三轮表单，问题与决策耦合，用户感知"为交互而交互" | 专家式决定性提问（四种问题类型，内容级改进） | 唯一面向用户的层可独立优化（§4.5） |
| **智能应用** | 静态大屏到顶 + dashboard-only 硬编码 | app_manifest 抽象，可演进前后端应用 | 覆盖 R2 完整诉求 |
| **离线适配** | 已离线，但知识固化在提示词 | 离线不变，且画像/技能全本地资产；权限层加固 | 保持，且更易审计 |
| **回滚/审计** | agent 文件大、差异难审 | persona 小 + 画像 diff 清晰 | 变更可审 |
| **上下文成本** | 每任务 eager 读 9 模块 | skills 懒加载 + SOP 单份 | 随模块增长近恒定 |

**代价（诚实列出）**：
- 运行期多一层"读画像"间接跳转（冷启动多 1 次 read，可接受）
- persona **自包含/可移植性下降**：agent 依赖仓内画像/技能/SOP，单文件拷到别处跑不了；
  但**可审计性上升**（persona 薄、画像 diff 小）。该权衡已确认取分离。
- skills 引入"模型自主加载"环节：对可复用能力 OK，对"必读"不变量不 OK（已通过 persona 直读 +
  权限层 + 网络层规避，见 §8）。

---

## 7. 智能应用演进（满足 R2 与远期目标）

远期目标：**从静态大屏 → 完整可交互应用，具备前后端逻辑与部署流程规划**。
这要求在 spec 之上抽象一层 `app_manifest`：

```
app_manifest.json
├─ app_type      dashboard | list-detail | crud | report | workflow …
├─ pages         [{name, layout, components, data_binding}]
├─ data          [{source: doris|mysql, table, query, params}]
├─ interactivity filters / drill-down / export / search
├─ backend       {runtime: python-fastapi | node, endpoints}
└─ deploy        {runtime deps, ports, reverse-proxy}
```

**关键设计**：领域画像的 `output` 字段 = app_manifest，**`app_type` 是输出形态的唯一裁决点**。
静态大屏是 `app_type: dashboard` 的特例，现有 spec→build→validate 管线原样保留为 dashboard
的构建后端，**存量资产零废弃**。

### 7.1 dashboard-only 硬编码拆除清单（P4 必做）

要真正支持非大屏输出，必须拆除三处"必须输出 HTML 大屏"硬编码：

| 位置 | 现状 | 改为 |
|------|------|------|
| `shared/env-offline.md` 规则 5 | "所有分析结果必须生成 HTML 大屏文件，不得仅以文本或表格形式汇报" | "按画像 output.app_type 产出对应形态；dashboard 走 spec 管线，其他类型走 app 模板" |
| `templates/analysis-agent.md:184`（及生成物拷贝） | "所有分析结果必须以 HTML 大屏形式输出，禁止手写 HTML" | "按 app_type 调用对应构建管线，禁止手写" |
| `agent-generator.md` 第6轮能力清单 | "输出层…始终为大屏输出" | "输出层…按业务需求决定 app_type（大屏/列表-详情/报表…）" |

**离线部署形态**（硬约束下的最优解）：不采用"每应用独立 docker build"（离线无法拉基础镜像），
而是**应用以容器内进程运行**——复用已打包镜像里的运行时（python 后端 + node + nginx 反代），
生成的工程放入 volume + 更新 nginx 路由 + 重启服务，全程离线。

---

## 8. 严格离线设计（三层模型）

离线保证是**三层模型**，缺一层都不成立；按"强度"排序：

```
① 网络层（唯一硬保证）
   容器/宿主机防火墙无出网路由（无默认网关 / 防火墙 deny）。因为生成 agent 的 bash 是 allow 的，
   curl/wget/pip/npm 只能被提示词或权限拦——任何提示词与权限层都有被绕过或误用的可能，
   只有网络层是物理性的。部署时以"断网后系统仍全功能"为验收标准。
② 权限层（平台级，次硬）
   已做：persona front matter webfetch/websearch deny（注入完成，生效性在 P0 冒烟确认）。
   待做：bash 权限 glob 加固 —— {"*": allow, "curl*": deny, "wget*": deny,
   "pip*": deny, "npm*": deny, "Invoke-WebRequest*": deny}。需 P0 冒烟确认 fork 是否支持 bash glob
   权限；支持则实施，不支持则跳过（仍靠提示词层约束）。
③ 提示词层（软保证）
   env-offline 规则（禁止联网、数据缺失如实标注）；迁移后拆分：硬约束上移②，说明留技能。
```

### 已实施（本轮完成）
- 提示词去网络化：env-offline / tools-guide / analysis-agent / agent-generator 删除
  websearch/webfetch 用法，情报仅来自本地知识库 + DB
- `display_name` 全量注入（生成器/模板/存量 agent），前端 Tab 中文显示
- 禁用官方内置 agent（build/plan/general/explore），`default_agent=agent-generator`
- server.json 迁移至 config/，baseUrl 改部署机 IP，读取命令跨平台化（Linux 无 pwsh）
- Dockerfile 预装 pandas/pymysql/jsonschema/node，镜像重建并容器内全链路验证

### 待办（配合重构）
- 权限层（仓库内，P0 冒烟验证 fork 支持后实施）：bash 网络命令 glob 加固；`Test-Path` 跨平台替换
- 网络层 + LLM（**部署期事项，非本仓库改动**）：离线部署包（镜像 tar + 部署文档）；LLM provider
  在目标环境配置（切内网 vLLM/litellm，改 baseURL + apiKey，见 §2.2）；首次启动无出网调用验证
  （防火墙/无路由兜底）

---

## 9. 完整构建方案（分阶段实施）

### 阶段总览

| 阶段 | 主题 | 目标 | 风险 |
|------|------|------|------|
| P0 | 前置验证门 | 容器 skills 冒烟 + 离线三层确认 + Test-Path 修复 | 低 |
| P1 | 抽共享运行时 + 能力技能化 | SOP → analysis-runtime.md；能力模块迁 skills；模板瘦身 | 中 |
| P2 | 画像化 | domain-profile.schema.json + 生成器决策数据化 + 存量迁移 | 中 |
| P3 | 分析模式资产化 | AIS 异常等先进 lib/analysis/，阈值 params 化 | 中 |
| P4 | 输出类型化 | 拆 dashboard-only 硬编码 + app_manifest 接入现有管线 | 中 |
| P5 | 前后端应用模板（**推迟**） | 首个交互型模板 + 容器内后端 + nginx 路由 + 离线部署流程 | 高 |
| P6 | 动态路由（可选） | "通用分析"兜底入口，运行时按意图选画像 | 低（可选） |

### P0 前置验证门（所有后续阶段的前提）

1. 容器内 `skills` 冒烟（§5.5）；失败 → 回退保守方案（shared + Boot Sequence 不动，仅做
   persona/画像分离，skills 列为 P6 可选）
2. 离线三层确认：网络层断网验证、权限层 webfetch deny 生效、bash 网络命令 glob 加固生效
3. 顺手修复 `Test-Path` 跨平台问题（tools-guide / env-offline / agent-generator）

### P1 抽共享运行时 + 能力技能化

1. 从 `templates/analysis-agent.md` 抽出通用 SOP 到 `shared/analysis-runtime.md`
2. 9 个能力模块按 §5.4 映射迁移为 `.opencode/skills/`；env-offline 拆权限/说明两层
3. 模板瘦身：front matter + 角色段 + 画像/SOP 指针，**删除 Boot Sequence 9 行**
4. 存量 agent 回归：us-carrier 场景行为等价
5. 验收：模板行数显著下降；容器内 skills 可见；存量产物走新链路过 validate_html

### P2 画像化

1. 新增 `templates/domain-profile.schema.json`
2. 生成器改造：决策逻辑从"填 20+ 占位符"改为"决策画像字段"；输出 `config/domains/<domain>.json` + 薄 persona
3. 存量迁移：us-carrier / khamenei → 薄 persona + 画像（重生成或手工迁移 + 冒烟回归）
4. 验收：产物通过 Schema 校验 + selftest 扩展（画像正例/负例）

> 对话体验改进（§4.5）为**独立低优先项**，不依赖本阶段：内容级重写生成器问题文本即可，随每次生成器维护顺带落地。数据化（config/dialog/*）仅在规模触发时考虑。

### P3 分析模式资产化

1. 新建 `lib/analysis/`，先迁 AIS 异常判定模块（含入参 schema + 单测）
2. 画像 `analysis_patterns` 改为引用模块 id；**阈值 params 化（§4.3.4 单一来源）**
3. 验收：模块可单测；同一模式被多个画像引用；selftest 覆盖

### P4 输出类型化

1. 新增 `templates/app-manifest.schema.json`
2. **拆除 dashboard-only 硬编码（§7.1 三处）**
3. 画像 `output` 扩展为 app_manifest；`app_type: dashboard` 映射到现有 spec 管线
4. 验收：现有 6 个 html 产物通过新管线回归（零行为变化）

### P5 前后端应用模板（推迟，暂不实施）

> **评审决定：推迟。** 理由：R2 智能应用是"还不存在的需求"；离线环境无法拉基础镜像，镜像未预装
> fastapi/flask；风险最高、收益最虚。仅当出现明确的前后端应用需求、且镜像已预装运行时后，
> 再启动本阶段（工程落盘 → 路由更新 → 重启，全程离线）。

1. `lib/app-templates/` 首个交互型模板（如 list-detail：列表 + 详情 + 筛选）
2. 容器内后端（python fastapi/flask 随镜像预装）+ nginx 路由
3. 离线部署流程文档：工程落盘 → 路由更新 → 重启
4. 验收：离线环境启动一个交互型应用，浏览器可访问

### P6 动态路由（可选，暂缓）

"通用分析" persona 在运行时按意图匹配 `config/domains/*.json`。仅在出现"意图模糊/不想维护入口"需求时实施。

---

## 10. 风险与权衡

| 风险 | 说明 | 缓解 |
|------|------|------|
| 重构期间生成链路中断 | P1/P2 改生成器输出形态 | P0 前置门 + 阶段化 + 每阶段 selftest 回归 + 存量先跑通再删旧 |
| skills 懒加载不可保证"必读" | 关键不变量可能被跳过 | 不变量留在 persona 直读 + 权限层 + 网络层，不交给技能 |
| fork skills 支持未验证 | 迁移可能白做 | P0 冒烟先行；失败回退保守方案（只做 persona/画像分离） |
| 阈值双源漂移 | KB 与代码各写一份阈值 | params 单一来源（§4.3.4），KB 只解释语义 |
| persona 不自包含 | 单文件可移植性下降 | 画像 diff 更清晰；已确认取舍（可审计性优先） |
| 运行时多一次 read | 冷启动开销 | 可接受；画像可缓存 |
| app 后端引入部署复杂度 | 离线受限 | 用容器内进程而非每应用建镜像 |
| 生成器"设计器"化对 LLM 要求高 | 决策更开放 | 用画像 Schema 约束输出域，降低自由度 |
| 对话质量依赖 LLM 执行力 | 问答上限 = 模型依循提问原则的程度 | 内容级改进 + 生成产物 Schema 校验 + 冒烟兜底（§4.5.4） |
| 对话自适应可预测性下降 | 轮数可变、跳问分支多，测试面广 | 内容级实现、不抽象策略；selftest 补跳问分支样例 |
| db_sources.json 明文凭据（公网 IP+密码） | 敏感资产泄露风险 | 仅内网可访问；部署时替换为内网地址；不在任何输出/报告中呈现 |

---

## 11. 附录

### 11.1 目标目录结构

```
agents_gen/
├── .opencode/
│   ├── agents/
│   │   ├── agent-generator.md          # 设计顾问（唯一 primary 设计入口）
│   │   └── <domain>.md                 # 薄 persona（前端 Tab 实体，无 Boot Sequence）
│   └── skills/<name>/SKILL.md          # ★ 可复用能力（db-* / analysis-common / dashboard-output / html-qa / viz-theme / tools-guide / env-server）
├── config/
│   ├── db_sources.json                 # 数据源注册表
│   ├── server.json                     # 内网查看地址
│   └── domains/<domain>.json           # 领域画像 + app_manifest（生成器产物）
├── shared/
│   ├── analysis-runtime.md             # ★ 运行时 SOP（persona 直读，强制保序）
│   └── env-offline.md                  # 离线规则（拆权限/说明两层后保留说明层）
├── templates/
│   ├── domain-profile.schema.json      # ★ 画像契约
│   ├── app-manifest.schema.json        # ★ 应用清单契约（P5 推迟，契约先行定义）
│   ├── dashboard-spec.schema.json      # 大屏契约（现有，保留）
│   └── analysis-agent.md               # 模板（瘦身为 persona 骨架）
├── lib/
│   ├── analysis/                       # ★ 分析模式资产（可复用、可单测、阈值 params 化）
│   ├── app-templates/                  # 应用模板（P5 推迟，占位）
│   └── dashboard/                      # 大屏引擎（现有，保留）
├── scripts/                            # build / validate / check / selftest（扩展）
└── html/                               # 产物（gitignored）
```

**治理注记（当前决定）**：生成产物（persona / 画像 / 应用工程）**暂不入库**，与现状一致
（.opencode/agents/* 与 html/ 均 gitignored）；版本化治理（入库 + 审计 + 回滚）列为后续可选项。

### 11.2 已在本轮实施（合并进现状）的事项

- 提示词严格离线化（4 源头 + 2 存量生成物）
- display_name 全量注入
- 禁用官方内置 agent（config/opencode.json，docker-compose 挂载）
- server.json 迁移 + baseUrl 改部署机 IP + 读取命令跨平台化
- 镜像预装 py3-jsonschema 并容器内全链路验证

### 11.3 术语

| 术语 | 含义 |
|------|------|
| persona | 智能体身份文件（薄，front matter + 角色 + 画像/SOP 指针） |
| 领域画像 | 垂域差异化的结构化 JSON（数据/KB/模式/路由/输出），skills 替代不了的数据资产 |
| app_manifest | 智能应用清单（app_type/pages/data/interactivity/backend/deploy），app_type 为输出裁决点 |
| 运行时 SOP | 通用执行流程，全垂域共用一份，persona 直读强制保序 |
| 决定性提问 | 四种问题类型（规则澄清/范围收窄/缺口提醒/偏好确认）——一个问题不改变生成物就不该问；内容级改进，不建机制 |
| 整链路模块化 | 从用户任务到 HTML 交付共 11 环节（M1-M11）的流程视图；仅文档级契约，不实施运行时机制 |
| 分析模式资产 | lib/analysis/ 下可复用的业务逻辑模块，阈值 params 化 |
| skill | opencode 原生可复用能力单元（SKILL.md），平台发现/懒加载/权限门控 |
| 离线三层 | 网络层（硬保证）/ 权限层（平台级）/ 提示词层（软保证） |

---

*本文档为待评审方案；评审通过后按 §9 分阶段实施，每阶段以 selftest 回归 + 存量产物回归作为验收门槛。P0 前置门未通过则回退保守方案。*
