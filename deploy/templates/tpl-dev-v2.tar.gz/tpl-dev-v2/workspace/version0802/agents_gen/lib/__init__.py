"""lib — 前端静态资产 + 可复用 Python 资产（db 网关在 scripts/，分析模式在 lib/analysis/）。"""
