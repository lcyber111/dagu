"""分析模式资产库 — 注册表

画像 `analysis_patterns[].pattern` 引用这里的 id。
每个模式模块提供：判定函数 + CLI（--input/--output JSON 文件契约）。
"""


def get(name):
    if name == 'ais-anomaly':
        from lib.analysis import ais_anomaly
        return ais_anomaly.detect_anomalies
    if name == 'ais-event-assembly':
        from lib.analysis import ais_event_assembly
        return ais_event_assembly.assemble_events
    if name == 'spatial-association':
        from lib.analysis import spatial_association
        return spatial_association.associate
    if name == 'threat-assessment':
        from lib.analysis import threat_assessment
        return threat_assessment.assess_threat
    if name == 'carrier-state':
        from lib.analysis import carrier_state
        return carrier_state.assess_carrier_state
    raise KeyError(f'未知分析模式: {name}，可用: {list_patterns()}')


def list_patterns():
    return sorted(['ais-anomaly', 'ais-event-assembly', 'carrier-state',
                   'spatial-association', 'threat-assessment'])


__all__ = ['get', 'list_patterns']
