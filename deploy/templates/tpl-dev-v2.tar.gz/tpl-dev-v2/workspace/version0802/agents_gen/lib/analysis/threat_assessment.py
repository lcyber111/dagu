"""威胁等级评估模块

规则来源: rag/carrier_assessment_kb.md 第四部分（威胁等级评估 4 级）。

用法:
  python -m lib.analysis.threat_assessment --input temp/threat.json --output temp/out.json

输入 JSON: {"distance_to_vital_km": 800, "weapon_range_km": 1500,
            "in_monitor_area": true, "radar_lock": false, "approaching": false,
            "conflict_level": "none"}   # conflict_level: none/low/medium/high
输出 JSON: {"level": "一般", "reasons": [...], "warnings": [...]}
"""
import argparse
import json

CONFLICT_LEVELS = ('none', 'low', 'medium', 'high')


def assess_threat(distance_to_vital_km, weapon_range_km, in_monitor_area,
                  radar_lock=False, approaching=False, conflict_level='none'):
    """4 级威胁评估（规则: carrier_assessment_kb.md 四，conflict_level 最高优先）。

    决策顺序:
      1. conflict_level 最高优先: high→严重 / medium→高 / low→一般（新闻类独立定级）
      2. 无冲突时按位置信号:
         - 不在监视区内 → 无实质（武器射程无法触及要害区外缘）
         - 距离 ≤ 武器射程 且 雷达稳定锁定 → 严重
         - 距离 ≤ 武器射程 → 高（已驶入要害区 VA，处于可打击范围）
         - 雷达稳定锁定（CIEA 内超射程） → 高
         - 航迹逼近/向内收缩 → 高
         - 其余 → 一般

    返回: {"level": "严重|高|一般|无实质", "reasons": [...], "warnings": [...]}
    """
    warnings = []
    if conflict_level not in CONFLICT_LEVELS:
        warnings.append(f'非法 conflict_level {conflict_level!r}，按 none 处理')
        conflict_level = 'none'

    if conflict_level == 'high':
        return {'level': '严重',
                'reasons': ['国际高烈度热点：局部战争交火、武装冲突、导弹试射、海上封锁、宣战、大规模兵力集结或核威慑'],
                'warnings': warnings}
    if conflict_level == 'medium':
        return {'level': '高',
                'reasons': ['国际中烈度热点：外交制裁、边境摩擦、大规模实弹演习或军机军舰常态化抵近对峙'],
                'warnings': warnings}
    if conflict_level == 'low':
        return {'level': '一般',
                'reasons': ['国际低烈度热点：常规外交摩擦、经济争端、小规模年度军演或无对抗区域巡航'],
                'warnings': warnings}

    try:
        dist = float(distance_to_vital_km)
        wrange = float(weapon_range_km)
    except (TypeError, ValueError):
        warnings.append('distance_to_vital_km 或 weapon_range_km 缺失/非法，按无实质处理')
        return {'level': '无实质', 'reasons': ['缺少有效的距离/武器射程参数，无法评估'], 'warnings': warnings}

    within_range = dist <= wrange
    if not in_monitor_area:
        return {'level': '无实质',
                'reasons': ['目标全程位于监视区外缘以外，武器射程无法触及要害区'],
                'warnings': warnings}
    if within_range and radar_lock:
        return {'level': '严重',
                'reasons': ['敌方雷达持续稳定锁定我方要害资产，且目标已落入要害区 VA（武器射程内）'],
                'warnings': warnings}
    if within_range:
        return {'level': '高',
                'reasons': ['目标已驶入我方要害区 VA，处于武器可打击范围内'],
                'warnings': warnings}
    if radar_lock:
        return {'level': '高',
                'reasons': ['敌方雷达稳定锁定我方资产，目标位于 CIEA 区域（监视区内、超出武器最大射程）'],
                'warnings': warnings}
    if approaching:
        return {'level': '高',
                'reasons': ['目标航迹逼近/向内收缩机动，存在突入要害区风险'],
                'warnings': warnings}
    return {'level': '一般',
            'reasons': ['目标处于监视区常规活动，无稳定锁定、未逼近要害区、武器射程无法覆盖我方核心设防资产'],
            'warnings': warnings}


def main(argv=None):
    p = argparse.ArgumentParser(description='威胁等级评估（规则: rag/carrier_assessment_kb.md 四）')
    p.add_argument('--input', required=True, help='威胁评估输入 JSON 文件')
    p.add_argument('--output', required=True, help='结果 JSON 输出路径')
    args = p.parse_args(argv)

    with open(args.input, encoding='utf-8') as f:
        data = json.load(f)
    result = assess_threat(data.get('distance_to_vital_km'), data.get('weapon_range_km'),
                           data.get('in_monitor_area', True),
                           radar_lock=bool(data.get('radar_lock', False)),
                           approaching=bool(data.get('approaching', False)),
                           conflict_level=data.get('conflict_level', 'none'))
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    print(json.dumps({'ok': True, 'level': result['level'], 'output': args.output}, ensure_ascii=False))


if __name__ == '__main__':
    main()
