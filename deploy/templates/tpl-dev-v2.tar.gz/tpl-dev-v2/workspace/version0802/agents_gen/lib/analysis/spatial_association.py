"""空间关联分析模块

规则来源: rag/carrier_aircraft_kb.md（空间关联规则 §1 + 高度分层 §3 + 数据质量校验 §4 + 误判防范 §5）。

用法:
  python -m lib.analysis.spatial_association --input temp/assoc.json --output temp/out.json \
      [--radius-km 50] [--landing-alt-ft 200] [--max-alt-ft 10000] [--max-dist-km 100]

输入 JSON: {"carriers": [{"id": "CVN-73", "name": "华盛顿号", "lat": .., "lon": ..}],
            "aircraft": [{"id": "ICAO1234", "lat": .., "lon": .., "altitude_ft": 150,
                          "aircraft_type": "F/A-18E/F"}]}
输出 JSON: {"aircraft": [{"id": .., "carrier_id": .., "distance_km": .., "altitude_ft": ..,
                          "altitude_layer": "<200ft", "is_carrier_aircraft": true, "aircraft_type": ..}],
            "layers": {carrier_id: {"<200ft": n, "200-1000ft": n, ">1000ft": n, "地面": n}},
            "types": {carrier_id: {aircraft_type: n}},
            "warnings": [...]}
"""
import argparse
import json
import math

R_EARTH_KM = 6371.0
CARRIER_AIRCRAFT_TYPES = ('F/A-18', 'F-35C', 'EA-18G', 'E-2D', 'MH-60', 'CMV-22B')
LAYER_KEYS = ('<200ft', '200-1000ft', '>1000ft', '地面')


def haversine_km(lat1, lon1, lat2, lon2):
    """Haversine 球面距离（km），R=6371。规则源 carrier_aircraft_kb.md §1.2。"""
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R_EARTH_KM * c


def _alt_layer(alt):
    """高度分层：<200ft 起降 / 200-1000ft 中空 / >1000ft 高空；0 或空 → 地面。"""
    if alt is None or alt == 0:
        return '地面'
    if alt < 200:
        return '<200ft'
    if alt <= 1000:
        return '200-1000ft'
    return '>1000ft'


def _is_carrier_type(aircraft_type, carrier_types):
    """机型匹配（前缀匹配，兼容 F/A-18E/F 等细分型号）。"""
    if not aircraft_type:
        return False
    t = str(aircraft_type).upper()
    return any(t.startswith(str(c).upper()) for c in carrier_types)


def associate(carriers, aircraft, radius_km=50.0, landing_alt_ft=200.0,
              max_alt_ft=10000.0, max_dist_km=100.0,
              carrier_types=CARRIER_AIRCRAFT_TYPES):
    """航母-飞机空间关联与高度分层统计。

    规则（carrier_aircraft_kb.md）:
      - 数据质量: 经纬度越界/非数字丢弃；高度 0 或空标记"地面"，不参与关联
      - 误判防范: 高度 > max_alt_ft 排除（高空过路）；距航母 > max_dist_km 排除（超出作战空域硬阈值）
      - 高度分层: <200ft 起降 / 200-1000ft 中空 / >1000ft 高空
      - 舰载机归属: 距航母 < radius_km 且 高度 < landing_alt_ft 且 机型匹配 → 归属最近航母
      - 重叠区归属: 两航母 50km 重叠区内的飞机归属距离最近的航母
    输出 layers/types 按 radius_km 内的飞机统计（用于舰载机活动强度/机型分布）。

    返回: {"aircraft": [...], "layers": {...}, "types": {...}, "warnings": [...]}
    """
    warnings = []
    valid_carriers = []
    for c in carriers:
        cid = c.get('id', '?')
        try:
            lat, lon = float(c['lat']), float(c['lon'])
        except (KeyError, TypeError, ValueError):
            warnings.append(f'航母 {cid} 经纬度缺失或非数字，已跳过')
            continue
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            warnings.append(f'航母 {cid} 经纬度超范围，已跳过')
            continue
        valid_carriers.append({**c, 'lat': lat, 'lon': lon})

    layers = {c['id']: {k: 0 for k in LAYER_KEYS} for c in valid_carriers}
    types = {c['id']: {} for c in valid_carriers}
    rows = []

    for a in aircraft:
        aid = a.get('id', '?')
        try:
            lat, lon = float(a['lat']), float(a['lon'])
        except (KeyError, TypeError, ValueError):
            warnings.append(f'飞机 {aid} 经纬度缺失或非数字，已跳过')
            continue
        alt = a.get('altitude_ft')
        if alt is not None:
            try:
                alt = float(alt)
            except (TypeError, ValueError):
                warnings.append(f'飞机 {aid} 高度非数字，已跳过')
                continue
            if not (0 <= alt <= 60000):
                warnings.append(f'飞机 {aid} 高度 {alt}ft 超范围，已跳过')
                continue
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            warnings.append(f'飞机 {aid} 经纬度超范围，已跳过')
            continue

        dists = [(c['id'], haversine_km(lat, lon, c['lat'], c['lon'])) for c in valid_carriers]
        nearest = min(dists, key=lambda x: x[1]) if dists else (None, None)

        row = {
            'id': aid,
            'carrier_id': nearest[0],
            'distance_km': round(nearest[1], 2) if nearest[1] is not None else None,
            'altitude_ft': alt,
            'altitude_layer': _alt_layer(alt),
            'is_carrier_aircraft': False,
            'aircraft_type': a.get('aircraft_type'),
        }
        if not valid_carriers:
            warnings.append(f'飞机 {aid} 无有效航母可关联')
            rows.append(row)
            continue
        if alt is not None and alt > max_alt_ft:
            warnings.append(f'飞机 {aid} 高度 {alt}ft > {max_alt_ft}ft，高空过路航班排除')
            rows.append(row)
            continue
        if nearest[1] > max_dist_km:
            warnings.append(f'飞机 {aid} 距最近航母 {row["distance_km"]}km > {max_dist_km}km，超出作战空域排除')
            rows.append(row)
            continue
        within = [(cid, d) for cid, d in dists if d < radius_km]
        if not within:
            rows.append(row)
            continue
        owner, _ = min(within, key=lambda x: x[1])
        row['carrier_id'] = owner
        rows.append(row)
        layers[owner][row['altitude_layer']] += 1
        t = a.get('aircraft_type') or '未知'
        types[owner][t] = types[owner].get(t, 0) + 1
        if (alt and alt < landing_alt_ft
                and _is_carrier_type(a.get('aircraft_type'), carrier_types)):
            row['is_carrier_aircraft'] = True

    rows.sort(key=lambda r: ((r['carrier_id'] or ''), (r['id'] or '')))
    return {'aircraft': rows, 'layers': layers, 'types': types, 'warnings': warnings}


def main(argv=None):
    p = argparse.ArgumentParser(description='空间关联分析（规则: rag/carrier_aircraft_kb.md）')
    p.add_argument('--input', required=True, help='航母+飞机 JSON 文件')
    p.add_argument('--output', required=True, help='结果 JSON 输出路径')
    p.add_argument('--radius-km', type=float, default=50.0, help='作业空域半径（km），默认 50')
    p.add_argument('--landing-alt-ft', type=float, default=200.0, help='起降阶段高度阈值（ft），默认 200')
    p.add_argument('--max-alt-ft', type=float, default=10000.0, help='误判防范：高度上限（ft），默认 10000')
    p.add_argument('--max-dist-km', type=float, default=100.0, help='误判防范：距离硬阈值（km），默认 100')
    args = p.parse_args(argv)

    with open(args.input, encoding='utf-8') as f:
        data = json.load(f)
    result = associate(data.get('carriers', []), data.get('aircraft', []),
                       radius_km=args.radius_km, landing_alt_ft=args.landing_alt_ft,
                       max_alt_ft=args.max_alt_ft, max_dist_km=args.max_dist_km)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    n_ca = sum(1 for r in result['aircraft'] if r['is_carrier_aircraft'])
    print(json.dumps({'ok': True, 'aircraft_count': len(result['aircraft']),
                      'carrier_aircraft_count': n_ca, 'output': args.output}, ensure_ascii=False))


if __name__ == '__main__':
    main()
