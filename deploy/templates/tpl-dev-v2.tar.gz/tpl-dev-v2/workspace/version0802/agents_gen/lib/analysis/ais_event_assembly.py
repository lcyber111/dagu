"""ais_event_assembly.py — 锚点→事件序列装配（AIS OFF/ON 事件推导）

把"锚点 + 边界记录 + 零记录"装配为事件序列（供 `ais_anomaly` 判定）。纯逻辑，不碰数据库。

用法:
  python -m lib.analysis.ais_event_assembly --input in.json --output out.json

输入 JSON:
{
  "window": {"start": "2026-02-10 00:00:00", "end": "2026-08-10 23:59:59"},
  "threshold_hours": 24,
  "anchors": [{"hull_no","event_time","event_type","lat","lon"}],  // SQL 锚点抽取（LEAD/LAG 间隔≥阈值）
  "firsts": {"hull_no": {"event_time","lat","lon"}},              // 窗口内首条记录
  "lasts":  {"hull_no": {"event_time","lat","lon"}},              // 窗口内末条记录
  "pres":   {"hull_no": {"event_time","lat","lon"}},              // 窗口前最后一条（状态基点）
  "zero_record": [{"hull_no","status":"at_sea|in_port|refit","last_known":{"event_time","lat","lon"}}],
  "trailing_exempt": ["CVN-78"]                                    // 末尾静默豁免（维修/在建等）
}

输出 JSON: {"events": [{"hull_no","event_time","event_type","lat","lon"}], "warnings": [...]}

装配规则（KB §一.5 / 真实作业实证）:
  - 源过滤由锚点 SQL 承担（快照型源排除、NULL source 保留）；本模块只管装配
  - 边界：首条<窗口起点→Initial AIS ON；否则 pre 状态→AIS OFF（基点）+ 首条→AIS ON
  - 尾条距窗口末端≥阈值且未豁免→AIS OFF（持续静默）
  - 零记录：status=at_sea 合成 1 次持续静默 AIS OFF；in_port/refit 不合成（防误报）
  - 同刻冲突：同时间戳多事件按"分组前最后保留事件"交替取一种；末次记录保留 OFF
  - 连续同类型去重（OFF/ON 交替不变式）；(hull,time) 去重（防重复处理）
"""
import argparse
import json
from datetime import datetime


def _parse(t):
    if isinstance(t, datetime):
        return t
    return datetime.fromisoformat(str(t).replace('Z', '+00:00'))


def assemble_events(data):
    window = data['window']
    threshold_h = float(data.get('threshold_hours', 24))
    w_start = _parse(window['start'])
    w_end = _parse(window['end'])
    exempt = set(data.get('trailing_exempt', []) or [])
    warnings = []

    raw = [dict(a) for a in data.get('anchors', []) or []]

    firsts = data.get('firsts', {}) or {}
    lasts = data.get('lasts', {}) or {}
    pres = data.get('pres', {}) or {}

    for hull, f in firsts.items():
        if _parse(f['event_time']) < w_start:
            raw.append({'hull_no': hull, 'event_time': f['event_time'],
                        'event_type': 'Initial AIS ON', 'lat': f['lat'], 'lon': f['lon']})
        elif hull in pres:
            p = pres[hull]
            raw.append({'hull_no': hull, 'event_time': p['event_time'],
                        'event_type': 'AIS OFF', 'lat': p['lat'], 'lon': p['lon']})
            raw.append({'hull_no': hull, 'event_time': f['event_time'],
                        'event_type': 'AIS ON', 'lat': f['lat'], 'lon': f['lon']})
        else:
            raw.append({'hull_no': hull, 'event_time': f['event_time'],
                        'event_type': 'Initial AIS ON', 'lat': f['lat'], 'lon': f['lon']})

    for hull, l in lasts.items():
        t = _parse(l['event_time'])
        if t < w_start or hull in exempt:
            continue
        if (w_end - t).total_seconds() / 3600 >= threshold_h:
            raw.append({'hull_no': hull, 'event_time': l['event_time'],
                        'event_type': 'AIS OFF', 'lat': l['lat'], 'lon': l['lon']})

    for zr in data.get('zero_record', []) or []:
        if zr.get('status') != 'at_sea':
            continue
        lk = zr.get('last_known', {}) or {}
        raw.append({'hull_no': zr['hull_no'], 'event_time': window['start'],
                    'event_type': 'AIS OFF', 'lat': lk.get('lat'), 'lon': lk.get('lon')})
        warnings.append(f"{zr['hull_no']}: 窗口内无记录(出海静默) → 合成持续静默 AIS OFF @{window['start']}")

    # 每舰装配：排序 → 同刻冲突消解 → 连续同类型去重 → (hull,time) 去重
    by_hull = {}
    for e in raw:
        by_hull.setdefault(e['hull_no'], []).append(e)

    final = []
    for hull in sorted(by_hull):
        seq = sorted(by_hull[hull], key=lambda x: (_parse(x['event_time']), x['event_type']))
        last_time = _parse(lasts[hull]['event_time']) if hull in lasts else None
        kept = []
        i = 0
        while i < len(seq):
            t = _parse(seq[i]['event_time'])
            j = i
            while j < len(seq) and _parse(seq[j]['event_time']) == t:
                j += 1
            grp = seq[i:j]
            if len(grp) > 1:
                base = kept[-1]['event_type'] if kept else None
                if last_time is not None and t == last_time:
                    chosen = 'AIS OFF'
                elif base == 'AIS OFF':
                    chosen = 'AIS ON'
                elif base == 'AIS ON':
                    chosen = 'AIS OFF'
                else:
                    chosen = 'AIS OFF'
                pick = next(e for e in grp if e['event_type'] == chosen)
                warnings.append(f'{hull}: 同刻冲突 @{t.isoformat()} 保留 {chosen}')
                kept.append(pick)
            else:
                e = grp[0]
                if kept and kept[-1]['event_type'] == e['event_type'] and e['event_type'] != 'Initial AIS ON':
                    warnings.append(f'{hull}: 连续同类型 {e["event_type"]} @{t.isoformat()} 去重')
                else:
                    kept.append(e)
            i = j
        final.extend(kept)

    # (hull,time) 去重 + 全局排序
    seen = set()
    dedup = []
    for e in sorted(final, key=lambda x: (_parse(x['event_time']), x['hull_no'])):
        key = (e['hull_no'], _parse(e['event_time']))
        if key in seen:
            continue
        seen.add(key)
        dedup.append(e)

    return {'events': dedup, 'warnings': warnings}


def main(argv=None):
    p = argparse.ArgumentParser(description='AIS 事件装配（锚点→事件序列）')
    p.add_argument('--input', required=True, help='装配输入 JSON')
    p.add_argument('--output', required=True, help='输出 events JSON 路径')
    args = p.parse_args(argv)

    with open(args.input, encoding='utf-8') as f:
        data = json.load(f)
    result = assemble_events(data)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    print(json.dumps({'ok': True, 'event_count': len(result['events']),
                      'warnings': len(result['warnings']), 'output': args.output},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
