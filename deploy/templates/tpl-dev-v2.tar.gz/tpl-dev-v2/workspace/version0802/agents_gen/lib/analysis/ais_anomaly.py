"""AIS 异常判定模块

规则来源: rag/carrier_ais_kb.md（异常事件判定 + 误判防范 + 异常等级评估）。

用法:
  python -m lib.analysis.ais_anomaly --input temp/events.json --output temp/anomalies.json \
      [--off-window-months 6] [--min-interval-hours 1.0]

输入 JSON: [{"hull_no": "CVN-73", "event_time": "2026-01-01T08:00:00", "event_type": "AIS OFF", "lat": .., "lon": ..}, ...]
输出 JSON: {"anomalies": [...], "levels": {"CVN-73": "关注"}, "warnings": [...]}
"""
import argparse
import json
from datetime import datetime, timedelta

EVENT_TYPES = {'Initial AIS ON', 'AIS OFF', 'AIS ON'}
_LEVEL_BY_COUNT = [(0, '正常'), (2, '关注'), (4, '警示'), (1 << 30, '严重')]


def _parse_time(value):
    if isinstance(value, datetime):
        return value
    return datetime.fromisoformat(str(value))


def dedupe(events):
    """同一目标同一时刻的多条记录去重（保留首条）。返回按 (hull_no, time) 排序的事件列表。"""
    seen = set()
    out = []
    for e in sorted(events, key=lambda x: (x['hull_no'], _parse_time(x['event_time']))):
        key = (e['hull_no'], _parse_time(e['event_time']))
        if key in seen:
            continue
        seen.add(key)
        out.append(e)
    return out


def _level(count):
    for upper, name in _LEVEL_BY_COUNT:
        if count <= upper:
            return name
    return '严重'


def detect_anomalies(events, off_window_months=6, min_interval_hours=1.0):
    """对按目标分组的 AIS 状态事件序列做异常检测。

    规则:
      - Initial AIS ON 为数据起点，不计异常
      - AIS OFF / AIS ON 状态切换计为异常（OFF=隐蔽, ON=恢复）
      - 相邻切换间隔 < min_interval_hours 小时 → 标记 suspected_fault（疑似设备故障）
      - 异常等级按最近 off_window_months 月内异常次数: 0→正常 1-2→关注 3-4→警示 >=5→严重
      - **等级窗口为固定绝对窗口**：window_end = 全部数据最晚事件时间（跨舰一致），
        window_start = window_end - off_window_months*30 天；统计 [start, end] 内异常次数。
        原逻辑以"该舰最近异常时间"回推窗口，末次异常久远时会漏数（跨舰窗口不一致），已修复。

    返回: {"anomalies": [...], "levels": {hull: 等级}, "warnings": [...]}
    """
    events = dedupe(events)
    by_hull = {}
    for e in events:
        by_hull.setdefault(e['hull_no'], []).append(e)

    all_times = [_parse_time(e['event_time']) for e in events]
    data_end = max(all_times) if all_times else None
    window_start = data_end - timedelta(days=off_window_months * 30) if data_end is not None else None

    anomalies = []
    warnings = []
    levels = {}

    for hull, seq in by_hull.items():
        seq = sorted(seq, key=lambda x: _parse_time(x['event_time']))
        prev = None
        hull_anomalies = []
        for e in seq:
            t = _parse_time(e['event_time'])
            et = e['event_type']
            if et not in EVENT_TYPES:
                warnings.append(f'{hull}: 未知事件类型 {et!r}，已忽略')
                continue
            if prev is None:
                prev = (t, et)
                continue
            prev_t, prev_et = prev
            if et != prev_et:
                anomaly = dict(e)
                anomaly['interval_hours'] = round((t - prev_t).total_seconds() / 3600.0, 2)
                anomaly['suspected_fault'] = anomaly['interval_hours'] < min_interval_hours
                if anomaly['suspected_fault']:
                    warnings.append(
                        f'{hull}: {e["event_time"]} 状态切换间隔 {anomaly["interval_hours"]}h '
                        f'< {min_interval_hours}h，疑似设备故障')
                anomaly['kind'] = 'off' if et == 'AIS OFF' else 'on'
                hull_anomalies.append(anomaly)
            prev = (t, et)
        if window_start is not None:
            recent = [a for a in hull_anomalies if _parse_time(a['event_time']) >= window_start]
        else:
            recent = []
        levels[hull] = _level(len(recent))
        anomalies.extend(hull_anomalies)

    anomalies.sort(key=lambda a: (_parse_time(a['event_time'])))
    return {'anomalies': anomalies, 'levels': levels, 'warnings': warnings}


def main(argv=None):
    p = argparse.ArgumentParser(description='AIS 异常判定（规则: rag/carrier_ais_kb.md）')
    p.add_argument('--input', required=True, help='事件 JSON 数组文件')
    p.add_argument('--output', required=True, help='结果 JSON 输出路径')
    p.add_argument('--off-window-months', type=int, default=6,
                   help='异常等级统计窗口（月），默认 6')
    p.add_argument('--min-interval-hours', type=float, default=1.0,
                   help='误判防范：切换间隔下限（小时），默认 1.0')
    args = p.parse_args(argv)

    with open(args.input, encoding='utf-8') as f:
        events = json.load(f)
    result = detect_anomalies(events, off_window_months=args.off_window_months,
                              min_interval_hours=args.min_interval_hours)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    print(json.dumps({'ok': True, 'anomaly_count': len(result['anomalies']),
                      'output': args.output}, ensure_ascii=False))


if __name__ == '__main__':
    main()
