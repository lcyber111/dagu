"""carrier_state.py — 航母状态判定模块（量化信号 + 优先级）

规则来源: rag/carrier_assessment_kb.md §一（航母状态判定规则，7 类）。
定位: 只判定**可量化信号**部分（靠泊/航速/驻留/执勤时长/起降架次/护航间距/补给对舰/官方公告 flags）；
定性判断（舆情/意图/演习细节）由 agent 提供为 news_flags 或保持提示词判断。

用法:
  python -m lib.analysis.carrier_state --input in.json --output out.json

输入 JSON:
{
  "hull_no": "CVN-73",
  "berthed": false, "speed_kts": 12.0, "stationary_hours": 0.0, "duty_days": 20,
  "sorties_per_day": 150, "sortie_streak_days": 3, "e2d_sorties_per_day": 0,
  "replenisher_distance_m": null, "replenisher_duration_min": null, "replenisher_sync": false,
  "escort_spacing_nm": null, "escort_count": null,
  "news_flags": {"official_combat": false, "official_exercise": false,
                 "official_repair": false, "social_rest": false}
}

输出 JSON: {"state", "confidence", "rules_matched", "evidence", "uncertainties"}

判定优先级（官方公告 > 强量化信号 > 弱量化信号 > 时长/靠泊）:
  1. official_combat / official_exercise / official_repair（官方声明最高优先）
  2. 补给（补给舰距≤200m + 持续>90min + 双舰同步）
  3. 作战（起降≥120架次/日 × 连续≥3日）
  4. 警戒（护航间距 10-20 海里 / E-2D 升空≥2架次·日）
  5. 维修（海上执勤 > 25 天）
  6. 休整（靠泊 + 航速<3节 + 位置驻留≥24h）
  7. 训练（起降 50-80 架次·日，中强度）
  8. 默认 → 常态/未知

阈值编码自 KB §一，KB 管语义解释。
"""
import argparse
import json


def _f(x):
    return float(x) if x is not None else None


def assess_carrier_state(data):
    news = data.get('news_flags') or {}
    evidence = []
    uncertainties = []

    def flag(name):
        return bool(news.get(name))

    # 1. 官方公告（最高优先）
    if flag('official_combat'):
        return {'state': '作战', 'confidence': 0.9, 'rules_matched': ['official_combat'],
                'evidence': '官方声明执行作战/威慑/打击任务', 'uncertainties': []}
    if flag('official_exercise'):
        return {'state': '演习', 'confidence': 0.9, 'rules_matched': ['official_exercise'],
                'evidence': '官方演习公告确认参演', 'uncertainties': []}
    if flag('official_repair'):
        return {'state': '维修', 'confidence': 0.9, 'rules_matched': ['official_repair'],
                'evidence': '官方维修计划/进厂通报', 'uncertainties': []}

    # 2. 补给（强量化：补给舰距离+时长+双舰同步）
    dist = _f(data.get('replenisher_distance_m'))
    dur = _f(data.get('replenisher_duration_min'))
    sync = bool(data.get('replenisher_sync'))
    if dist is not None and dist <= 200 and dur is not None and dur > 90 and sync:
        return {'state': '补给', 'confidence': 0.85, 'rules_matched': ['replenishment_all'],
                'evidence': f'与补给舰距离{int(dist)}m、持续{int(dur)}min、双舰同步', 'uncertainties': []}
    if dist is not None and dist <= 200 and dur is not None and dur > 90:
        return {'state': '补给', 'confidence': 0.6, 'rules_matched': ['replenishment_dist_dur'],
                'evidence': f'与补给舰距离{int(dist)}m、持续{int(dur)}min（同步信息缺失）',
                'uncertainties': ['双舰同步信号缺失']}

    # 3. 作战（起降强度）
    sorties = _f(data.get('sorties_per_day'))
    streak = _f(data.get('sortie_streak_days'))
    if sorties is not None and sorties >= 120 and streak is not None and streak >= 3:
        return {'state': '作战', 'confidence': 0.8, 'rules_matched': ['combat_sorties_streak'],
                'evidence': f'起降{int(sorties)}架次/日 × 连续{int(streak)}日', 'uncertainties': []}
    if sorties is not None and sorties >= 120:
        return {'state': '作战', 'confidence': 0.5, 'rules_matched': ['combat_sorties_single'],
                'evidence': f'单日起降{int(sorties)}架次（连续天数不足3日）',
                'uncertainties': ['连续作战强度未确认']}

    # 4. 警戒（护航间距 / E-2D 升空）
    spacing = _f(data.get('escort_spacing_nm'))
    e2d = _f(data.get('e2d_sorties_per_day'))
    if (spacing is not None and 10 <= spacing <= 20) and (e2d is not None and e2d >= 2):
        return {'state': '警戒', 'confidence': 0.75, 'rules_matched': ['alert_spacing_e2d'],
                'evidence': f'护航间距{spacing}海里 + E-2D升空{e2d}架次/日', 'uncertainties': []}
    if (spacing is not None and 10 <= spacing <= 20) or (e2d is not None and e2d >= 2):
        return {'state': '警戒', 'confidence': 0.5, 'rules_matched': ['alert_partial'],
                'evidence': f'护航间距{spacing}海里 / E-2D升空{e2d}架次/日（单信号）',
                'uncertainties': ['防空警戒信号未完全确认']}

    # 5. 维修（执勤时长）
    duty = _f(data.get('duty_days'))
    if duty is not None and duty > 25:
        return {'state': '维修', 'confidence': 0.7, 'rules_matched': ['duty_exceeded'],
                'evidence': f'海上执勤{duty}天 > 25 天阈值', 'uncertainties': []}

    # 6. 休整（靠泊 + 低速 + 驻留）
    berthed = bool(data.get('berthed'))
    speed = _f(data.get('speed_kts'))
    stat = _f(data.get('stationary_hours'))
    if berthed and speed is not None and speed < 3 and stat is not None and stat >= 24:
        return {'state': '休整', 'confidence': 0.8, 'rules_matched': ['berthed_stationary'],
                'evidence': f'靠泊 + 航速{speed}节 + 位置驻留{stat}h', 'uncertainties': []}
    if flag('social_rest'):
        return {'state': '休整', 'confidence': 0.5, 'rules_matched': ['social_rest'],
                'evidence': '舰员社区服务/岸上休整动态', 'uncertainties': ['靠泊/驻留信号缺失']}

    # 7. 训练（中强度起降）
    if sorties is not None and 50 <= sorties < 120:
        return {'state': '训练', 'confidence': 0.5, 'rules_matched': ['training_sorties'],
                'evidence': f'起降{int(sorties)}架次/日（中强度）', 'uncertainties': ['训练窗口/课目未确认']}

    # 8. 默认
    return {'state': '常态/未知', 'confidence': 0.0, 'rules_matched': [],
            'evidence': '无显著量化信号或官方声明', 'uncertainties': ['输入信号不足以判定状态']}


def main(argv=None):
    p = argparse.ArgumentParser(description='航母状态判定（量化信号 + 优先级）')
    p.add_argument('--input', required=True, help='输入 JSON')
    p.add_argument('--output', required=True, help='输出 JSON 路径')
    args = p.parse_args(argv)
    with open(args.input, encoding='utf-8') as f:
        data = json.load(f)
    result = assess_carrier_state(data)
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, default=str)
    print(json.dumps({'ok': True, 'state': result['state'],
                      'confidence': result['confidence'], 'output': args.output},
                     ensure_ascii=False))


if __name__ == '__main__':
    main()
