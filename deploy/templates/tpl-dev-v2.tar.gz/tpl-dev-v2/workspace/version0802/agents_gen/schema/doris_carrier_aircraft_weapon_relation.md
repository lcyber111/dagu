# 航母武器关系表 判读规则与探查档案

## 业务判读规则
- 航母搭载武器系统关系

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 9 行

### 时间范围
- 未识别到有效时间列（列: uuid, carrier_id, carrier_name, carrier_hull_number, carrier_ship_class, carrier_status, carrier_home_port, carrier_country…）

### 数据源语义
- 探查分布：（`source`）：yuanting_weapon_naval_equipment,yuanting_weapon_military_aircraft,yuanting_mount_carry_relation,yuanting_weapon_missile=8, yuanting_weapon_naval_equipment,yuanting_weapon_military_aircraft,yuanting_mount_carry_relation,yuanting_weapon_explosive_ammunition=1


### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid

### 取数策略
- 小表（9 行）全量；源 yuanting 多类武器组合

### 已知坑
- 暂无已知坑

