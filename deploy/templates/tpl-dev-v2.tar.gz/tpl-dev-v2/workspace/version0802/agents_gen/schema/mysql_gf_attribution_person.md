# 目标人物属性 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | attribution_person |
| 数据库 | gf (MySQL) |
| 分类 | 人物情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| name | varchar(255) | 姓名(原文) |
| name_ch | varchar(255) | 中文名 |
| name_en | varchar(255) | 英文名 |
| birthday | varchar(255) | 出生日期 |
| sex | varchar(255) | 性别 |
| institution | varchar(255) | 所属机构 |
| position | varchar(255) | 职务/头衔 |
| ethnicity | varchar(255) | 民族 |
| religion | varchar(255) | 宗教信仰 |
| hobbies | varchar(255) | 兴趣爱好 |
| education | varchar(255) | 教育背景 |
| marital | varchar(255) | 婚姻状况 |
| birthplace | varchar(255) | 出生地 |
| deathday | varchar(255) | 死亡日期 |
| identity | varchar(255) | 身份标识/分类 |
| political | varchar(255) | 政治派别 |
| ideology | varchar(255) | 意识形态 |
| picture | varchar(255) | 照片路径 |

## 业务判读规则

### 身份分类
- identity 区分: 最高领袖/政府高官/IRGC高层/宗教领袖/关联人物
- 通过 institution + position 可判断目标在权力体系中的位置

### 关联分析
- name/name_en 可作为核心关键词关联其他表(person/communication/email等)
- institution 可关联 institution 表获取所属机构详情
- identity + political + ideology 可研判目标政治倾向和忠诚度

### 时间线分析
- birthday + deathday 可构建人物生命周期
- 活跃时间段可通过关联通信/信令/邮件数据推断
