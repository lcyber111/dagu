# 目标人物属性 判读规则

## 业务判读规则

### 身份分类
- identity 区分: 最高领袖/政府高官/IRGC高层/宗教领袖/关联人物
- 通过 institution + position 可判断目标在权力体系中的位置

### 关联分析
- name/name_en 可作为核心关键词关联其他表(person/communication/email等)
- institution 可关联 institution 表获取所属机构详情
- identity + political + ideology 可研判目标政治倾向和忠诚度

### 时间线分析
- birthday + deathday 可构建人物生命周期
- 活跃时间段可通过关联通信/信令/邮件数据推断
