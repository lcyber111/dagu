# 通信截获记录 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | communication |
| 数据库 | gf (MySQL) |
| 分类 | 通信情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| time_capture | varchar(40) | 数据捕获时间 |
| from_number | varchar(255) | 主叫号码/发送方 |
| to_number | varchar(255) | 被叫号码/接收方 |
| longitude | varchar(255) | 通信发生地经度 |
| latitude | varchar(255) | 通信发生地纬度 |
| begin_time | varchar(255) | 通信开始时间 |
| end_time | varchar(255) | 通信结束时间 |
| duration | varchar(255) | 通信时长 |
| msisdn | varchar(255) | 用户MSISDN号码 |
| call_indicator | varchar(255) | 通话指示标志 |
| is_encrypt | varchar(255) | 是否加密 |
| file_path | text | 录音/消息文件路径 |
| content | text | 通信内容/消息原文 |

## 业务判读规则

### 通信类型分类
- call_indicator 区分: 语音呼叫/短信/即时消息
- is_encrypt 标记加密通信,加密消息需解密分析

### 时空分析
- time_capture + begin_time/end_time 可构建目标通信时间线
- longitude/latitude 可定位通信发生地,结合 key_area 判断是否在敏感区域

### 关联分析
- from_number/to_number 可关联 contact 表构建通联关系网
- msisdn 可关联 signaling 表获取信令位置轨迹
