# 通信截获记录 判读规则

## 业务判读规则

### 通信类型分类
- call_indicator 区分: 语音呼叫/短信/即时消息
- is_encrypt 标记加密通信,加密消息需解密分析

### 时空分析
- time_capture + begin_time/end_time 可构建目标通信时间线
- longitude/latitude 可定位通信发生地,结合 key_area 判断是否在敏感区域

### 关联分析
- from_number/to_number 可关联 contact 表构建通联关系网
- msisdn 可关联 signaling 表获取信令位置轨迹
