# 航母属性表 判读规则与探查档案

## 业务判读规则
- 航母状态判读：现役/退役/在建（service_status）
- 母港分析：homeport 关联 carrier_homeport_info 判断部署阶段
- 技术指标对比：排水量/航速/舰载机搭载量同级对比

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 11 行

### 时间范围
- `service_time` [1972-05-13 ~ 2013-10-11]

### 数据源语义
- 探查分布：（`provider`）：yuanting,jingan,changguang=11
- provider 多源融合（yuanting,jingan,changguang）

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, mmsi, hull_number, name, en_name
- hull_number/mmsi/name/en_name（列名是 name 非 ship_name）

### 取数策略
- 小表（11 行）全量

### 已知坑
- CVN-79 肯尼迪（在建）未入本表，但 AIS 有真实信号——目标全集须 AIS 实际出现 ∪ 本表

