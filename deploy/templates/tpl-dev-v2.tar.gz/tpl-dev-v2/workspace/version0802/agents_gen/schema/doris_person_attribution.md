# 人员属性数据 判读规则与探查档案

## 业务判读规则
- 军事人员基本属性：军衔/职务/机构
- 经 person_carrier_relation 关联航母

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 126 行

### 时间范围
- `birth_date` [ ~ 1968]

### 数据源语义
- 探查分布：（`source`）：yuanting_military_personnel,yuanting_military_personnel_education_history,yuanting_military_personnel_work_history,yuanting_military_personnel_combat_experience,yuanting_military_personnel_exercise_experience=87, jingan_dwd_aircraft_carrier_commander_attribute,jingan_dwd_aircraft_carrier_commander_career_attribute=24, None=15
- yuanting 多源 / jingan / None（少量）

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, name, en_name

### 取数策略
- 小表（126 行）全量；时间列 birth_date 可参考

### 已知坑
- 暂无已知坑

