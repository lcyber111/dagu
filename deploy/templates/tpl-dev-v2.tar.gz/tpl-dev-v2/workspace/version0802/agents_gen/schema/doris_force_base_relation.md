# 部队基地驻扎关系表 判读规则与探查档案

## 业务判读规则
- 部队-基地驻扎关系
- 关联 force_attribution / base_attribution

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 70 行

### 时间范围
- 未识别到有效时间列（列: uuid, force_id, force_name, base_id, base_name, base_type, country_region, address…）

### 数据源语义
- 探查分布：（`source`）：yuanting_force_attribution,yuanting_base_attribution=70
- yuanting_force_attribution,yuanting_base_attribution 组合

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid

### 取数策略
- 小表（70 行）全量；无时间列

### 已知坑
- 暂无已知坑

