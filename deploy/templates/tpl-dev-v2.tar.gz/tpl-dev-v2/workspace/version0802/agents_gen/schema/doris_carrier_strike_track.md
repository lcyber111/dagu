# 航母编队组成 判读规则与探查档案

## 业务判读规则
- 编队组成为动态数据：同一航母不同时间编队可能不同（护航舰艇/补给舰）
- 编队规模判断：按护航舰艇数量与构成评估

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 8 行

### 时间范围
- 未识别到有效时间列（列: uuid, carrier_id, carrier_name, equipment_id, equipment_name, equipment_category, lng, lat…）

### 数据源语义
- 探查分布：（`source`）：None=5, rg=3


### 坐标范围
- 坐标列全为 NULL（无有效坐标）

### 关键字段事实
- 关联键：uuid

### 取数策略
- 小表（8 行）全量

### 已知坑
- acquire_time 与经纬度列当前多为空，编队信息以描述性字段为准

