# 航母编队组成 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | carrier_strike_track || 数据量 | 58 条| 分类 | 航母核心 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | varchar(200) | 唯一标识 | 是 || carrier_id | text | 航母编号 |  || carrier_name | text | 航母名 |  || equipment_id | text | 装备编号 |  || equipment_name | text | 装备名称 |  || equipment_category | varchar(64) | 装备类别 |  || lng | text | 经度 |  || lat | text | 纬度 |  || acquire_time | text | 接收时间 |  || commissioning_date | text | 开始服役时间 |  || decommissioning_date | text | 结束服役时间 |  || source | text | 来源 |  || provider | text | 供应商 |  || insert_time | datetimev2(0) | 插入时间 |  || confidence | text | 置信度 |  |## 业务判读规则
### 编队组成为动态数据
- 同一航母在不同时间编队组成可能不同- 含护航舰艇、补给舰等### 编队规模判断
- 编队内装备数量反映任务规模和威胁等级