# 手机信令数据 判读规则

## 业务判读规则

### 事件类型分类
- event_type 区分: 位置更新(LAU)/周期性更新(PER)/呼叫始发/呼叫终止/关机/开机

### 轨迹还原
- 按 msisdn + event_time 排序可还原目标连续移动轨迹
- 基站切换序列可判断移动路线和速度

### 三角定位
- 结合 base_station 表和多个基站信号到达时间可进行三角定位
- longitude/latitude 为信令事件关联的基站或估算位置

### 关联分析
- msisdn 可关联 communication 表获取目标通信内容
- base_station 可关联 base_station 表获取基站详细部署信息
