# 海战平台装备挂载关系表 判读规则与探查档案

## 业务判读规则
- 海战平台-装备挂载关系
- 关联 naval_ships_attribution / equipment_attribution

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 450 行

### 时间范围
- `platform_commissioning_date` [1975-05-03 ~ 2024-11-09]

### 数据源语义
- 探查分布：（`source`）：yuanting_weapon_naval_equipment,yuanting_mount_carry_relation=450
- yuanting_weapon_naval_equipment,yuanting_mount_carry_relation 组合

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid

### 取数策略
- 小表（450 行）全量

### 已知坑
- 暂无已知坑

