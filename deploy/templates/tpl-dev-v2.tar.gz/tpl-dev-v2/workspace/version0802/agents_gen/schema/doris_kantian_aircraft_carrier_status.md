# 瞰天航母状态表 判读规则与探查档案

## 业务判读规则
- 状态判读：status 含 在港/出海/部署/维护/船坞
- 多源融合：provider=kantian（单厂商）；confidence 评估数据可靠性

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 265 行

### 时间范围
- `date` [2026-03-12 ~ 2026-07-02]

### 数据源语义
- 探查分布：（`provider`）：kantian=265


### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, hull_number
- hull_number 关联；时间列是 date（无 update_time 列）

### 取数策略
- 小表（265 行）全量

### 已知坑
- 排序用 date，勿猜 update_time（会报 Unknown column）

