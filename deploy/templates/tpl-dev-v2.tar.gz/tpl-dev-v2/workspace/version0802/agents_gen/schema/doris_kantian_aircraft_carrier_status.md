# 瞰天航母状态表 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | kantian_aircraft_carrier_status || 数据量 | 156 条| 分类 | 航母核心 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | VARCHAR(36) NOT NULL | 自动生成的UUID | 是 || type | VARCHAR(64) NULL | 类型 |  || hull_number | VARCHAR(128) NULL | 编号/名称 |  || status | VARCHAR(64) NULL | 状态 |  || provider | VARCHAR(64) NULL | 厂商 |  || date | DATE NULL | 日期 |  || insert_time | DATETIME NULL | 插入时间 |  || confidence | FLOAT NULL | 置信度 |  || predict | text | 预测：1表示预测 |  || filepath | text | 判断依据路径 |  |## 业务判读规则
### 状态字段
- status 含: 在港/出海/部署/维护/船坞- hull_number 对应航母舷号### 多源融合
- provider 为数据厂商(如Kantian)- 置信度 confidence 评估数据可靠性