# AIS舰船轨迹数据 判读规则与探查档案

## 业务判读规则
- 航速业务含义：0-5节锚泊/低速、5-15节经济巡航、15-25节高速巡航、25+节最大航速
- AIS 开关异常判定：相邻记录间隔 ≥24h 视为 AIS 关闭（隐蔽异常）；再次出现视为恢复（AIS ON）；Initial AIS ON 不计异常
- 航行状态编码 nav_status：0 在航 / 1 锚泊 / 2 失控 / 3 操纵受限 / 4 吃水受限 / 5 系泊 / 6 搁浅 / 7 捕捞 / 8 航行中

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 159204373 行

### 时间范围
- `acquire_time` [1964-03-05 00:00:00 ~ 2026-08-10 10:07:52]

### 数据源语义
- 探查分布：（`source`）：beiyou_ais=158488362, jingan_dwd_bhv_aircraft_combine_rt=256649, jingan_AIS_INTERNAL_AIS_FIXED=188872, jingan_dwd_bhv_aircraft_combine_rt,jingan_dwd_bhv_aircraft_combine_rt_backup_20260522_164356=151057, vesselfinder=95695, None=19096, uscarriers=3964, dvidshub=345
- beiyou_ais≈99.6% 为真实分钟级 AIS 转发；dvidshub 为每日状态快照（时间恒 00:00:00、坐标固定城市中心、speed=null）——推导 AIS 开关前必须排除；source 为 NULL（≈1.9 万行，如 jinganT）按真实轨迹处理，勿用 NOT IN 误过滤

### 坐标范围
- lat [-89.95343~89.999985], lng [-179.99997~179.99983]

### 关键字段事实
- 关联键：uuid, hull_no, mmsi

### 取数策略
- 分钟级主导；"24h 无更新=关闭"阈值隐含分钟级密度前提（同质性假设），稀疏数据降级为"信号缺失"而非战术性关闭
- 全表 1.59 亿行，全量拉取不可行；大数据用 SQL 窗口函数锚点抽取（LAG(acquire_time) + TIMESTAMPDIFF≥24），显式 --limit
- 锚点抽取后，**事件装配调用 `lib/analysis/ais_event_assembly` 模块**（边界合成/同刻冲突/零记录静默/去重），勿手写装配脚本；装配输入含窗口/阈值/首末条边界/零记录状态（见模块 docstring）

### 已知坑
- 网关默认 LIMIT 1000 静默截断；快照共享边界点会产生同刻 OFF+ON 需规避；CVN-79 在建舰在 AIS 有真实信号但不在 carrier_attribution

