# 航母母港信息表 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | carrier_homeport_info || 数据量 | 11 条| 分类 | 航母核心 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| id | bigint | 自增主键，分桶字段 | 是 || hull_number | text | 完整舷号 |  || cn_name | text | 航母中文舰名 |  || homeport_full_name | text | 母港标准全称 |  || location_country | text | 所属国家 |  || location_state_city | text | 州/城市 |  || lat | decimalv3(10,4) | 纬度 北纬正数 |  || lon | decimalv3(10,4) | 经度 西经负/东经正 |  || base_type | text | 基地类型 |  || fleet_belong | text | 隶属舰队 |  || base_function | text | 基地核心功能属性 |  || strategic_position | text | 航母战略定位 |  || create_time | datetimev2(0) | 数据录入时间 |  |## 业务判读规则
### 母港地理分布
- location_country + location_region 确定地缘分布- 可用于判断航母战略方向