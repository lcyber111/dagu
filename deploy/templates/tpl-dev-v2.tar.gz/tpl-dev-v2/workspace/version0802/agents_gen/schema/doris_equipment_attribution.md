# 装备属性数据 判读规则与探查档案

## 业务判读规则
- 装备分类 equipment_type：舰载机/导弹/雷达/电子战系统
- 装备-平台关联：经 carrier_equipment_relation/naval_platform_equipment_mount

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 223 行

### 时间范围
- `equipment_commissioning_date` [1921 ~ 2020-07-20]

### 数据源语义
- 探查分布：（`source`）：jingan_dwd_aircraft_carrier_equipment_attribute=165, yuanting_mount_carry_relation,yuanting_weapon_detection_tracking_remote_sensing=27, yuanting_mount_carry_relation,yuanting_weapon_missile=16, yuanting_mount_carry_relation,yuanting_weapon_military_aircraft=7, yuanting_mount_carry_relation,yuanting_weapon_explosive_ammunition=4, yuanting_mount_carry_relation,yuanting_weapon_other=2, yuanting_mount_carry_relation,yuanting_weapon_light_weapon=1, yuanting_weapon_other=1
- jingan_dwd_aircraft_carrier_equipment_attribute / yuanting 各武器类

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid

### 取数策略
- 小表（223 行）全量；时间列 equipment_commissioning_date

### 已知坑
- 暂无已知坑

