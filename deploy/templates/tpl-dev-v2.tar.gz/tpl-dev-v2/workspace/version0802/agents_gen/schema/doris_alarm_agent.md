# 智能体告警数据 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | alarm_agent || 数据量 | 3 条| 分类 | 情报事件 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | varchar(200) | 唯一标识 | 是 || alarm_id | text | 原告警ID |  || task_id | text | 任务ID |  || alarm_type | text | 告警类型 |  || alarm_content | text | 告警内容 |  || alarm_level | text | 告警级别（1，2，3） |  || start_time | text | 告警开始时间 |  || end_time | text | 告警结束时间 |  || source_agent | text | 来源智能体 |  || confidence | text | 置信度 |  || provider | text | 供应商 |  || insert_time | datetimev2(0) | 插入时间 |  || deal | text | 是否处理（1:已处理，0:未处理） |  |