# 基地属性数据 判读规则与探查档案

## 业务判读规则
- 军事基地属性：名称/位置/设施/国家
- 经 force_base_relation 关联驻扎部队

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 22 行

### 时间范围
- `creation_time` [1767 ~ 1961]

### 数据源语义
- 探查分布：（`source`）：yuanting_base_facility,yuanting_force_base_station_relation,yuanting_carrier_homeport_relation=22
- yuanting_base_facility,yuanting_force_base_station_relation,yuanting_carrier_homeport_relation 组合

### 坐标范围
- latitude [13.569037~48.3451754], longitude [-157.94397~144.921719]

### 关键字段事实
- 关联键：uuid, en_name

### 取数策略
- 小表（22 行）全量；关键字段 uuid/en_name

### 已知坑
- 暂无已知坑

