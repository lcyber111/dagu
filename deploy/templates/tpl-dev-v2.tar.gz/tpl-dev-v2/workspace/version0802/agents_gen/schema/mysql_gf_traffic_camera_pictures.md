# 卡口监控抓拍 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | traffic_camera_pictures |
| 数据库 | gf (MySQL) |
| 分类 | 视觉情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| staff_id | varchar(255) | 人员ID |
| plate_number | varchar(255) | 车牌号 |
| camera_latitude | varchar(255) | 摄像头纬度 |
| camera_longitude | varchar(255) | 摄像头经度 |
| time_capture | varchar(255) | 抓拍时间 |
| camera_id | varchar(255) | 摄像头ID |
| file_name | varchar(255) | 图片文件名 |
| data_type | varchar(255) | 数据类型 |
| tag | varchar(255) | 标签 |
| messenger_name | varchar(255) | 通信人名称 |
| address_name | varchar(255) | 地址名称 |

## 业务判读规则

### 车辆轨迹还原
- 按 plate_number + time_capture 排序可还原车辆移动轨迹
- 跨摄像头序列可判断行驶路线和方向

### 目标关联
- plate_number 可关联 senior_government_vehicle 表确认是否为目标车辆
- staff_id/messenger_name 可关联 attribution_person 表确认人员身份

### 时空分析
- camera_latitude/camera_longitude 对应摄像头安装位置
- time_capture 结合多个摄像头覆盖区域可推算目标停留时间和移动速度
