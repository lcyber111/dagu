# 卡口监控抓拍 判读规则

## 业务判读规则

### 车辆轨迹还原
- 按 plate_number + time_capture 排序可还原车辆移动轨迹
- 跨摄像头序列可判断行驶路线和方向

### 目标关联
- plate_number 可关联 senior_government_vehicle 表确认是否为目标车辆
- staff_id/messenger_name 可关联 attribution_person 表确认人员身份

### 时空分析
- camera_latitude/camera_longitude 对应摄像头安装位置
- time_capture 结合多个摄像头覆盖区域可推算目标停留时间和移动速度
