# 邮件截获记录 判读规则

## 业务判读规则

### 通联关系分析
- from_number/to_number 可构建邮件通联关系网络
- from_belong/to_belong 标记收发双方的机构归属

### 情报提取
- original_content + translation_content 提供完整邮件内容
- named_entity 自动提取人员/机构/地点/事件等关键实体
- abstracts 提供邮件摘要,快速筛选高价值信息

### 情报评分
- score 标记邮件情报价值: 高/中/低
- 可通过关联 contact 表分析通信频次和模式

### 时空分析
- begin_time 按时间序列可构建目标邮件活动规律
- longitude/latitude 定位发件地点,结合 key_area 判断敏感位置
