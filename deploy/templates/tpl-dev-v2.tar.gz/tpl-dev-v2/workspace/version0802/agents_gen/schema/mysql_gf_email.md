# 邮件截获记录 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | email |
| 数据库 | gf (MySQL) |
| 分类 | 通信情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| id | int | 唯一标识(自增) |
| time_capture | varchar(50) | 数据捕获时间 |
| from_number | varchar(255) | 发件人邮箱 |
| to_number | text | 收件人邮箱(支持多个) |
| file_name | varchar(255) | 附件文件名 |
| file_path | varchar(255) | 附件存储路径 |
| data_type | varchar(255) | 数据类型(默认email) |
| longitude | double | 发件位置经度 |
| latitude | double | 发件位置纬度 |
| begin_time | varchar(40) | 邮件发送时间 |
| read | varchar(20) | 是否已读(默认否) |
| original_content | text | 邮件原文 |
| translation_content | text | 邮件翻译内容 |
| named_entity | text | 命名实体识别结果 |
| abstracts | text | 邮件摘要 |
| from_belong | varchar(255) | 发件人归属 |
| to_belong | varchar(255) | 收件人归属 |
| score | varchar(20) | 情报评分/优先级 |

## 业务判读规则

### 通联关系分析
- from_number/to_number 可构建邮件通联关系网络
- from_belong/to_belong 标记收发双方的机构归属

### 情报提取
- original_content + translation_content 提供完整邮件内容
- named_entity 自动提取人员/机构/地点/事件等关键实体
- abstracts 提供邮件摘要,快速筛选高价值信息

### 情报评分
- score 标记邮件情报价值: 高/中/低
- 可通过关联 contact 表分析通信频次和模式

### 时空分析
- begin_time 按时间序列可构建目标邮件活动规律
- longitude/latitude 定位发件地点,结合 key_area 判断敏感位置
