# 高价值目标车辆 判读规则

## 业务判读规则

### 车队识别
- senior_name 对应目标要员身份
- team_leader + team_member 构成完整车队人员配置
- member_role 区分: 司机/安保/副官/通信员

### 车辆识别
- lincence_plate/icense_plate_en 可用于 traffic_camera_pictures 表关联匹配
- vehicle_brand + vehicle_type + vehicle_color 构成视觉识别特征
- 多辆同款同色车辆互换是常见反侦察手段

### 关联分析
- staff_id/member_msisdn 可关联 attribution_person 表获取人员详情
- 车牌号关联 traffic_camera_pictures 可还原车队移动轨迹
