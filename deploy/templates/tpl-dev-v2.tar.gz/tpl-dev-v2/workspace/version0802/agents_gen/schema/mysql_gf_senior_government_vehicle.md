# 高价值目标车辆 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | senior_government_vehicle |
| 数据库 | gf (MySQL) |
| 分类 | 车辆情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| senior_name | varchar(255) | 要员姓名 |
| team_leader | varchar(255) | 车队负责人 |
| team_member | varchar(255) | 车队成员 |
| staff_id | varchar(255) | 人员ID |
| member_role | varchar(255) | 成员角色 |
| member_msisdn | varchar(255) | 成员MSISDN号码 |
| lincence_plate | varchar(255) | 车牌号(波斯文) |
| icense_plate_en | varchar(255) | 车牌号(英文) |
| vehicle_brand | varchar(255) | 车辆品牌 |
| vehicle_type | varchar(255) | 车辆类型(轿车/SUV/防弹车等) |
| vehicle_model | varchar(255) | 车辆型号 |
| vehicle_color | varchar(255) | 车辆颜色 |

## 业务判读规则

### 车队识别
- senior_name 对应目标要员身份
- team_leader + team_member 构成完整车队人员配置
- member_role 区分: 司机/安保/副官/通信员

### 车辆识别
- lincence_plate/icense_plate_en 可用于 traffic_camera_pictures 表关联匹配
- vehicle_brand + vehicle_type + vehicle_color 构成视觉识别特征
- 多辆同款同色车辆互换是常见反侦察手段

### 关联分析
- staff_id/member_msisdn 可关联 attribution_person 表获取人员详情
- 车牌号关联 traffic_camera_pictures 可还原车队移动轨迹
