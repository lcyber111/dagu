# 非结构化数据信息 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | unstructed_data_info || 数据量 | 16733 条| 分类 | 情报事件 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | VARCHAR(200) NOT NULL |  | 是 || file_path_name | VARCHAR(500) NULL |  |  || file_size | VARCHAR(500) NULL |  |  || data_source | VARCHAR(100) NULL |  |  || data_type | VARCHAR(100) NULL |  |  || insert_time | DATETIME NULL | 插入时间 |  || task_id | VARCHAR(100) NULL |  |  || abstract | TEXT NULL |  |  || emergency | TEXT NULL |  |  || confidence | FLOAT NULL | 置信度 |  |