# 飞行器重点数据 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | aircraft_focus_targets || 数据量 | 513 条| 分类 | 属性数据 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| icao | varchar(64) | ICAO 编号 | 是 || flight_type | varchar(128) | 型号 |  || friend_foe | varchar(32) | 敌我 |  || country | varchar(64) | 国家 |  || longitude | text | 精度 |  || latitude | text | 纬度 |  || height | text | 高度 |  || source | text | 数据来源 |  |