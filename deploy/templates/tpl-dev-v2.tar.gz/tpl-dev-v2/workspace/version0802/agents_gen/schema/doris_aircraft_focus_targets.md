# 飞行器重点数据 判读规则与探查档案

## 业务判读规则
- 重点飞行器关注清单：ICAO/机型/敌我(friend_foe)/国家
- 用于 ADS-B 轨迹过滤与重点目标识别

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 513 行

### 时间范围
- 未识别到有效时间列（列: icao, flight_type, friend_foe, country, longitude, latitude, height, source…）

### 数据源语义
- 探查分布：（`source`）：jingan=513
- jingan 单源

### 坐标范围
- latitude [-51.84305~61.25657], longitude [-166.21904~152.70865]

### 关键字段事实
- 关联键：（无典型键列）

### 取数策略
- 小表（513 行）全量

### 已知坑
- 坐标列名是 longitude/latitude（非 lat/lng）；含 height 高度

