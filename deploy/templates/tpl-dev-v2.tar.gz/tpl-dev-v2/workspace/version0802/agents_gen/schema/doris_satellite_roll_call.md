# 卫星点名数据 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | satellite_roll_call || 数据量 | 837 条| 分类 | 情报事件 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | VARCHAR(64) NOT NULL | 唯一标识 | 是 || base_name | VARCHAR(255) NULL | 基地名称 |  || vessels | TEXT NULL | 船舶列表（可存储JSON或逗号分隔） |  || date | DATE NULL | 日期 |  || provider | VARCHAR(100) NULL | 数据提供商 |  || insert_time | DATETIME NULL | 记录插入时间 |  || confidence | FLOAT NULL | 置信度 |  |## 业务判读规则
### 卫星侦察数据
- base_name: 基地名称- vessels: 船舶列表(JSON)- date: 卫星过顶日期### 应用场景
- 验证 AIS 数据完整性- 发现未开 AIS 的目标