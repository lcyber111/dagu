# 部队属性数据 判读规则与探查档案

## 业务判读规则
- 军事部队属性：番号/隶属/驻地/编制
- 经 force_base_relation 关联基地

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 96 行

### 时间范围
- `establishment_date` [ ~ 1999-1]

### 数据源语义
- 探查分布：（`source`）：yuanting_force_organization,yuanting_force_hierarchy_relation,yuanting_force_base_station_relation,yuanting_force_combat_exercise_relation,yuanting_force_command_relation,yuanting_force_commander_relation=96
- yuanting_force_organization 等 yuanting_force_* 多源组合

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, en_name

### 取数策略
- 小表（96 行）全量

### 已知坑
- 暂无已知坑

