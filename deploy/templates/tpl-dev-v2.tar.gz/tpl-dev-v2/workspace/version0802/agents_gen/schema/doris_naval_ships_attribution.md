# 军船属性数据 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | naval_ships_attribution || 数据量 | 59 条| 分类 | 航母核心 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | varchar(200) | 主键id | 是 || unit_id | text | 护航舰艇编号 |  || unit_name | varchar(200) | 护航舰艇名称 |  || unit_type | varchar(200) | 护航舰艇类型 |  || launch_date | text | 下水时间 |  || specific_use | text | 具体用途 |  || power_system | text | 动力系统 |  || service_status | text | 在役状态 |  || cruise_speed | text | 巡航速度 |  || builder | text | 建造商 |  || affiliated_unit | text | 所属部队 |  || displacement | text | 排水量 |  || range | text | 航程 |  || speed | text | 航速 |  || carrier_id | text | 对应航母编号 |  || date | text | 发现时间 |  || location | text | 事件地点 |  || description | text | 事件详细描述 |  || source_section | text | 来源章节 |  || update_date | text | 更新日期 |  || source | text |  |  || insert_time | datetimev2(0) | 插入时间 |  || confidence | float | 置信度 |  |## 业务判读规则
### 护航舰艇类型
- unit_type: 驱逐舰/巡洋舰/核潜艇/补给舰/两攻舰### 编队判定
- 通过 carrier_strike_track 确定当前编队构成