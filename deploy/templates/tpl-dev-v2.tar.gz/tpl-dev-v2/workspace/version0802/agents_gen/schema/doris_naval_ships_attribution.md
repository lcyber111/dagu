# 军船属性数据 判读规则与探查档案

## 业务判读规则
- 护航舰艇类型 unit_type：驱逐舰/巡洋舰/核潜艇/补给舰/两攻舰
- 编队判定：关联 carrier_strike_track

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 59 行

### 时间范围
- `launch_date` [1963-01-01 ~ 2022-06-12]

### 数据源语义
- 探查分布：（`source`）：yuanting_weapon_naval_equipment=51, beiyou=8
- yuanting_weapon_naval_equipment / beiyou

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, mmsi, hull_number

### 取数策略
- 小表（59 行）全量；关键字段 mmsi/hull_number

### 已知坑
- 暂无已知坑

