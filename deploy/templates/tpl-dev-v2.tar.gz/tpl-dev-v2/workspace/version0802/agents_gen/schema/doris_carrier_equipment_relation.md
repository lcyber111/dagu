# 航母装备挂载关系表 判读规则与探查档案

## 业务判读规则
- 航母-装备挂载关系：舰载机/导弹/雷达等
- 装备类别可关联 equipment_attribution 查参数

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 811 行

### 时间范围
- 未识别到有效时间列（列: uuid, carrier_id, equipment_id, carrier_name, equipment_name, source_context, update_date, source…）

### 数据源语义
- 探查分布：（`source`）：yuanting_mount_carry_relation=358, jingan_dwd_aircraft_carrier_equipment_relation=279, yuanting_weapon_equipment_relation=66, yuanting_weapon_naval_equipment=43, 01-4344-持续数据采集_2026-06-1608_46-主对话.html=1, 01-4344-持续数据采集_2026-06-1608_53-主对话.html=1, 01-4344-持续数据采集_2026-06-1608_23-主对话.html=1, 01-4344-持续数据采集_2026-06-1608_24-主对话.html=1
- 多源混合（yuanting 各挂载类 / jingan_dwd_aircraft_carrier_equipment_relation / 少量采集 html）

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid

### 取数策略
- 小表（811 行）全量

### 已知坑
- 无业务时间列（update_date 仅作参考）

