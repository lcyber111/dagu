# 航母装备挂载关系表 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | carrier_equipment_relation || 数据量 | 811 条| 分类 | 航母核心 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | VARCHAR(200) NOT NULL |  | 是 || carrier_id | TEXT NULL | 航母编号（主键） |  || equipment_id | TEXT NULL | 装备编号（主键） |  || carrier_name | TEXT NULL | 舰名 |  || equipment_name | TEXT NULL | 装备名称 |  || source_context | TEXT NULL | 数据来源 |  || update_date | TEXT NULL | 更新日期 |  || source | TEXT NULL |  |  || insert_time | DATETIME NULL | 插入时间 |  || confidence | FLOAT NULL | 置信度 |  |