# 事件属性信息 判读规则与探查档案

## 业务判读规则
- 事件分类 event_type：部署/演习/访问/维修/改装
- 时间线分析按事件日期（event_date/date）构建

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 3155 行

### 时间范围
- `date` [1968-06-22 ~ 2026-08-18]

### 数据源语义
- 探查分布：（`source`）：yuanting=1088, jingan_dwd_aircraft_carrier_event_attribute=707, gfkd=630, carrier_event_attribution=403, jingan_dwd_aircraft_carrier_event_attribute,jingan_dwd_aircraft_carrier_combat_attribute=304, rg=23
- 多源混合（yuanting / jingan_dwd_aircraft_carrier_event_attribute / gfkd / carrier_event_attribution / rg）

### 坐标范围
- latitude [-35.28~90.0], longitude [-166.51917~172.59389]

### 关键字段事实
- 关联键：uuid, entity_name
- entity_name 关联目标；时间列用 date（event_date 多为空）

### 取数策略
- 小表（3155 行）全量，按时间窗过滤

### 已知坑
- 勿用 event_start_time/event_end_time（不存在，已修正）

