# 事件属性信息 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | event || 数据量 | 3155 条| 分类 | 情报事件 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | varchar(200) | 唯一标识 | 是 || event_id | text | 事件ID |  || entity_name | text | 实体名称 |  || carrier_id | text | 载体ID |  || event_type | text | 事件类型 |  || event_name | text | 事件名称 |  || date | text | 事件日期 |  || location | text | 位置描述 |  || description | text | 事件描述 |  || source | text | 数据来源 |  || insert_time | datetimev2(0) | 插入时间 |  || latitude | text | 纬度 |  || longitude | text | 经度 |  || confidence | text | 置信度 |  || thumbnail_url | text | 缩略图URL |  |## 业务判读规则
### 事件分类
- event_type 含: 部署/演习/访问/维修/改装### 时间线分析
- event_start_time/event_end_time 可构建活动时间线