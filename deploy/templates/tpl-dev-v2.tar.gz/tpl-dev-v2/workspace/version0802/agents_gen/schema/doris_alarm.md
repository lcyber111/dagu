# 异动情报表 判读规则与探查档案

## 业务判读规则
- 告警类型 alarm_type：AIS异常/航线偏离/区域入侵/通信异常
- 告警处理状态 status；严重度需结合 alarm_type 与内容研判（无独立 severity 列）
- 结合 event 表可追溯告警前因后果

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 1376 行

### 时间范围
- `start_time` [2025-06-12 17:15:07 ~ 2026-06-11 13:58:27]

### 数据源语义
- 探查分布：（`source`）：beiyou_alarm=1363, None=13
- beiyou_alarm≈全部 + None（少量）

### 坐标范围
- lat [0.0~42.2243], lon [-132.448~0.0]

### 关键字段事实
- 关联键：uuid
- ship_hull/ship_name 关联目标

### 取数策略
- 小表全量拉取（显式 --limit）

### 已知坑
- 无 severity 列（勿写 severity 查询）；部分记录坐标 lat/lng 为 0 表示缺省

