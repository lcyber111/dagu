# 异动情报表 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | alarm || 数据量 | 1369 条| 分类 | 情报事件 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | varchar(200) | 主键ID | 是 || alarm_id | text | 原告警ID |  || task_id | text | 任务ID |  || alarm_type | text | 告警类型 |  || alarm_content | text | 告警内容 |  || start_time | text | 告警开始时间 |  || end_time | text | 告警结束时间 |  || source_data_id | text | 源数据ID |  || judge_agent | text | 判断Agent |  || status | text | 告警状态 |  || ship_hull | text | 船体编号 |  || ship_country | text | 船籍国/注册国家 |  || ship_type | text | 船舶类型 |  || ship_name | text | 船名 |  || ship_mmsi | text | 船舶MMSI |  || ship_imo | text | 船舶IMO编号 |  || ship_callsign | text | 船舶呼号 |  || ais_name | text | AIS设备播发的船名 |  || ais_mmsi | text | AIS设备播发的MMSI |  || ais_imo | text | AIS设备播发的IMO号 |  || ais_callsign | text | AIS设备播发的呼号 |  || lon | text | 经度 |  || lat | text | 纬度 |  || sea_name | text | 海域名称 |  || insert_time | text | 记录插入时间 |  || provider | text | 数据提供方 |  || source | text | 数据来源 |  || confidence | text | 置信度 |  || geohash | text | Geohash编码 |  || emergency | text | 紧急程度 |  |## 业务判读规则
### 告警类型
- alarm_type 含: AIS异常/航线偏离/区域入侵/通信异常### 告警等级
- severity 字段: 低/中/高/严重### 研判参考
- 结合 event 表可追溯告警前因后果