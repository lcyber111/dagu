# 目标联系人网络 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | contact |
| 数据库 | gf (MySQL) |
| 分类 | 关系情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| from_Identity | varchar(255) | 主叫方身份 |
| from_number | varchar(255) | 主叫方号码 |
| to_Identity | varchar(255) | 被叫方身份 |
| to_number | varchar(255) | 被叫方号码 |
| frequency | varchar(255) | 通信频次 |
| duration | varchar(255) | 累计通信时长 |
| begin_time | varchar(255) | 首次通信时间 |
| end_time | varchar(255) | 末次通信时间 |

## 业务判读规则

### 关系网络分析
- from_Identity/to_Identity 定义通信双方身份
- 构建以哈梅内伊为中心的通联关系网络图
- 高频率+长时长的关系对标记为密接关联人

### 通信模式分析
- frequency 指示通信紧密程度: 高频=日常联系,低频=紧急联系
- duration 累计时长反映关系深度
- begin_time/end_time 时间窗口可判断关系活跃期

### 关联分析
- from_number/to_number 可关联 communication 表获取具体通信内容
- from_Identity/to_Identity 可关联 attribution_person 表获取人物详情
- 多层关联可构建完整的社会关系网络
