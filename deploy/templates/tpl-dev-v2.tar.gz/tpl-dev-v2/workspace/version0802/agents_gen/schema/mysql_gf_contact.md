# 目标联系人网络 判读规则

## 业务判读规则

### 关系网络分析
- from_Identity/to_Identity 定义通信双方身份
- 构建以哈梅内伊为中心的通联关系网络图
- 高频率+长时长的关系对标记为密接关联人

### 通信模式分析
- frequency 指示通信紧密程度: 高频=日常联系,低频=紧急联系
- duration 累计时长反映关系深度
- begin_time/end_time 时间窗口可判断关系活跃期

### 关联分析
- from_number/to_number 可关联 communication 表获取具体通信内容
- from_Identity/to_Identity 可关联 attribution_person 表获取人物详情
- 多层关联可构建完整的社会关系网络
