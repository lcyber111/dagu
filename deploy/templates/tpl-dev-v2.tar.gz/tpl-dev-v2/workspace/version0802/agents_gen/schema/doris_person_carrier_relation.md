# 人员航母关系表 字段说明
## 基本信息
| 属性 | 内容 ||------|------|| 表名 | person_carrier_relation || 数据量 | 30 条| 分类 | 人员数据 |## 字段列表
| 字段 | 类型 | 说明 | 主键 ||------|------|------|------|| uuid | VARCHAR(200) NOT NULL |  | 是 || person_id | VARCHAR(200) NULL | 人物ID |  || person_name | TEXT NULL | 人物姓名 |  || person_rank | TEXT NULL | 人物军衔 |  || role | TEXT NULL | 人物在航母的职务(CO/XO/CAG/CSG_Commander/other) |  || hull_number | TEXT NULL | 航母舷号(CVN-69等) |  || carrier_name | TEXT NULL | 航母名称 |  || carrier_class | TEXT NULL | 航母级别 |  || carrier_status | TEXT NULL | 航母服役状态 |  || homeport | TEXT NULL | 航母母港 |  || affiliated_unit | TEXT NULL | 航母所属单位 |  || parent_person_id | TEXT NULL | 上级人物ID |  || source_context | TEXT NULL | 溯源上下文 |  || update_date | TEXT NULL | 更新日期 |  || source | TEXT NULL |  |  || insert_time | DATETIME NULL | 插入时间 |  || confidence | FLOAT NULL | 置信度 |  |## 业务判读规则
### 人物角色
- role: CO(舰长)/XO(副舰长)/CAG(航空联队长)/CSG_Commander(打击群司令)### 关键人物
- 航母舰长任期通常2-3年- 可通过任职时间反推航母活动期