# 人员航母关系表 判读规则与探查档案

## 业务判读规则
- 关键人物-航母关系：role CO(舰长)/XO(副舰长)/CAG(航空联队长)/CSG_Commander(打击群司令)
- 关键人物任期可辅助判断航母指挥脉络

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 39 行

### 时间范围
- 未识别到有效时间列（列: uuid, person_id, parent_person_id, person_name, person_rank, role, hull_number, carrier_name…）

### 数据源语义
- 探查分布：（`source`）：yuanting_person_attribution,yuanting_aircraft_carrier_attribution=24, None=9, yuanting_carrier_commander_relation=6
- yuanting 多源 / jingan / None

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, hull_number

### 取数策略
- 小表（39 行）全量；关键字段 hull_number

### 已知坑
- 暂无已知坑

