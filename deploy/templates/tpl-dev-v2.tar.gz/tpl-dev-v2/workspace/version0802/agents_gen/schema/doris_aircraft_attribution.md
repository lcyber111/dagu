# 飞行器属性数据 判读规则与探查档案

## 业务判读规则
- 飞行器型号参数：作战半径/动力/制造商
- 关联 aircraft_focus_targets / aircraft_ads-b_track

## 探查档案

> 数据事实由 `scripts/probe_tables.py` 只读探查（as-of 2026-08-10）；运行时以运行时 SOP 3.1 探索三步复核。

### 数据量级
- 全表 9 行

### 时间范围
- `service_time` [1966 ~ 2019-02-28]

### 数据源语义
- 探查分布：（`source`）：yuanting_weapon_military_aircraft=9
- yuanting_weapon_military_aircraft

### 坐标范围
- 无经纬度列（或列名非 lat/lng）

### 关键字段事实
- 关联键：uuid, name

### 取数策略
- 小表（9 行）全量

### 已知坑
- 暂无已知坑

