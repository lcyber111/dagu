# 目标关联机构 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | institution |
| 数据库 | gf (MySQL) |
| 分类 | 组织情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| institution_name | varchar(255) | 机构名称 |
| supervisor | varchar(255) | 上级机构/主管单位 |
| institution_nature | varchar(255) | 机构性质 |
| main_purposes | varchar(255) | 主要职能/目的 |
| key_feature | varchar(255) | 关键特征 |
| longitude | varchar(255) | 机构所在地经度 |
| latitude | varchar(255) | 机构所在地纬度 |

## 业务判读规则

### 机构分类
- institution_nature 区分: 政府机构/军事组织/情报机构/宗教机构/研究机构
- 核心机构: IRGC(伊斯兰革命卫队)、MOIS(情报与安全部)、最高领袖办公室

### 层级关系
- supervisor 定义机构隶属关系,可构建组织层级树
- main_purposes 描述机构核心职能

### 空间分析
- longitude/latitude 可在地图上标注机构位置
- 结合 key_area 表判断机构是否位于敏感区域

### 关联分析
- institution_name 可关联 attribution_person 表中的 institution 字段
- 通过组织层级+人员关系可构建目标关联网络
