# 重点目标区域 字段说明

## 基本信息
| 属性 | 内容 |
|------|------|
| 表名 | key_area |
| 数据库 | gf (MySQL) |
| 分类 | 空间情报 |

## 字段列表
| 字段 | 类型 | 说明 |
|------|------|------|
| location_type | varchar(255) | 位置类型 |
| location_name | varchar(255) | 位置名称 |
| location_function | varchar(255) | 位置功能/用途 |
| latitude | varchar(255) | 纬度 |
| longitude | varchar(255) | 经度 |
| geohash | varchar(255) | geohash 编码 |
| type | varchar(255) | 区域类型 |

## 业务判读规则

### 区域分类
- location_type/type 区分: 官邸/办公场所/宗教场所/军事设施/秘密会面点/安全屋
- location_function 详细描述该地点的实际用途

### 威胁等级评估
- 不同类型的区域对应不同的威胁等级和安全评估需求
- 宗教场所(如周五礼拜清真寺)是公开活动的可预测地点
- 秘密会面点属高价值低确证性情报

### 时空分析
- geohash 可用于快速空间索引和邻近搜索
- 结合 signaling 信令位置判断目标是否出现于重点区域附近

### 关联分析
- location_name 可关联 institution 表判断区域所属机构
- 区域经纬度范围可用于过滤通信/信令/抓拍数据
